-- DH-Tools: Modules\DHBavin\Tooltip.lua
-- Adds a "Bavin Points: N" line to any item tooltip whose exact display
-- name appears in ItemPoints.lua's ns.ITEM_POINTS table (or has a live
-- in-game override on top of it - see Core.lua's "Item points" section)
-- - see ItemPoints.lua's header for why the lookup is by name, not
-- itemID (random-suffix rare items share one base itemID but price
-- differently per suffix). Read-only informational display, no
-- permission gate - this doesn't reveal anything guildmates can't
-- already see in the source spreadsheet (or, for a live edit, in the
-- Points Editor itself - PointsEditor.lua).
--
-- Uses ns.GetItemPoints(name), NOT ns.ITEM_POINTS[name] directly, so a
-- Points Editor override is reflected here immediately instead of only
-- after the next addon release ships a regenerated ItemPoints.lua.
--
-- Hooked via GameTooltip:HookScript("OnTooltipSetItem", ...) - the
-- standard, low-risk tooltip-extension idiom (unlike Bavin's still-
-- unbuilt M5 bag-highlight hook, which has real unverified API risk -
-- see PROFILE.md's Known risks). Works everywhere GameTooltip:SetItem
-- gets called - bags, merchant, mail, trade, loot, chat links - since
-- it hooks the shared GameTooltip object, not any one frame. Also hooks
-- ItemRefTooltip (the tooltip shown for chat-linked items specifically),
-- which is a separate frame from GameTooltip.

local DHTools = DHTools
DHTools.Bavin = DHTools.Bavin or {}
local ns = DHTools.Bavin

-- 2026-08-06 (Chris): trying the spreadsheet's richer column-P summary
-- line ("<name>: <points> pts to Bavin; <price/source>", e.g. "crafted
-- by an @Alchemist" or "(est. AH value)") in place of the plain "Bavin
-- Points: N" line, on a trial basis - Chris wants to see how it looks
-- in-game before committing to it, with an easy one-line revert if it's
-- too much text for a tooltip. Flip this back to false to instantly
-- restore the old plain-points line - no other code changes needed.
local USE_DETAIL_LINE = true

local function FormatPoints(points)
    if points == math.floor(points) then
        return string.format("%d", points)
    end
    return string.format("%.2f", points)
end

local function OnTooltipSetItem(tooltip)
    if not ns.GetItemPoints then return end -- Core.lua failed to load
    local name = tooltip:GetItem()
    if not name then return end
    local entry = ns.GetItemPoints(name)
    if not entry then return end
    -- entry.detail only exists for a non-overridden baseline entry (see
    -- Core.lua's GetItemPoints) - anything else (a live override, or an
    -- item added through the Points Editor with no spreadsheet detail)
    -- falls back to the plain line automatically.
    if USE_DETAIL_LINE and entry.detail then
        tooltip:AddLine(entry.detail, 1, 0.82, 0)
    else
        tooltip:AddLine("Bavin Points: " .. FormatPoints(entry.points), 1, 0.82, 0)
    end
    tooltip:Show()
end

GameTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
if ItemRefTooltip then
    ItemRefTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
end
