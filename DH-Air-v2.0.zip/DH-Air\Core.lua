-- DH-Air Core.lua
-- Addon initialization, saved variables, and central event dispatch.

local ADDON_NAME, DHAir = ...
_G.DHAir = DHAir

DHAir.VERSION = "2.0" -- Bump only with Chris's explicit sign-off.

--------------------------------------------------------------------------
-- Defaults / Saved Variables
--------------------------------------------------------------------------

local DEFAULT_MESSAGE = "Please click to help summon {target}!"

local defaults = {
    active = true,          -- auto-summon on/off (auto-invite is independent of this)
    paused = false,         -- pause auto-summon without turning it fully off
    autoInvite = true,      -- whisper "inv" auto-invite feature
    summonTimeout = 30,     -- seconds to wait for a summon before moving on
    minShards = 2,          -- pause auto-summon if Soul Shards drop below this
    shareQueue = true,      -- share the summon queue with other DH-Air Warlocks in the raid/group
    guildOnly = true,       -- only auto-invite/auto-summon players in your guild
    minimap = {
        hide = false,
    },
    -- Per-channel announcement toggles and customizable message text.
    -- {target} is replaced with the player currently being summoned.
    messages = {
        raid    = { enabled = true,  text = DEFAULT_MESSAGE },
        party   = { enabled = true,  text = DEFAULT_MESSAGE },
        guild   = { enabled = false, text = "Now summoning {target} for the Air Service." },
        say     = { enabled = true,  text = DEFAULT_MESSAGE },
        whisper = { enabled = true,  text = "You're being summoned - please stand by!" },
    },
    queue = {},             -- ordered list of { name, summoned, role, queuedAt }
    history = {},           -- name -> true once summoned this session

    -- v2.0: guild-wide roster/registration (see Roster.lua)
    roster = {
        summoners = {},     -- [normalizedName] = { lastSeen = <local GetTime()> }
        clickers  = {},     -- same shape
    },
    codePhrase = "air",             -- /raid chat phrase that self-queues the sender
    autoPromote = true,             -- auto-promote registered Summoners to assistant
    autoPromoteGuildOnly = true,    -- ...but only guild members, by default
}

DHAir.DEFAULT_MESSAGE = DEFAULT_MESSAGE

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then
                dst[k] = {}
            end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

--------------------------------------------------------------------------
-- Utility
--------------------------------------------------------------------------

function DHAir:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff9482c9DH-Air|r: " .. tostring(msg))
end

--------------------------------------------------------------------------
-- Guild roster cache (for the "guild members only" option)
--------------------------------------------------------------------------

DHAir.guildRoster = {} -- normalizedName -> { online = true|false }

-- Asks the game to (re)fetch the guild roster. The actual data isn't
-- necessarily available until GUILD_ROSTER_UPDATE fires afterward.
function DHAir:RequestGuildRoster()
    if not IsInGuild() then return end
    if C_GuildInfo and C_GuildInfo.GuildRoster then
        pcall(C_GuildInfo.GuildRoster)
    elseif GuildRoster then
        pcall(GuildRoster)
    end
end

-- Rebuilds the local guild-membership cache (including online status) from
-- whatever roster data the client currently has (called on GUILD_ROSTER_UPDATE).
function DHAir:UpdateGuildRosterCache()
    for k in pairs(self.guildRoster) do
        self.guildRoster[k] = nil
    end

    if not IsInGuild() then return end

    local numMembers = GetNumGuildMembers and GetNumGuildMembers() or 0
    for i = 1, numMembers do
        local name, _, _, _, _, _, _, _, isOnline = GetGuildRosterInfo(i)
        if name then
            self.guildRoster[self:NormalizeName(name)] = { online = (isOnline == true) }
        end
    end
end

-- Returns true if name is a known member of the player's own guild. Fails
-- open (returns true) if the player isn't in a guild or the roster hasn't
-- loaded yet, since we'd rather occasionally allow a non-guildie through
-- than silently brick auto-invite for everyone because of a timing gap.
function DHAir:IsGuildMember(name)
    if not name then return false end
    if not IsInGuild() then return true end
    if next(self.guildRoster) == nil then return true end
    return self.guildRoster[self:NormalizeName(name)] ~= nil
end

-- Returns true/false if we have a definite answer, or nil if we can't tell
-- (not a guild member, or the roster hasn't loaded) - callers should treat
-- nil as "unknown", not as "offline", since we only have real signal for
-- guild members with a loaded roster.
function DHAir:IsGuildMemberOnline(name)
    if not name then return nil end
    local entry = self.guildRoster[self:NormalizeName(name)]
    if not entry then return nil end
    return entry.online
end

--------------------------------------------------------------------------
-- Permission model (v2.0)
--------------------------------------------------------------------------

-- Resolves `name` to a raid/party unit token and checks leader/assistant
-- status for THAT unit - not necessarily the local player. This is the one
-- function used both to decide what the local player can do, AND to verify
-- an incoming permission-gated broadcast against the receiver's OWN trusted
-- knowledge of the raid roster - never trusting a self-asserted claim baked
-- into the message itself.
function DHAir:UnitHasAuthority(name)
    if not IsInGroup() then return true end -- nobody's grouped yet; anyone can act

    local myName = UnitName("player")
    local unit
    if self:NormalizeName(name) == self:NormalizeName(myName) then
        unit = "player"
    elseif self.FindGroupUnitByName then
        unit = self.FindGroupUnitByName(name)
    end
    if not unit then return false end -- can't verify - fail closed

    return (UnitIsGroupLeader(unit) == true) or (UnitIsGroupAssistant(unit) == true)
end

--------------------------------------------------------------------------
-- Shared window utility
--------------------------------------------------------------------------

-- Sets up a top-level DH-Air window with the properties every one of them
-- needs: proper click-to-raise behavior (so two overlapping DH-Air windows
-- correctly stack based on which you last interacted with, rather than
-- staying stuck in creation order), a guaranteed-opaque background (rather
-- than relying entirely on the template's own backdrop, which may not fully
-- cover every pixel), and dragging scoped to a title-bar-height strip only.
--
-- On that last point: registering drag on an entire frame means clicking
-- ANYWHERE moves the window, and interacts badly with addons like MoveAny
-- that wrap whatever draggable region a frame already exposes with their
-- own click-to-pick-up/click-to-drop behavior - scoping it to a slim strip
-- at the top keeps that behavior confined to where it belongs.
--
-- Every DH-Air window should call this ONCE, right after creating its
-- frame, instead of setting these properties up by hand.
function DHAir:InitStandaloneWindow(targetFrame, rightInset)
    targetFrame:SetToplevel(true)

    local bg = targetFrame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.9)

    targetFrame:SetMovable(true)
    targetFrame:EnableMouse(true)

    local dragRegion = CreateFrame("Frame", nil, targetFrame)
    dragRegion:SetPoint("TOPLEFT", 0, 0)
    dragRegion:SetPoint("TOPRIGHT", -(rightInset or 28), 0) -- leaves room for a close button
    dragRegion:SetHeight(24)
    dragRegion:EnableMouse(true)
    dragRegion:RegisterForDrag("LeftButton")
    dragRegion:SetScript("OnDragStart", function() targetFrame:StartMoving() end)
    dragRegion:SetScript("OnDragStop", function() targetFrame:StopMovingOrSizing() end)
    return dragRegion
end

-- Single entry point for every permission-gated action, checked LOCALLY by
-- the receiver against trusted Blizzard data (never a self-asserted claim
-- in a network message). In 2.2 this is where guild-officer-rank checks get
-- added, without touching any of the call sites below.
function DHAir:HasPermission(action)
    if action == "remove_any" or action == "clear_all" or action == "set_phrase" or action == "invite" then
        return self:UnitHasAuthority(UnitName("player"))
    end
    return false
end

--------------------------------------------------------------------------
-- Event Frame
--------------------------------------------------------------------------

DHAir.frame = CreateFrame("Frame")
DHAir.frame:RegisterEvent("ADDON_LOADED")
DHAir.frame:RegisterEvent("PLAYER_LOGIN")
DHAir.frame:RegisterEvent("CHAT_MSG_WHISPER")
DHAir.frame:RegisterEvent("CHAT_MSG_RAID")
DHAir.frame:RegisterEvent("CHAT_MSG_RAID_LEADER")
DHAir.frame:RegisterEvent("GROUP_ROSTER_UPDATE")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_FAILED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_STOP")
DHAir.frame:RegisterEvent("BAG_UPDATE")
DHAir.frame:RegisterEvent("CHAT_MSG_ADDON")
DHAir.frame:RegisterEvent("GUILD_ROSTER_UPDATE")

function DHAir.OnEvent(event, ...)
    if event == "CHAT_MSG_WHISPER" then
        local msg, sender = ...
        if DHAir.HandleWhisper then
            DHAir:HandleWhisper(msg, sender)
        end
    elseif event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER" then
        local msg, sender = ...
        if DHAir.HandleRaidChat then
            DHAir:HandleRaidChat(msg, sender)
        end
    elseif event == "GROUP_ROSTER_UPDATE" then
        if DHAir.TrySummonNext then
            DHAir:TrySummonNext()
        end
        if DHAir.Sync_OnRosterChanged then
            DHAir:Sync_OnRosterChanged()
        end
    elseif event == "UNIT_SPELLCAST_SUCCEEDED"
        or event == "UNIT_SPELLCAST_FAILED"
        or event == "UNIT_SPELLCAST_INTERRUPTED"
        or event == "UNIT_SPELLCAST_STOP" then
        if DHAir.OnSpellcastEvent then
            DHAir:OnSpellcastEvent(event, ...)
        end
    elseif event == "BAG_UPDATE" then
        if DHAir.OnBagUpdate then
            DHAir:OnBagUpdate()
        end
    elseif event == "CHAT_MSG_ADDON" then
        if DHAir.Sync_OnAddonMessage then
            DHAir:Sync_OnAddonMessage(...)
        end
    elseif event == "GUILD_ROSTER_UPDATE" then
        DHAir:UpdateGuildRosterCache()
    end
end

DHAir.frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loaded = ...
        if loaded == ADDON_NAME then
            DHAirDB = DHAirDB or {}
            CopyDefaults(defaults, DHAirDB)
            DHAir.db = DHAirDB

            -- GetTime() resets on a full client restart (but NOT on /reload),
            -- so a queuedAt saved from a previous session could be a huge,
            -- nonsensical number relative to the fresh clock. Reset any entry
            -- whose queuedAt is impossible (in the "future" relative to now).
            for _, entry in ipairs(DHAir.db.queue) do
                if not entry.queuedAt or entry.queuedAt > GetTime() then
                    entry.queuedAt = GetTime()
                end
            end
        end
        return
    elseif event == "PLAYER_LOGIN" then
        DHAir:Print("v" .. DHAir.VERSION .. " loaded. Type /dhair help for commands.")
        if DHAir.Minimap_Init then
            DHAir.Minimap_Init()
        end
        if DHAir.Sync_Init then
            DHAir:Sync_Init()
        end
        DHAir:RequestGuildRoster()
        return
    end

    DHAir.OnEvent(event, ...)
end)
