-- DH-Air Queue.lua
-- Manages the ordered summon queue and per-session summon history.

local ADDON_NAME, DHAir = ...

-- Strips a "-Realm" suffix for display / comparison purposes.
function DHAir:NormalizeName(name)
    if not name then return name end
    return name:match("^([^%-]+)") or name
end

-- Adds a player to the bottom of the queue. Returns true if added.
function DHAir:QueueAdd(name)
    if not name or name == "" then return false end
    local db = self.db
    local short = self:NormalizeName(name)

    for _, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            return false -- already queued
        end
    end

    if db.history[short] then
        return false -- already summoned this session, don't re-queue
    end

    table.insert(db.queue, {
        name = name,
        summoned = false,
        role = self.EffectiveRole and self:EffectiveRole(name) or nil,
        queuedAt = GetTime(),
    })
    self:Print(short .. " added to the summon queue (position " .. #db.queue .. ").")

    if self.TrySummonNext then
        self:TrySummonNext()
    end

    return true
end

-- Returns the first not-yet-summoned entry, or nil.
function DHAir:QueueNext()
    for _, entry in ipairs(self.db.queue) do
        if not entry.summoned then
            return entry
        end
    end
    return nil
end

--------------------------------------------------------------------------
-- Self-service (any DH-Air installation can join/leave, no permission needed)
--------------------------------------------------------------------------

-- Adds the local player to the queue. Same as being added by someone else's
-- whisper trigger, just self-initiated (e.g. from the Board's "Join queue"
-- button, or the /raid code phrase). Broadcasts so everyone else's queue
-- picks it up too.
function DHAir:SelfJoinQueue()
    local myName = UnitName("player")
    if self:QueueAdd(myName) then
        if self.Sync_BroadcastAdd then
            self:Sync_BroadcastAdd(myName)
        end
        return true
    end
    return false
end

-- Removes the local player from the queue. Always allowed - removing
-- yourself never needs permission, unlike removing someone else.
function DHAir:SelfLeaveQueue()
    local myName = UnitName("player")
    if self:QueueRemove(myName) then
        if self.Sync_IsActive and self:Sync_IsActive() then
            self:Sync_Send("REMOVE", myName)
        end
        return true
    end
    return false
end

--------------------------------------------------------------------------
-- Permission-gated removal (see Core.lua's HasPermission/UnitHasAuthority)
--------------------------------------------------------------------------

-- Requests removing ANY player from the queue. Removing yourself is always
-- allowed; removing someone else requires raid leader/assist. Refuses
-- quietly (with a chat message) rather than attempting and failing, so the
-- UI can just call this without duplicating the permission check itself.
function DHAir:RequestRemove(name)
    local myName = UnitName("player")
    local isSelf = self:NormalizeName(name) == self:NormalizeName(myName)

    if not isSelf and not self:HasPermission("remove_any") then
        self:Print("Only the raid leader or an assistant can remove someone else from the queue.")
        return false
    end

    if not self:QueueRemove(name) then
        return false
    end

    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("REMOVE", name)
    end
    return true
end

-- Requests clearing the ENTIRE queue. Raid leader/assist only.
function DHAir:RequestClearAll()
    if not self:HasPermission("clear_all") then
        self:Print("Only the raid leader or an assistant can clear the entire queue.")
        return false
    end

    self:QueueReset()
    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("CLEARALL")
    end
    return true
end

-- Requests changing the /raid chat code phrase. Leader/assist only for now
-- (see HasPermission - guild-officer-gated in 2.2, same call site).
function DHAir:RequestSetPhrase(newPhrase)
    if not newPhrase or newPhrase == "" then
        self:Print("Usage: /dhair phrase <word or phrase>")
        return false
    end

    if not self:HasPermission("set_phrase") then
        self:Print("Only the raid leader or an assistant can change the code phrase.")
        return false
    end

    self.db.codePhrase = newPhrase
    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("SETPHRASE", newPhrase)
    end
    return true
end

-- Marks a queued player as summoned and records them in session history.
function DHAir:QueueMarkSummoned(name)
    local db = self.db
    local short = self:NormalizeName(name)
    for _, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            entry.summoned = true
        end
    end
    db.history[short] = true
end

-- Removes a player from the queue entirely (does not touch history).
function DHAir:QueueRemove(name)
    local db = self.db
    local short = self:NormalizeName(name)
    for i, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            table.remove(db.queue, i)
            return true
        end
    end
    return false
end

-- Clears the queue and the session history (fresh Air Service session).
function DHAir:QueueReset()
    self.db.queue = {}
    self.db.history = {}
    if self.CancelTimeout then
        self:CancelTimeout()
    end
    self.summonState = "idle"
    self.currentSummon = nil
    self.pendingEntry = nil
    self.failCount = 0
    self.pausedForShards = false
    if self.claims then
        self.claims = {}
    end
    if self.syncBuffers then
        self.syncBuffers = {}
    end
    self:Print("Summon queue and session have been reset.")
end

-- Prints the current queue state to chat.
function DHAir:QueueList()
    local db = self.db
    if #db.queue == 0 then
        self:Print("Summon queue is empty.")
        return
    end
    self:Print("Current summon queue:")
    for i, entry in ipairs(db.queue) do
        local status = entry.summoned and "|cff00ff00(summoned)|r" or "|cffffff00(waiting)|r"
        self:Print(i .. ". " .. self:NormalizeName(entry.name) .. " " .. status)
    end
end

--------------------------------------------------------------------------
-- Display ordering (Board UI) - pure function, no side effects
--------------------------------------------------------------------------

-- Returns queue entries in Board display order:
--   1. the viewer's own entry (if queued), always first
--   2. entries with a role (summoner/clicker), sorted by sortKey/sortDir
--   3. everyone else, sorted by sortKey/sortDir
-- Sorting never reorders ACROSS tiers, only within each one - a helper who
-- just joined still outranks every regular member, but not a helper who's
-- been waiting longer.
function DHAir:SortedQueue(sortKey, sortDir)
    sortKey = sortKey or "wait"
    sortDir = sortDir or "desc"
    local myName = UnitName("player")
    local myKey = self:NormalizeName(myName)

    local function compare(a, b)
        local c
        if sortKey == "name" then
            c = self:NormalizeName(a.name) < self:NormalizeName(b.name) and -1
                or (self:NormalizeName(a.name) > self:NormalizeName(b.name) and 1 or 0)
        else
            local aWait, bWait = GetTime() - (a.queuedAt or GetTime()), GetTime() - (b.queuedAt or GetTime())
            c = aWait < bWait and -1 or (aWait > bWait and 1 or 0)
        end
        if sortDir == "asc" then return c < 0 end
        return c > 0
    end

    local mine, helpers, regular = nil, {}, {}
    for _, entry in ipairs(self.db.queue) do
        if not entry.summoned then
            if self:NormalizeName(entry.name) == myKey then
                mine = entry
            elseif entry.role then
                table.insert(helpers, entry)
            else
                table.insert(regular, entry)
            end
        end
    end

    table.sort(helpers, compare)
    table.sort(regular, compare)

    local ordered = {}
    if mine then table.insert(ordered, mine) end
    for _, e in ipairs(helpers) do table.insert(ordered, e) end
    for _, e in ipairs(regular) do table.insert(ordered, e) end
    return ordered
end
