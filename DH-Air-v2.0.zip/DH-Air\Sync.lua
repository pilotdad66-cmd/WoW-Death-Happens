-- DH-Air Sync.lua
-- Lets any DH-Air installation - Warlocks, Clickers, or plain members -
-- share one guild-wide summon queue and role roster over addon messages.
--
-- PROTOCOL (all messages are "TYPE|payload", sent via C_ChatInfo.SendAddonMessage
-- to RAID if in a raid, else PARTY if grouped, else GUILD so registration and
-- queueing work even before any raid exists; nothing is sent if db.shareQueue
-- is off):
--
--   HELLO                     - "I'm here running DH-Air" (presence/heartbeat)
--   ADD|Name                  - a player was queued locally; peers should add them too
--   CLAIM|Name|ClaimerName    - claimer is about to attempt summoning Name
--   RELEASE|Name              - the current claimer is giving up on Name; it's free again
--   SUMMONED|Name             - Name has been fully summoned (or timed out); mark done everywhere
--   RESET                     - clear the shared queue/session for everyone
--   REMOVE|Name               - remove Name from the queue (self always allowed;
--                               removing someone else requires the SENDER to be
--                               raid leader/assist, verified by the RECEIVER
--                               against their own roster - never self-asserted)
--   CLEARALL                  - clear the whole queue (sender must be leader/assist,
--                               verified the same way as REMOVE)
--   SETPHRASE|newPhrase       - change the /raid chat code phrase (sender must be
--                               leader/assist for now, guild-officer-gated in 2.2 -
--                               verified the same way as REMOVE/CLEARALL)
--   REGISTER|role|Name        - Name is now volunteering as "summoner" or "clicker"
--   UNREGISTER|role|Name      - Name is no longer volunteering as that role
--   SYNCREQ                   - "I just joined/reloaded, please send me the current state"
--   SYNCDATA|i/total|data     - chunked full-state reply to a SYNCREQ (addon-whispered directly
--                               back to the requester, not broadcast, to cut down on raid traffic)
--
-- CONSISTENCY MODEL: this is a lightweight, eventually-consistent gossip
-- protocol, not a strict distributed lock. Two safety nets keep it correct
-- even if messages are dropped, arrive out of order, or a Warlock disconnects
-- mid-claim:
--   1. Claim ties (two Warlocks claim the same player within the same
--      instant) are broken deterministically by comparing claimer names -
--      every client that sees both claims picks the same winner, with no
--      extra messages needed.
--   2. Claims expire on their own (CLAIM_TTL) if never resolved via
--      SUMMONED or RELEASE, so a disconnect can't permanently lock a player
--      out of the queue for everyone else.
-- The one thing this protocol guarantees above all else is the thing that
-- actually matters here: two Warlocks should not both spend a Soul Shard
-- summoning the same player. Minor raciness in queue ORDER across clients
-- is a cosmetic non-issue by comparison.

local ADDON_NAME, DHAir = ...

local PREFIX = "DHAirQueueV1"
local MAX_CHUNK_CHARS = 200
local CLAIM_TTL_SECONDS = 120     -- how long an unresolved claim is honored before being treated as stale
local HELLO_INTERVAL_SECONDS = 300 -- re-announce presence at most this often

DHAir.claims = {}       -- normalizedName -> { by = "ClaimerName", receivedAt = GetTime() }
DHAir.peers = {}        -- name -> GetTime() last seen
DHAir.syncBuffers = {}  -- sender -> { total = n, chunks = {} } for reassembling SYNCDATA
DHAir.lastHelloSent = 0

--------------------------------------------------------------------------
-- Low-level send/receive
--------------------------------------------------------------------------

local function AddonSendMessage(text, channel, target)
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        C_ChatInfo.SendAddonMessage(PREFIX, text, channel, target)
    elseif SendAddonMessage then
        SendAddonMessage(PREFIX, text, channel, target)
    end
end

local function RegisterPrefix()
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
    elseif RegisterAddonMessagePrefix then
        pcall(RegisterAddonMessagePrefix, PREFIX)
    end
end

-- Returns the broadcast channel to use, or nil if sharing isn't possible
-- right now (feature turned off). Prefers the tightest channel available -
-- RAID/PARTY are lower-latency and less noisy than guild-wide GUILD chat -
-- but falls back to GUILD so registration and queueing work even before any
-- raid exists.
function DHAir:Sync_Channel()
    if not self.db or not self.db.shareQueue then return nil end
    if IsInRaid() then return "RAID" end
    if IsInGroup() then return "PARTY" end
    if IsInGuild() then return "GUILD" end
    return nil
end

function DHAir:Sync_IsActive()
    return self:Sync_Channel() ~= nil
end

-- Broadcasts a message to the whole raid/party.
function DHAir:Sync_Send(msgType, payload)
    local channel = self:Sync_Channel()
    if not channel then return end
    local text = payload and (msgType .. "|" .. payload) or msgType
    AddonSendMessage(text, channel)
end

-- Sends a message directly to one player (used for SYNCDATA replies, to
-- avoid broadcasting a potentially large state dump to the whole raid).
function DHAir:Sync_SendTo(msgType, payload, targetName)
    if not self.db or not self.db.shareQueue then return end
    local text = payload and (msgType .. "|" .. payload) or msgType
    AddonSendMessage(text, "WHISPER", targetName)
end

function DHAir:Sync_Init()
    RegisterPrefix()
    if self:Sync_IsActive() then
        self:Sync_SendHello()
        self:Sync_Send("SYNCREQ")
    end
end

-- Called on GROUP_ROSTER_UPDATE - re-announce presence (throttled) so
-- Warlocks who join later still discover each other.
function DHAir:Sync_OnRosterChanged()
    if not self:Sync_IsActive() then return end
    local now = GetTime()
    if now - (self.lastHelloSent or 0) < HELLO_INTERVAL_SECONDS then return end
    self:Sync_SendHello()
end

function DHAir:Sync_SendHello()
    self.lastHelloSent = GetTime()
    self:Sync_Send("HELLO")
    if self.Roster_Reannounce then
        self:Roster_Reannounce()
    end
end

--------------------------------------------------------------------------
-- Claims
--------------------------------------------------------------------------

function DHAir:IsClaimStale(claim)
    if not claim then return true end
    return (GetTime() - claim.receivedAt) > CLAIM_TTL_SECONDS
end

-- Stores/refreshes a claim, applying the deterministic tie-break: if a
-- different claimer is already recorded and still fresh, only the
-- alphabetically-earlier name wins (every client applies the same rule,
-- so all clients converge on the same winner independent of message order).
function DHAir:StoreClaim(name, claimerName)
    self.claims = self.claims or {}
    local key = self:NormalizeName(name)
    local existing = self.claims[key]

    if existing and existing.by ~= claimerName and not self:IsClaimStale(existing) then
        if claimerName < existing.by then
            self.claims[key] = { by = claimerName, receivedAt = GetTime() }
        end
        -- else: existing claimer already wins the tie-break; keep it.
    else
        self.claims[key] = { by = claimerName, receivedAt = GetTime() }
    end
end

function DHAir:ClearClaim(name)
    if not self.claims then return end
    self.claims[self:NormalizeName(name)] = nil
end

function DHAir:GetClaim(name)
    if not self.claims then return nil end
    return self.claims[self:NormalizeName(name)]
end

-- Releases OUR claim (if we hold it) and tells everyone else it's free.
function DHAir:ReleaseClaim(name)
    if not name then return end
    self:ClearClaim(name)
    if self:Sync_IsActive() then
        self:Sync_Send("RELEASE", name)
    end
end

--------------------------------------------------------------------------
-- Outgoing state-change broadcasts (called from Queue.lua / Summon.lua)
--------------------------------------------------------------------------

function DHAir:Sync_BroadcastAdd(name)
    if self:Sync_IsActive() then
        self:Sync_Send("ADD", name)
    end
end

function DHAir:Sync_BroadcastSummoned(name)
    if self:Sync_IsActive() then
        self:Sync_Send("SUMMONED", name)
    end
end

function DHAir:Sync_BroadcastReset()
    if self:Sync_IsActive() then
        self:Sync_Send("RESET")
    end
end

--------------------------------------------------------------------------
-- Full-state sync (for late joiners / reloads)
--------------------------------------------------------------------------

local function RoleCode(role)
    if role == "summoner" then return "s" end
    if role == "clicker" then return "c" end
    return ""
end

local function RoleFromCode(code)
    if code == "s" then return "summoner" end
    if code == "c" then return "clicker" end
    return nil
end

-- Encodes the local queue as "Name:status:role:elapsed,..." - elapsed is
-- seconds since queued, transmitted rather than an absolute timestamp since
-- GetTime() isn't comparable across clients (same reasoning as claim TTLs).
local function EncodeQueue(queue)
    local parts = {}
    local now = GetTime()
    for _, entry in ipairs(queue) do
        local elapsed = math.max(0, math.floor(now - (entry.queuedAt or now)))
        table.insert(parts, entry.name .. ":" .. (entry.summoned and "1" or "0")
            .. ":" .. RoleCode(entry.role) .. ":" .. elapsed)
    end
    return table.concat(parts, ",")
end

local function DecodeQueueChunk(data)
    local entries = {}
    for pair in data:gmatch("[^,]+") do
        local name, status, roleCode, elapsed = pair:match("^(.-):(%d):([a-z]*):(%d+)$")
        if name then
            table.insert(entries, {
                name = name,
                summoned = (status == "1"),
                role = RoleFromCode(roleCode),
                elapsed = tonumber(elapsed) or 0,
            })
        end
    end
    return entries
end

function DHAir:Sync_SendState(targetName)
    local encoded = EncodeQueue(self.db.queue)
    if encoded == "" then return end -- nothing to share

    local chunks = {}
    local remaining = encoded
    while #remaining > 0 do
        if #remaining <= MAX_CHUNK_CHARS then
            table.insert(chunks, remaining)
            remaining = ""
        else
            -- Cut at the last comma before the limit so we never split an entry.
            local cut = remaining:sub(1, MAX_CHUNK_CHARS)
            local lastComma = cut:find(",[^,]*$")
            if not lastComma then lastComma = MAX_CHUNK_CHARS end
            table.insert(chunks, remaining:sub(1, lastComma - 1))
            remaining = remaining:sub(lastComma + 1)
        end
    end

    local total = #chunks
    for i, chunk in ipairs(chunks) do
        self:Sync_SendTo("SYNCDATA", i .. "/" .. total .. "|" .. chunk, targetName)
    end
end

-- Merges received entries into our local queue/history. "Summoned" is
-- sticky - it only ever upgrades a local waiting entry to summoned, never
-- the reverse, since avoiding a double-summon is the whole point. Role and
-- wait time are only used to BOOTSTRAP a brand-new entry we didn't already
-- know about - if we already have this entry locally, its role stays under
-- the authority of Roster.lua's REGISTER/UNREGISTER tracking instead, since
-- that's fresher than a potentially-stale SYNCDATA snapshot.
function DHAir:Sync_MergeEntries(entries)
    for _, remote in ipairs(entries) do
        local key = self:NormalizeName(remote.name)
        local found = nil
        for _, local_ in ipairs(self.db.queue) do
            if self:NormalizeName(local_.name) == key then
                found = local_
                break
            end
        end

        if not found then
            table.insert(self.db.queue, {
                name = remote.name,
                summoned = remote.summoned,
                role = remote.role,
                queuedAt = GetTime() - (remote.elapsed or 0),
            })
            if remote.summoned then
                self.db.history[key] = true
            end
        elseif remote.summoned and not found.summoned then
            found.summoned = true
            self.db.history[key] = true
        end
    end

    if self.TrySummonNext then
        self:TrySummonNext()
    end
end

--------------------------------------------------------------------------
-- Incoming message handling
--------------------------------------------------------------------------

function DHAir:Sync_OnAddonMessage(prefix, message, channel, sender)
    if prefix ~= PREFIX then return end

    local myName = UnitName("player")
    local senderShort = self:NormalizeName(sender)
    if senderShort == myName then return end -- ignore any echo of our own messages

    self.peers[senderShort] = GetTime()

    local msgType, rest = message:match("^([^|]+)|?(.*)$")
    if not msgType then return end

    if msgType == "HELLO" then
        -- presence already recorded above; nothing else to do

    elseif msgType == "ADD" then
        local name = rest
        if name ~= "" then
            self:QueueAdd(name) -- QueueAdd itself doesn't re-broadcast, so no echo loop
        end

    elseif msgType == "CLAIM" then
        local name, claimer = rest:match("^(.-)|(.+)$")
        if name and claimer then
            self:StoreClaim(name, claimer)
            -- If we were mid-claim on the same player and just lost the
            -- deterministic tie-break, back off immediately rather than
            -- waiting out our own grace timer.
            if self.summonState == "claiming" and self.currentSummon
                and self:NormalizeName(self.currentSummon) == self:NormalizeName(name) then
                local claim = self:GetClaim(name)
                if claim and claim.by ~= myName then
                    if self.claimHandle then
                        self.claimHandle:Cancel()
                        self.claimHandle = nil
                    end
                    self.summonState = "idle"
                    self.currentSummon = nil
                    self.pendingEntry = nil
                    self:TrySummonNext()
                end
            end
        end

    elseif msgType == "RELEASE" then
        local name = rest
        if name ~= "" then
            self:ClearClaim(name)
            self:TrySummonNext()
        end

    elseif msgType == "SUMMONED" then
        local name = rest
        if name ~= "" then
            self:ClearClaim(name)
            self:QueueMarkSummoned(name)
            self:TrySummonNext()
        end

    elseif msgType == "RESET" then
        self:QueueReset()

    elseif msgType == "REMOVE" then
        local name = rest
        if name ~= "" then
            local isSelfRemoval = self:NormalizeName(name) == senderShort
            if isSelfRemoval or self:UnitHasAuthority(sender) then
                self:QueueRemove(name)
            end
            -- else: sender isn't leader/assist and isn't removing themselves -
            -- silently ignored rather than trusting a self-asserted claim.
        end

    elseif msgType == "CLEARALL" then
        if self:UnitHasAuthority(sender) then
            self:QueueReset()
        end

    elseif msgType == "SETPHRASE" then
        local newPhrase = rest
        if newPhrase ~= "" and self:UnitHasAuthority(sender) then
            self.db.codePhrase = newPhrase
        end

    elseif msgType == "REGISTER" or msgType == "UNREGISTER" then
        if self.Roster_OnMessage then
            self:Roster_OnMessage(msgType, rest)
        end

    elseif msgType == "SYNCREQ" then
        self:Sync_SendState(sender)

    elseif msgType == "SYNCDATA" then
        local header, data = rest:match("^(%d+/%d+)|(.*)$")
        if not header then return end
        local i, total = header:match("^(%d+)/(%d+)$")
        i, total = tonumber(i), tonumber(total)
        if not i or not total then return end

        self.syncBuffers[sender] = self.syncBuffers[sender] or { total = total, chunks = {} }
        local buf = self.syncBuffers[sender]
        buf.chunks[i] = data

        local received = 0
        for _ in pairs(buf.chunks) do received = received + 1 end
        if received >= buf.total then
            local fullData = table.concat(buf.chunks, ",")
            self.syncBuffers[sender] = nil
            self:Sync_MergeEntries(DecodeQueueChunk(fullData))
        end
    end
end

--------------------------------------------------------------------------
-- Visibility helpers
--------------------------------------------------------------------------

function DHAir:PrintPeers()
    local now = GetTime()
    local any = false
    self:Print("Other DH-Air Warlocks seen in the last 5 minutes:")
    for name, lastSeen in pairs(self.peers) do
        if now - lastSeen < HELLO_INTERVAL_SECONDS then
            self:Print("  - " .. name)
            any = true
        end
    end
    if not any then
        self:Print("  (none)")
    end
end
