-- DH-Tools: Modules\DHBavin\Tooltip.lua
-- Adds a "Bavin Points: N" line to any item tooltip whose exact display
-- name appears in ItemPoints.lua's ns.ITEM_POINTS table (or has a live
-- in-game override on top of it - see Core.lua's "Item points" section)
-- - see ItemPoints.lua's header for why the lookup is by name, not
-- itemID (random-suffix rare items share one base itemID but price
-- differently per suffix). Read-only informational display, no
-- permission gate - this doesn't reveal anything guildmates can't
-- already see in the source spreadsheet (or, for a live edit, in the
-- Points Editor itself - PointsEditor.lua).
--
-- Uses ns.GetItemPoints(name), NOT ns.ITEM_POINTS[name] directly, so a
-- Points Editor override is reflected here immediately instead of only
-- after the next addon release ships a regenerated ItemPoints.lua.
--
-- Hooked via GameTooltip:HookScript("OnTooltipSetItem", ...) - the
-- standard, low-risk tooltip-extension idiom (unlike Bavin's still-
-- unbuilt M5 bag-highlight hook, which has real unverified API risk -
-- see PROFILE.md's Known risks). Works everywhere GameTooltip:SetItem
-- gets called - bags, merchant, mail, trade, loot, chat links - since
-- it hooks the shared GameTooltip object, not any one frame. Also hooks
-- ItemRefTooltip (the tooltip shown for chat-linked items specifically),
-- which is a separate frame from GameTooltip.

local DHTools = DHTools
DHTools.Bavin = DHTools.Bavin or {}
local ns = DHTools.Bavin

local function FormatPoints(points)
    if points == math.floor(points) then
        return string.format("%d", points)
    end
    return string.format("%.2f", points)
end

local function OnTooltipSetItem(tooltip)
    if not ns.GetItemPoints then return end -- Core.lua failed to load
    local name = tooltip:GetItem()
    if not name then return end
    local entry = ns.GetItemPoints(name)
    if not entry then return end
    tooltip:AddLine("Bavin Points: " .. FormatPoints(entry.points), 1, 0.82, 0)
    tooltip:Show()
end

GameTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
if ItemRefTooltip then
    ItemRefTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
end
