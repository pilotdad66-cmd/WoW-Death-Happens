# DH-Air

**Version 2.1.5** | Author: **Loopi** | For: *Death Happens* Hardcore guild — Air Service

---

## Summary

DH-Air is a Warlock addon built specifically for running the Death Happens guild's
"Air Service" — the process of summoning large numbers of players to a single
location in WoW Classic Hardcore.

Instead of manually tracking whispers, invites, and turns, DH-Air automates the
repetitive parts of the job so the Warlock can focus on watching chat and reacting
to anything unusual:

- **Auto-Invite** — whisper the Warlock "inv" (or a similar phrase) and you're
  automatically invited to the raid/party.
- **Guild Members Only (optional)** — restrict auto-invite and auto-summon to
  players in your own guild. Off by default; when on, whispers and queued
  players from anyone outside your guild are simply ignored/skipped.
- **Explicit Queue Joins** — getting summoned is always something you asked
  for: whisper the Warlock the code phrase (default `air`), type it in raid
  chat, or use the Board's Join Queue button. A plain invite request never
  queues you by itself.
- **Auto-Summon** — the Warlock works through the queue one player at a time,
  targeting and casting Ritual of Summoning, waiting for each summon to complete
  or time out before moving to the next person. No duplicate summons.
- **Shared Queue Across Multiple Warlocks** — if more than one Warlock in the
  raid is running DH-Air, they automatically share a single summon queue over
  addon messages. Two Warlocks can run Air Service at the same time without
  ever both spending a shard summoning the same player - each player is
  claimed by exactly one Warlock before casting starts. Self-healing if a
  Warlock disconnects mid-summon; catches up automatically if you join or
  reload mid-session.
- **Customizable Chat Announcements** — every time a new summon begins, DH-Air
  can announce it in any combination of Raid, Group, Guild, `/say`, and a
  direct whisper to the player being summoned. Each channel can be turned
  on/off independently and has its own fully editable message template
  (default: `Please click to help summon {target}!`).
- **Minimap Button** — a standard LibDataBroker/LibDBIcon minimap button using
  the same icon as the Warlock spell Ritual of Summoning. Left-click toggles
  auto-summon on/off (auto-invite keeps running either way); right-click
  opens the config window; drag to reposition.
- **Pause / Resume** — hold the queue in place without losing your spot, from
  a slash command or a button right on the Options page.
- **Session Reset** — wipe the queue and start fresh for a new Air Service run
  (resets it for every linked Warlock, not just you).
- **Automatic Failure Recovery** — if a summon cast fails (e.g. out of range,
  interrupted), DH-Air retries the same player a few times before pausing
  itself with a clear message, instead of silently stalling or spamming chat
  with repeated failed attempts. If you're sharing the queue, giving up also
  frees the player up for another Warlock to take over.
- **Soul Shard Safeguard** — before every summon attempt, DH-Air checks your
  Soul Shard count. If it's below a configurable minimum (default 2),
  auto-summon pauses itself before targeting or announcing anything, so you
  never get a failed cast or a "please click" message for a summon that
  can't actually happen. It resumes automatically once you've restocked.
- **Configuration Window** — `/dhair config` opens a four-page settings
  window (Options, Messages, Sharing, and About), in the style of a standard
  addon options panel.
- **Air Service Board** — `/dhair board` (or minimap left-click) opens a
  shared, live-updating window for the whole raid, not just Warlocks: see
  the queue, who's currently being summoned and by whom, join/leave the
  queue yourself, register as a Summoner or Clicker, and (if you're a
  Summoner) manually summon anyone already in your raid.
- **Summoner / Clicker Registration** — declare yourself available as a
  Summoner or Clicker so everyone can see who's on deck, independent of the
  summon queue itself.
- **Self-Service Queue** — join or leave the summon queue yourself, no
  whisper to a Warlock required.
- **Destination Picker & Guild-Wide Destination List** — pick where you
  want to be summoned to (flight point or dungeon summoning stone) from
  the Board or the minimap menu; the list is split into Flight Points (by
  continent) and Dungeon Stones so it's easy to browse. Officers can add,
  remove, enable/disable, or reset the guild-wide list to the built-in
  defaults from a dedicated Destinations editor window — everyone can
  view it, only officers can edit it, and edits sync live to the whole
  raid/guild.
- **Raid-Chat Code Phrase** — typing a configurable phrase in raid chat
  joins the queue automatically, the same as whispering.
- **Auto-Promote & Leader-Succession Rescue** — optionally auto-promotes
  registered Summoners to raid assistant, and can hand raid lead to a
  registered Summoner if it unexpectedly lands elsewhere (e.g. after the
  leader disconnects).

DH-Air does **not** replace the Warlock's Soul Shards, positioning, or judgment —
it only automates the bookkeeping (who's next, who's already been summoned,
inviting, and announcing) so summon runs go faster and with fewer mistakes.

---

## Help

### Slash Commands

| Command | Effect |
|---|---|
| `/dhair board` | Opens the Air Service Board (see below) - the main window for everyone, not just Warlocks. |
| `/dhair join` | Adds yourself to the summon queue - no whisper needed. |
| `/dhair leave` | Removes yourself from the summon queue. |
| `/dhair summoner on` / `off` | Registers/unregisters you as a Summoner. |
| `/dhair clicker on` / `off` | Registers/unregisters you as a Clicker. |
| `/dhair start` | Turns auto-summon **on**. |
| `/dhair stop` | Turns auto-summon **off**. Auto-invite keeps working. |
| `/dhair pause` | Pauses auto-summon without losing the queue. |
| `/dhair resume` | Resumes a paused queue. |
| `/dhair reset` | Clears the summon queue and session (shared with other DH-Air Warlocks, if sharing is on). |
| `/dhair queue` | Prints the current queue and each player's status to chat. |
| `/dhair shards` | Prints your current Soul Shard count and the configured minimum. |
| `/dhair share on` / `off` | Turns queue sharing with other DH-Air Warlocks on or off. |
| `/dhair peers` | Lists other DH-Air Warlocks seen recently in your raid/party. |
| `/dhair sync` | Re-requests the shared queue from other DH-Air Warlocks (useful after a reload). |
| `/dhair invite on` / `off` | Turns the auto-invite whisper trigger on or off. |
| `/dhair guildonly on` / `off` | Restricts auto-invite/auto-summon to your own guild's members. |
| `/dhair phrase [<word or phrase>]` | Shows the current raid-chat code phrase, or sets a new one (raid leader/assist only). |
| `/dhair autopromote on` / `off` | Auto-promotes registered Summoners to raid assistant as they join. |
| `/dhair autopromote guildonly on` / `off` | Restricts auto-promote to guild members only. |
| `/dhair remove <name>` | Removes someone else from the queue (raid leader/assist only). |
| `/dhair clearall` | Clears the entire queue for everyone (raid leader/assist only). |
| `/dhair config` | Opens the configuration window. |
| `/dhair` (no argument) | Prints this command list. |

### Minimap Button

DH-Air uses the standard LibDataBroker-1.1 / LibDBIcon-1.0 minimap button,
the same system used by most WoW addons, so it behaves like the minimap
icons you're already used to:

- **Left-click**: opens the Air Service Board (see below).
- **Right-click**: opens the config window (`/dhair config`).
- **Drag**: reposition the button around the minimap.
- Can be hidden entirely from the Options page in `/dhair config`.

### The Air Service Board (`/dhair board`, or minimap left-click)

The Board is the main window for running or joining an Air Service - built
for everyone, not just Warlocks. It's a resizable window showing:

- **Live stats** — how many Summoners and Clickers are currently registered
  and ready, and how many players are in the queue right now.
- **Who's currently being summoned**, and by which Warlock, updated live -
  useful when more than one Warlock is running Air Service at once.
- **The queue itself**, one row per player, sortable by Name or by Waiting
  time (click either column header to sort/reverse). Each row shows the
  player's registered role (Summoner/Clicker, if any), how long they've been
  waiting, and an action button: **Summon** (if you're a registered Summoner
  and they're already in your raid/party - see Manual Summon below),
  **Invite** (if you have leader/assist), or a plain "not in raid"/"offline"
  label otherwise. Your own row shows a remove (**X**) button to leave the
  queue instead; anyone with leader/assist can remove other rows too.
- **Join queue / Leave queue** button - same as `/dhair join` / `/dhair leave`.
- **"I'm a summoner" / "I'm a clicker"** checkboxes - same as
  `/dhair summoner on|off` / `/dhair clicker on|off`.
- A **Start/Stop auto-summon** button, shown only if you're a registered
  Summoner.
- A **Clear entire queue** button, shown only if you have leader/assist.

### Registering as a Summoner or Clicker

Registering is a pure declaration - it doesn't add you to the queue by
itself, and joining the queue doesn't register you as anything. The two are
deliberately independent: a Clicker who's already parked at the meeting spot
can register as ready without ever asking to be summoned, and someone can
join the queue to be summoned without registering as anything at all.

Use `/dhair summoner on|off` / `/dhair clicker on|off`, or the checkboxes on
the Board. Registration is shared with every other DH-Air user in your
raid/party (or guild, if no group exists yet), so everyone's Board shows the
same up-to-date counts and role tags.

### Self-Service Queue (Join / Leave)

Anyone can add or remove themselves from the summon queue directly - no
whisper to a Warlock required: `/dhair join` / `/dhair leave`, or the Join
queue / Leave queue button on the Board.

### Configuration Window (`/dhair config`)

The window has a page list on the left:

- **Options** — toggle auto-invite, restrict to guild members only, show/hide
  the minimap button, set the summon timeout (10–90 seconds), set the
  minimum Soul Shards before auto-summon pauses itself (default 2), set the
  raid-chat code phrase (leader/assist only), reset the queue/session,
  pause/resume auto-summon, and print the current queue.
- **Messages** — enable/disable and customize the announcement text for each
  of Raid, Group, Guild, `/say`, and a direct Whisper to the player being
  summoned. Use `{target}` anywhere in a message and it will be replaced
  with the name of the player currently being summoned. A "Restore Default
  Messages" button resets all five back to their originals.
- **Sharing** — turn shared-queue mode on/off, see whether it's currently
  active (and in which channel), print the list of other DH-Air Warlocks
  seen recently, and manually re-request the shared queue.
- **About** — shows the addon version, the detected game client version, the
  author (Loopi), and the copyright notice.

### How Auto-Invite Works

Whisper the Warlock a short phrase like `inv`, `invite`, `inv me`, `pls inv`,
etc., and you're auto-invited to the raid/party. As of 2.1.3 an invite
request does **not** put you in the summon queue - joining the queue is
always a separate, deliberate act. To get queued, whisper the code phrase
(default `air`) instead: that both queues you and auto-invites you in one
whisper (and shares the queue addition with any other DH-Air Warlocks in
the raid). Matching intentionally only accepts short, whole-phrase requests
(not a substring match) so normal conversation whispers aren't mistaken for
requests. There's a short cooldown per player to avoid invite spam if
someone's client re-sends the same whisper.

"Guild members only" is **on by default** (`/dhair guildonly off` to disable,
or the checkbox in Options): whispers from anyone outside your guild are
ignored entirely - no invite, no queue add. This also applies retroactively
to auto-summon: if a non-guild player is already in the queue (e.g. from
before this was enabled, or synced in from another Warlock who has it
disabled), auto-summon simply skips them rather than summoning them.

### Raid-Chat Code Phrase

Anyone in raid or raid-leader chat who types the configured code phrase
(default `air`, exact match, case-insensitive) is automatically added to
the summon queue - handy for a Clicker calling out to the whole raid
instead of whispering the Warlock directly. Whispering the same phrase
directly to the Warlock works too (and also gets you an invite if you're
not in the group yet). View or set it with `/dhair phrase [<word or phrase>]`, or the
"Raid-chat code phrase" field on the Options page. Changing it requires raid
leader/assist (same requirement as `/dhair clearall`), and the change
propagates to every DH-Air user sharing the queue.

### How Auto-Summon Works

1. DH-Air looks at the next player in the queue who hasn't been summoned yet
   and, if sharing is on, isn't already claimed by another DH-Air Warlock.
2. It checks your Soul Shard count. If it's below the configured minimum
   (default 2), auto-summon pauses right there - before targeting anyone or
   sending any chat message - and resumes automatically once you've
   restocked above the minimum (or you can `/dhair resume` manually).
3. If sharing, it broadcasts a claim on that player and waits briefly for a
   competing claim from another Warlock before proceeding (see "Shared Queue"
   below for how conflicts are resolved).
4. It targets that player (they must already be in your raid/party — this
   happens automatically once their invite is accepted).
5. It casts Ritual of Summoning and waits for the game to confirm the ritual
   actually started before announcing anything — this avoids announcing (and
   later wrongly marking someone "summoned") if the cast fails silently, e.g.
   from an invalid target.
6. Once confirmed, it announces in whichever of Raid/Group/Guild/`/say`/Whisper
   you've enabled, using your custom message for each, and starts the
   completion timeout.
7. It waits for the ritual to complete or hit the configurable timeout
   (default 30 seconds) before moving to the next player.
8. Once a player has been summoned in the session, they won't be queued or
   summoned again (by you or, if sharing, by any other linked Warlock) unless
   you `/dhair reset`.

If a cast fails to start or gets interrupted for a reason other than low
shards (out of range, LoS, etc.), DH-Air retries the same player up to 3
times (a few seconds apart) before pausing auto-summon with a clear chat
message, rather than silently stalling forever or hammering the same failed
cast repeatedly. If sharing is on, giving up also releases the claim so
another Warlock can pick that player up. Use `/dhair resume` once you've
resolved the issue.

### Manual Summon

A registered Summoner can also summon someone on demand, outside the
automatic queue order, by clicking **Summon** next to their row on the Board
(only shown once that player is actually in your raid/party). Useful for
pulling a specific person forward - e.g. someone about to log for the night -
without resetting or reordering the rest of the queue.

### Auto-Promote & Leader-Succession Rescue

- **Auto-promote** (`/dhair autopromote on`, optionally paired with
  `/dhair autopromote guildonly on` to restrict it to guild members): while
  you're raid leader, every registered Summoner in the raid is automatically
  promoted to assistant, so they can invite people themselves instead of
  routing every invite through the leader. Re-checked whenever the roster
  changes, so new arrivals get swept in too.
- **Leader-succession rescue**: if raid lead unexpectedly lands on someone
  who isn't a registered Summoner - most commonly Blizzard's own
  auto-succession after the leader disconnects - and a DH-Air client
  notices itself becoming leader in that situation, it hands lead straight
  to the best available registered Summoner (preferring one actively running
  auto-summon, then earliest to join the raid) rather than leaving Air
  Service leaderless. This is deliberately conservative: it never
  second-guesses a deliberate hand-off a human just made on purpose, and it
  only ever acts through your own client - if the new leader isn't running
  DH-Air at all, a human still has to hand off manually, same as always.

### Shared Queue (Multiple Warlocks)

If more than one Warlock in your raid or party is running DH-Air with sharing
enabled (the default), they automatically discover each other and share one
summon queue:

- Whoever gets whispered the code phrase adds that player to everyone's
  queue.
- Before casting on a player, a Warlock broadcasts a claim on them. If two
  Warlocks happen to decide on the same player at the same instant, the
  conflict resolves itself automatically and consistently for everyone
  watching - there's no need to coordinate manually or worry about a race
  wasting a shard.
- Once a player is fully summoned (or times out), that's broadcast too, so
  they're marked done everywhere and won't be re-queued or re-summoned.
- If a Warlock disconnects or reloads mid-claim, that claim expires on its
  own after a couple of minutes so the player doesn't get stuck waiting on
  someone who's no longer there.
- Joining mid-session or reloading your UI automatically requests the current
  queue from other DH-Air Warlocks so you catch up (use `/dhair sync` to
  force this manually).
- Turn it off anytime with `/dhair share off` or the Sharing page in
  `/dhair config` if you'd rather keep your queue private.

### Known Limitations

- DH-Air cannot detect the exact moment a bystander clicks to complete the
  summon portal — the game doesn't expose that to addons. It relies on the
  Ritual of Summoning cast being confirmed and then a timeout window
  (adjustable in Options) before advancing. If a summon finishes early, you
  can always `/dhair reset` and re-queue, or simply let the timeout elapse.
- The Warlock still needs Soul Shards and must be positioned appropriately;
  DH-Air only handles targeting, casting, invites, queueing, and
  announcements.
- Requires being in a raid or party for Ritual of Summoning; players must have
  accepted their invite before they can be targeted/summoned.
- Queue sharing is a lightweight, best-effort protocol, not a guaranteed
  distributed lock. It's specifically designed so that the one thing that
  matters most - never double-summoning the same player - holds up even if
  messages are delayed or a Warlock disconnects; minor differences in queue
  *order* across different Warlocks' screens can happen and are harmless.
- "Guild members only" is a personal setting, not a shared one - if you're
  sharing the queue with a Warlock who has it turned off, a non-guild player
  they queue will still show up in your queue too; you just won't be the one
  who summons them.

---

## Changelog

### 2.1.5
- **Fixed: the wait between summons.** Auto-summon used to sit in a fixed
  30-second wait after every cast, no matter how fast the ritual actually
  finished - on a real raid this meant summoning one person with the
  addon while summoning three more manually in the same time. It now
  advances as soon as the Ritual of Summoning channel itself ends. The
  old timer still exists as a fallback if a summon gets stuck, cut down
  from 30s to 4s. **This is the first time this fix has run in a live
  raid on this build** - if summons don't feel faster, or you see "no
  channel detected" in chat, let Loopi know.
- **Manual picks are never refused any more.** Clicking a specific person
  to summon out of order used to just say "please wait" if a ritual was
  already in progress. Now it switches targets instead - warning you on
  the first click, acting on the second - and whoever you were
  summoning stays in the queue rather than getting skipped.
- **New: you can now re-queue after being summoned once**, instead of
  needing a new session. Whispering/typing the trigger phrase again just
  resets your spot.
- **New: the trigger phrase now works in party chat, not just raid
  chat**, and whispering it with extra text (e.g. "air need a ride to
  BRD") is captured as a note the Warlock can see on the Board.
- **New: assisted destinations.** A raid leader/assist can set another
  player's summon destination for them from the Board; the affected
  player gets a whisper telling them what was set and how to change it.
- **The Board now re-syncs automatically** whenever your own group/raid
  membership changes, instead of only on request.
- Everyone should update together: a client still on 2.1.4 won't
  understand another Warlock's assisted-destination messages and will
  silently disagree about destinations (it just ignores them - no error).

### 2.1.4
- **Fixed: the Board's "In queue" counter never went down.** Once a player
  was summoned they were correctly removed from the list, but the counter
  at the top of the window kept climbing - so after a long session it
  showed everyone summoned that night rather than the number still
  waiting. It now always matches the rows below it. (Found running a real
  raid of 30+ summons; thanks for the report.)

### 2.1.3
- **Fixed: opening the Board shortly after login/reload could crash with
  "Cannot anchor protected frames to regions".** No more waiting before
  the first open.
- **Fixed: the Board's top text (queue count, stats, column headers, Join
  Queue label) could stay blank until you clicked something in the
  window.** Everything now populates immediately on open.
- **Fixed: the Confirm Summon click could silently do nothing** (no
  target, no cast). Both this and the two Board bugs above shared root
  causes in how the 2.1.2 secure-click rework interacted with the game
  client's frame-security model; the secure click handling has been
  restructured to work with it.
- **Fixed: Abort Summon now actually stops your in-flight Ritual of
  Summoning cast**, instead of only resetting the queue state while the
  cast kept going. Clicking Abort when nothing is being summoned is safe -
  it will never cancel an unrelated cast (like your hearthstone).
- **Summon flow: the per-row button for Summoners is now "Pick".** It
  selects that player (out of queue order) and arms the gold **Confirm
  Summon** button; the Confirm click is what targets and casts. Same
  one-click-per-summon flow auto-summon already uses.
- **Changed: joining the summon queue is now always an explicit act.**
  Whispering `inv` (and variants) still gets you an auto-invite but no
  longer adds you to the summon queue. To join the queue: whisper the code
  phrase (default `air`) - which also auto-invites you - or type it in
  raid chat, or use the Board's Join Queue button. Guildies whispering for
  an ordinary group invite no longer end up queued for a summon.
- **Fixed: the About page showed version "2.0"** regardless of the actual
  installed version. It now always shows the real version.

### 2.1.2
- **Fixed: clicking Summon (or Confirm Summon) could throw "blocked from an
  action only available to the Blizzard UI" and never actually target or
  cast on the player**, even though the target was in your group. The
  button now dispatches the targeting/cast through the game's own secure
  click handling instead of doing it in plain addon code, which is what
  Blizzard's security model actually requires for this to work reliably.
- Everyone running Air Service should update - this affects every manual
  and confirm-click summon.

### 2.1.1
- **Fixed: the minimap's "Set Destination" → Flight Points menu never
  opened.** It was nested one level deeper than the Board's own
  destination picker (Flight Points → continent → actual list) and never
  actually rendered that deepest level in-game. Restructured to match the
  Board exactly: "Flight Points - Eastern Kingdoms" and "Flight Points -
  Kalimdor" are now their own top-level choices.
- **Fixed: adding a destination through the Destinations editor never let
  you set its continent**, so anything an officer added there silently
  never showed up in either continent-grouped picker. The "Add a
  destination" dropdown now offers "Flight Point - Eastern Kingdoms" /
  "Flight Point - Kalimdor" / "Summoning Stone" directly.
- **Fixed a real data-loss bug in the destinations list.** Continent
  tagging (and, on an outdated client, potentially the whole custom list)
  could get silently wiped out whenever the guild-wide list synced between
  Warlocks - including on every ordinary login/reload. If you'd noticed
  officer-added destinations or continent grouping mysteriously
  disappearing, this was why. Also hardened the sync protocol itself so an
  addon still running an older version can no longer silently corrupt a
  current version's synced data - it just won't sync with it until it's
  updated, instead.
- Everyone should update to this version - if even one Warlock/guildmate
  stays on 2.1 or earlier, destinations sync between that person and
  everyone else on 2.1.1 simply won't happen (see previous point) until
  they update too.

### 2.1 (beta)
- **New: guild-wide Destinations list.** Pick a destination (flight point
  or dungeon summoning stone) for yourself from the Board or the minimap
  menu's "Set Destination" submenu — the list is now split into Flight
  Points (grouped by continent: Eastern Kingdoms / Kalimdor) and Dungeon
  Stones instead of one long flat list.
- **New: Destinations editor window.** Everyone can open it to view the
  current list read-only; guild officers (rank ≤ the configurable officer
  threshold, default 3) additionally get Add/Remove/Enable/Disable/Reset
  controls. Edits sync live to everyone sharing the queue, and a late
  joiner picks up the current (possibly officer-edited) list, not the
  built-in defaults. "Reset to Default" now genuinely reverts to the
  built-in starter list — including which entries start disabled — instead
  of force-enabling everything.
- **New starter destinations:** The Stockade (Stormwind City) is back in
  the built-in list; it, Ragefire Chasm, and The Deadmines all start
  **disabled by default** (all three are reachable without a summon) but
  remain selectable if an officer re-enables them.
- **Board:** added a Destination column (sortable, like Name/Waiting) and
  a Whisper action button per row; fixed the Destination/Waiting column
  headers overlapping and not lining up with their data columns.
- Minimap left-click still opens the Board, right-click still opens
  config — unchanged from 2.0.

### 2.0
- Updated for WoW 1.15.9 (Interface bumped to 11509).
- **New: raid-chat code phrase.** Anyone in raid or raid-leader chat who
  types the configured phrase (default `air`, exact match, case-insensitive)
  is automatically added to the summon queue, the same as whispering `inv`.
  Set or view it with `/dhair phrase [<word or phrase>]`, or the new
  "Raid-chat code phrase" field on the Options page of `/dhair config`.
  Changing it requires raid leader/assist (same as `/dhair clearall`), and
  the change propagates to every DH-Air Warlock sharing the queue.
- "Guild members only" now defaults to **on** instead of off. Use
  `/dhair guildonly off` (or the Options checkbox) if you want DH-Air to
  auto-invite/auto-summon non-guild players too.
- **New: Air Service Board** (`/dhair board`, or minimap left-click) - a
  shared, live-updating window for the whole raid, not just Warlocks. See
  the queue and who's currently being summoned by whom, join/leave the
  queue yourself, register as a Summoner or Clicker, and manually summon
  anyone already in your raid. Minimap left-click now opens the Board
  instead of toggling auto-summon; right-click still opens config.
- **New: Summoner/Clicker registration** (`/dhair summoner on|off`,
  `/dhair clicker on|off`, or the Board's checkboxes) - declare yourself
  available so others can see who's on deck, independent of the queue.
- **New: self-service queue** (`/dhair join` / `/dhair leave`, or the
  Board's Join/Leave button) - add or remove yourself from the summon queue
  without whispering a Warlock.
- **New: manual summon** - a registered Summoner can click Summon next to
  anyone already in the raid, from the Board, to summon them on demand
  outside the automatic queue order.
- **New: auto-promote and leader-succession rescue** (`/dhair autopromote
  on|off`, optionally `/dhair autopromote guildonly on|off`) - automatically
  promotes registered Summoners to assistant, and can hand raid lead to a
  registered Summoner if it unexpectedly lands elsewhere (e.g. after the
  leader disconnects).

### 1.3
- Fixed the minimap button's right-click not doing anything on Classic Era.
  Root cause was two separate bugs in the vendored LibDBIcon-1.0 library
  (fetched from a stale mirror): right-click wasn't registered at all, and
  a `math.mod` call (removed from Lua since 5.0) would have errored on
  every frame while dragging the button. Replaced the library with a
  current, verified copy.
- Simplified the minimap button's right-click: it now opens the config
  window directly instead of a dropdown menu. The previous EasyMenu-based
  menu didn't reliably appear on live Classic Era even after the click
  registration was fixed, so rather than keep debugging a client-specific
  quirk blind, right-click now does one simple, proven-reliable thing.
  Pause/Resume (previously only in that menu) is now also a button on the
  Options page, so nothing is lost.
- Added a fifth announcement channel: **Whisper to Target** - sends a
  private, customizable message directly to the player being summoned.
  Enabled by default.
- Fixed a layout bug on the Messages page where each channel's row was
  very slightly offset further right than the one above it (each row was
  anchored to the previous row's edit box instead of a fixed baseline).
  All rows now line up exactly.

### 1.2
- Optional "guild members only" restriction (`/dhair guildonly on|off`, or
  the Options page): when on, auto-invite ignores whispers from non-guild
  players, and auto-summon skips any non-guild player already in the queue.
  Off by default. Fails open (doesn't block anyone) if you're not in a guild
  or the guild roster hasn't finished loading yet, rather than risk bricking
  auto-invite over a startup timing gap.

### 1.1 (first published release)
- Initial release.
- Auto-invite on whisper ("inv" and common variants).
- Auto-add invited players to the summon queue.
- Auto-summon loop: target → cast → confirm → announce → wait for
  completion/timeout → advance, with no duplicate summons within a session.
- Shared summon queue across multiple DH-Air Warlocks in the same raid/party,
  with claim-based conflict resolution, self-healing on disconnect, and
  automatic catch-up sync for late joiners/reloads.
- Customizable, independently toggleable announcements for Raid, Group,
  Guild, and `/say`, with a `{target}` placeholder.
- Standard LibDataBroker/LibDBIcon minimap button (Ritual of Summoning icon)
  with on/off toggle and right-click menu (config, pause/resume, reset).
- Pause / Resume for auto-summon.
- Session reset to clear the queue and summon history.
- Automatic retry-then-pause on repeated cast failures, so a bad target or
  bad positioning can't stall the run silently or spam chat.
- Proactive Soul Shard check before every summon attempt: pauses before
  targeting/announcing if shards are below a configurable minimum (default
  2), and resumes automatically once restocked.
- `/dhair` slash commands: start, stop, pause, resume, reset, queue, shards,
  share on/off, peers, sync, invite on/off, config.
- Configuration window (`/dhair config`) with Options, Messages, Sharing, and
  About pages.
