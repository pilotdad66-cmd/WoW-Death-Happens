-- DH-Air Config.lua
-- /dhair config window: left-hand page list (Options, Messages, About) + right content pane.

local ADDON_NAME, DHAir = ...

local frame
local navButtons = {}

--------------------------------------------------------------------------
-- Options page
--------------------------------------------------------------------------

local function CreateOptionsPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Options")

    local inviteCheck = CreateFrame("CheckButton", "DHAirInviteCheck", panel, "UICheckButtonTemplate")
    inviteCheck:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -20)
    _G[inviteCheck:GetName() .. "Text"]:SetText("Enable auto-invite (whisper INV)")
    inviteCheck:SetScript("OnClick", function(self)
        DHAir.db.autoInvite = self:GetChecked() and true or false
    end)

    local guildOnlyCheck = CreateFrame("CheckButton", "DHAirGuildOnlyCheck", panel, "UICheckButtonTemplate")
    guildOnlyCheck:SetPoint("TOPLEFT", inviteCheck, "BOTTOMLEFT", 0, -8)
    _G[guildOnlyCheck:GetName() .. "Text"]:SetText("Guild members only (invite & summon)")
    guildOnlyCheck:SetScript("OnClick", function(self)
        DHAir.db.guildOnly = self:GetChecked() and true or false
        if DHAir.db.guildOnly and DHAir.RequestGuildRoster then
            DHAir:RequestGuildRoster()
        end
    end)

    local minimapCheck = CreateFrame("CheckButton", "DHAirMinimapCheck", panel, "UICheckButtonTemplate")
    minimapCheck:SetPoint("TOPLEFT", guildOnlyCheck, "BOTTOMLEFT", 0, -8)
    _G[minimapCheck:GetName() .. "Text"]:SetText("Show minimap button")
    minimapCheck:SetScript("OnClick", function(self)
        local show = self:GetChecked() and true or false
        DHAir.db.minimap.hide = not show
        local LDBIcon = LibStub("LibDBIcon-1.0", true)
        if LDBIcon then
            if show then
                LDBIcon:Show("DHAir")
            else
                LDBIcon:Hide("DHAir")
            end
        end
    end)

    local phraseLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    phraseLabel:SetPoint("TOPLEFT", minimapCheck, "BOTTOMLEFT", 4, -16)
    phraseLabel:SetText("Raid-chat code phrase (leader/assist only):")

    local phraseEdit = CreateFrame("EditBox", "DHAirPhraseEdit", panel, "InputBoxTemplate")
    phraseEdit:SetSize(160, 20)
    phraseEdit:SetPoint("TOPLEFT", phraseLabel, "BOTTOMLEFT", 6, -6)
    phraseEdit:SetAutoFocus(false)
    phraseEdit:SetMaxLetters(32)
    phraseEdit:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    phraseEdit:SetScript("OnEscapePressed", function(self)
        self:SetText(DHAir.db.codePhrase or "")
        self:ClearFocus()
    end)
    phraseEdit:SetScript("OnEditFocusLost", function(self)
        local newPhrase = self:GetText()
        if newPhrase == (DHAir.db.codePhrase or "") then return end
        if not DHAir:RequestSetPhrase(newPhrase) then
            self:SetText(DHAir.db.codePhrase or "") -- revert: no permission, or empty phrase
        end
    end)

    local slider = CreateFrame("Slider", "DHAirTimeoutSlider", panel, "OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT", phraseEdit, "BOTTOMLEFT", -6, -20)
    -- 2026-08-08: was 10-90 in steps of 5, back when this was genuinely
    -- "how long a summon takes". It's now only the stuck-summon fallback
    -- (Summon.lua @kb:channel-driven-advance) and the whole range lives
    -- in Core.lua so this slider and the ADDON_LOADED migration can't
    -- disagree.
    local fbMin = DHAir.SUMMON_FALLBACK_MIN or 3
    local fbMax = DHAir.SUMMON_FALLBACK_MAX or 15
    slider:SetMinMaxValues(fbMin, fbMax)
    slider:SetValueStep(1)
    slider:SetObeyStepOnDrag(true)
    slider:SetWidth(220)
    _G[slider:GetName() .. "Low"]:SetText(tostring(fbMin))
    _G[slider:GetName() .. "High"]:SetText(tostring(fbMax))
    slider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value + 0.5)
        DHAir.db.summonTimeout = value
        -- 2026-08-08: relabelled from "Summon timeout". This is no longer
        -- how long a summon takes to release - the ritual CHANNEL ending
        -- does that now (Summon.lua @kb:channel-driven-advance). It only
        -- applies when the channel never starts at all.
        _G[self:GetName() .. "Text"]:SetText("Stuck-summon fallback: " .. value .. "s")
    end)

    local shardSlider = CreateFrame("Slider", "DHAirMinShardsSlider", panel, "OptionsSliderTemplate")
    shardSlider:SetPoint("TOPLEFT", slider, "BOTTOMLEFT", 0, -34)
    shardSlider:SetMinMaxValues(0, 6)
    shardSlider:SetValueStep(1)
    shardSlider:SetObeyStepOnDrag(true)
    shardSlider:SetWidth(220)
    _G[shardSlider:GetName() .. "Low"]:SetText("0")
    _G[shardSlider:GetName() .. "High"]:SetText("6")
    shardSlider:SetScript("OnValueChanged", function(self, value)
        value = math.floor(value + 0.5)
        DHAir.db.minShards = value
        _G[self:GetName() .. "Text"]:SetText("Pause below this many Soul Shards: " .. value)
    end)

    local resetBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    resetBtn:SetSize(160, 22)
    resetBtn:SetPoint("TOPLEFT", shardSlider, "BOTTOMLEFT", -4, -30)
    resetBtn:SetText("Reset Queue / Session")
    resetBtn:SetScript("OnClick", function() DHAir:QueueReset() end)

    local pauseBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    pauseBtn:SetSize(160, 22)
    pauseBtn:SetPoint("TOPLEFT", resetBtn, "BOTTOMLEFT", 0, -8)
    pauseBtn:SetScript("OnClick", function()
        DHAir.db.paused = not DHAir.db.paused
        DHAir.pausedForShards = false
        DHAir:Print(DHAir.db.paused and "Auto-summon paused." or "Auto-summon resumed.")
        if not DHAir.db.paused then
            DHAir:TrySummonNext()
        end
        pauseBtn:SetText(DHAir.db.paused and "Resume Auto-Summon" or "Pause Auto-Summon")
    end)

    local queueBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    queueBtn:SetSize(160, 22)
    queueBtn:SetPoint("TOPLEFT", pauseBtn, "BOTTOMLEFT", 0, -8)
    queueBtn:SetText("Print Queue to Chat")
    queueBtn:SetScript("OnClick", function() DHAir:QueueList() end)

    -- Guild officer rank threshold (M3, DH-Air-Destinations-Design.md §3/§7):
    -- Guild-Master-only (HasPermission "set_officer_threshold"), same
    -- SetShown(HasPermission(...)) idiom Board.lua's clearAllBtn already
    -- uses for its own officer-gated control - hidden entirely for anyone
    -- who isn't rank 0, rather than shown-but-disabled, since a regular
    -- member fiddling with a control they can't use isn't useful UI.
    local officerLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    officerLabel:SetPoint("TOPLEFT", queueBtn, "BOTTOMLEFT", 4, -20)
    officerLabel:SetText("Guild officer rank (Guild Master only):")

    local officerDropdown = CreateFrame("Frame", "DHAirOfficerRankDropdown", panel, "UIDropDownMenuTemplate")
    officerDropdown:SetPoint("TOPLEFT", officerLabel, "BOTTOMLEFT", -16, -4)
    UIDropDownMenu_SetWidth(officerDropdown, 160)

    local function OfficerRank_OnClick(self)
        if not DHAir:HasPermission("set_officer_threshold") then
            DHAir:Print("Only the Guild Master can change the officer rank threshold.")
            return
        end
        DHAir.db.officerRankThreshold = self.value
        UIDropDownMenu_SetSelectedValue(officerDropdown, self.value)
        UIDropDownMenu_SetText(officerDropdown, self:GetText())
    end

    UIDropDownMenu_Initialize(officerDropdown, function(selfFrame, level)
        local numRanks = GuildControlGetNumRanks and GuildControlGetNumRanks() or 0
        for i = 0, numRanks - 1 do
            -- GuildControlGetRankName is 1-indexed (index 1 = Guild Master),
            -- while GetGuildRosterInfo's rankIndex (what IsGuildOfficer
            -- compares against) is 0-indexed - hence the +1 here.
            local rankName = (GuildControlGetRankName and GuildControlGetRankName(i + 1)) or ("Rank " .. i)
            local info = UIDropDownMenu_CreateInfo()
            info.text = rankName .. " (rank " .. i .. ")"
            info.value = i
            info.func = OfficerRank_OnClick
            UIDropDownMenu_AddButton(info, level)
        end
    end)

    panel.Refresh = function()
        inviteCheck:SetChecked(DHAir.db.autoInvite)
        guildOnlyCheck:SetChecked(DHAir.db.guildOnly)
        minimapCheck:SetChecked(not DHAir.db.minimap.hide)
        phraseEdit:SetText(DHAir.db.codePhrase or "")
        slider:SetValue(DHAir.db.summonTimeout)
        _G[slider:GetName() .. "Text"]:SetText("Stuck-summon fallback: " .. DHAir.db.summonTimeout .. "s")
        pauseBtn:SetText(DHAir.db.paused and "Resume Auto-Summon" or "Pause Auto-Summon")
        shardSlider:SetValue(DHAir.db.minShards)
        _G[shardSlider:GetName() .. "Text"]:SetText("Pause below this many Soul Shards: " .. DHAir.db.minShards)

        local canSetThreshold = DHAir:HasPermission("set_officer_threshold")
        officerLabel:SetShown(canSetThreshold)
        officerDropdown:SetShown(canSetThreshold)
        if canSetThreshold then
            local current = DHAir.db.officerRankThreshold or 3
            local rankName = (GuildControlGetRankName and GuildControlGetRankName(current + 1))
                or ("Rank " .. current)
            UIDropDownMenu_SetSelectedValue(officerDropdown, current)
            UIDropDownMenu_SetText(officerDropdown, rankName .. " (rank " .. current .. ")")
        end
    end

    return panel
end

--------------------------------------------------------------------------
-- Messages page (customizable /raid, /group, /guild, /say announcements)
--------------------------------------------------------------------------

local CHANNELS = {
    { key = "raid",    label = "Raid Chat" },
    { key = "party",   label = "Group Chat" },
    { key = "guild",   label = "Guild Chat" },
    { key = "say",     label = "/Say" },
    { key = "whisper", label = "Whisper to Target" },
}

local ROW_HEIGHT = 56 -- fixed vertical spacing per row, measured from checkbox top to checkbox top

-- Every row anchors to the SAME fixed baseline (not to the previous row's
-- edit box), each at its own absolute Y offset. This keeps every checkbox
-- and edit box perfectly left-aligned regardless of how any other row is
-- sized - no drift accumulates from row to row.
local function CreateChannelRow(parent, baseline, channelKey, channelLabel, rowIndex)
    local yOffset = -(rowIndex - 1) * ROW_HEIGHT

    local checkName = "DHAirMsgCheck_" .. channelKey
    local check = CreateFrame("CheckButton", checkName, parent, "UICheckButtonTemplate")
    check:SetPoint("TOPLEFT", baseline, "BOTTOMLEFT", 0, yOffset)
    _G[checkName .. "Text"]:SetText("Announce in " .. channelLabel)

    local editName = "DHAirMsgEdit_" .. channelKey
    local edit = CreateFrame("EditBox", editName, parent, "InputBoxTemplate")
    edit:SetSize(330, 20)
    edit:SetPoint("TOPLEFT", baseline, "BOTTOMLEFT", 6, yOffset - 24)
    edit:SetAutoFocus(false)
    edit:SetMaxLetters(255)
    edit:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnEditFocusLost", function(self)
        DHAir.db.messages[channelKey].text = self:GetText()
    end)

    check:SetScript("OnClick", function(self)
        DHAir.db.messages[channelKey].enabled = self:GetChecked() and true or false
    end)

    return check, edit
end

local function CreateMessagesPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Messages")

    local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    hint:SetPoint("RIGHT", -16, 0)
    hint:SetJustifyH("LEFT")
    hint:SetText("Use {target} anywhere in a message - it will be replaced with the player's name. "
        .. "\"Whisper to Target\" sends privately to the player being summoned instead of a chat channel.")
    hint:SetWordWrap(true)

    local rows = {}
    for i, info in ipairs(CHANNELS) do
        local check, edit = CreateChannelRow(panel, hint, info.key, info.label, i)
        rows[info.key] = { check = check, edit = edit }
    end

    local lastRowBottom = -((#CHANNELS - 1) * ROW_HEIGHT) - 24 - 20 -- bottom of the last edit box, plus gap

    local resetBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    resetBtn:SetSize(180, 22)
    resetBtn:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", -6, lastRowBottom)
    resetBtn:SetText("Restore Default Messages")
    resetBtn:SetScript("OnClick", function()
        for _, info in ipairs(CHANNELS) do
            DHAir.db.messages[info.key].text = (info.key == "guild")
                and "Now summoning {target} for the Air Service."
                or DHAir.DEFAULT_MESSAGE
        end
        panel.Refresh()
    end)

    panel.Refresh = function()
        for _, info in ipairs(CHANNELS) do
            local cfg = DHAir.db.messages[info.key]
            rows[info.key].check:SetChecked(cfg.enabled)
            rows[info.key].edit:SetText(cfg.text)
        end
    end

    return panel
end

--------------------------------------------------------------------------
-- Sharing page (multi-Warlock shared queue)
--------------------------------------------------------------------------

local function CreateSharingPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Sharing")

    local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    hint:SetPoint("RIGHT", -16, 0)
    hint:SetJustifyH("LEFT")
    hint:SetText("When enabled, other Warlocks running DH-Air in your raid/party share "
        .. "one summon queue with you, so nobody wastes a Soul Shard summoning the same "
        .. "player twice.")
    hint:SetWordWrap(true)

    local shareCheck = CreateFrame("CheckButton", "DHAirShareCheck", panel, "UICheckButtonTemplate")
    shareCheck:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", -4, -50)
    _G[shareCheck:GetName() .. "Text"]:SetText("Share summon queue with other DH-Air Warlocks")
    shareCheck:SetScript("OnClick", function(self)
        DHAir.db.shareQueue = self:GetChecked() and true or false
        if DHAir.db.shareQueue and DHAir.Sync_Init then
            DHAir:Sync_Init()
        end
    end)

    local status = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    status:SetPoint("TOPLEFT", shareCheck, "BOTTOMLEFT", 4, -12)

    local peersBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    peersBtn:SetSize(180, 22)
    peersBtn:SetPoint("TOPLEFT", status, "BOTTOMLEFT", -4, -14)
    peersBtn:SetText("Print Active Peers to Chat")
    peersBtn:SetScript("OnClick", function()
        if DHAir.PrintPeers then DHAir:PrintPeers() end
    end)

    local syncBtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    syncBtn:SetSize(180, 22)
    syncBtn:SetPoint("TOPLEFT", peersBtn, "BOTTOMLEFT", 0, -8)
    syncBtn:SetText("Re-sync Queue Now")
    syncBtn:SetScript("OnClick", function()
        if DHAir.Sync_IsActive and DHAir:Sync_IsActive() then
            DHAir:Print("Requesting the current shared queue from other DH-Air Warlocks...")
            DHAir:Sync_Send("SYNCREQ")
        else
            DHAir:Print("Queue sharing is off or you're not in a group.")
        end
    end)

    panel.Refresh = function()
        shareCheck:SetChecked(DHAir.db.shareQueue)
        local active = DHAir.Sync_IsActive and DHAir:Sync_IsActive()
        if not DHAir.db.shareQueue then
            status:SetText("|cffff0000Off|r - your queue is private to you.")
        elseif active then
            status:SetText("|cff00ff00Active|r - broadcasting to your "
                .. (IsInRaid() and "raid" or "party") .. ".")
        else
            status:SetText("|cffffff00On, but idle|r - not currently in a raid or party.")
        end
    end

    return panel
end

--------------------------------------------------------------------------
-- About page
--------------------------------------------------------------------------

local function CreateAboutPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("About DH-Air")

    local body = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    body:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -16)
    body:SetPoint("RIGHT", -16, 0)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")

    panel.Refresh = function()
        local gameVersion = GetBuildInfo()
        local text = "Addon Version: " .. DHAir.VERSION .. "\n"
            .. "Game Version: " .. tostring(gameVersion) .. "\n\n"
            .. "Author: Loopi\n\n"
            .. "Built for the Death Happens Hardcore guild Air Service, "
            .. "to help Warlocks auto-invite and summon players in an orderly queue.\n\n"
            .. "Copyright (c) 2026 Loopi. All rights reserved."
        body:SetText(text)
    end

    return panel
end

--------------------------------------------------------------------------
-- Frame / navigation
--------------------------------------------------------------------------

local function SelectPage(key)
    for k, b in pairs(navButtons) do
        if k == key then
            b:LockHighlight()
        else
            b:UnlockHighlight()
        end
    end
    for k, p in pairs(frame.pages) do
        if k == key then
            p:Show()
            if p.Refresh then p.Refresh() end
        else
            p:Hide()
        end
    end
end

function DHAir:Config_Open()
    if not frame then
        frame = CreateFrame("Frame", "DHAirConfigFrame", UIParent, "BasicFrameTemplateWithInset")
        frame:SetSize(520, 560)
        frame:SetPoint("CENTER")
        -- Toplevel raising, opaque background, and title-bar-only dragging -
        -- see Core.lua's InitStandaloneWindow for why (this is also what
        -- fixed the Board window's identical overlap/dragging bugs).
        DHAir:InitStandaloneWindow(frame)
        if frame.TitleText then
            frame.TitleText:SetText("DH-Air Configuration")
        end
        tinsert(UISpecialFrames, "DHAirConfigFrame")

        local nav = CreateFrame("Frame", nil, frame)
        nav:SetPoint("TOPLEFT", 12, -32)
        nav:SetPoint("BOTTOMLEFT", 12, 12)
        nav:SetWidth(130)

        local navBg = nav:CreateTexture(nil, "BACKGROUND")
        navBg:SetAllPoints()
        navBg:SetColorTexture(0, 0, 0, 0.25)

        local content = CreateFrame("Frame", nil, frame)
        content:SetPoint("TOPLEFT", nav, "TOPRIGHT", 10, 0)
        content:SetPoint("BOTTOMRIGHT", -12, 12)

        frame.pages = {
            Options = CreateOptionsPanel(content),
            Messages = CreateMessagesPanel(content),
            Sharing = CreateSharingPanel(content),
            About = CreateAboutPanel(content),
        }

        local pageNames = { "Options", "Messages", "Sharing", "About" }
        local prevBtn
        for _, name in ipairs(pageNames) do
            local btn = CreateFrame("Button", nil, nav, "UIPanelButtonTemplate")
            btn:SetSize(112, 24)
            if prevBtn then
                btn:SetPoint("TOPLEFT", prevBtn, "BOTTOMLEFT", 0, -4)
            else
                btn:SetPoint("TOPLEFT", 8, -8)
            end
            btn:SetText(name)
            btn:SetScript("OnClick", function() SelectPage(name) end)
            navButtons[name] = btn
            prevBtn = btn
        end

        SelectPage("Options")
    end

    frame:Show()
    for k, p in pairs(frame.pages) do
        if p:IsShown() and p.Refresh then
            p.Refresh()
        end
    end
end
