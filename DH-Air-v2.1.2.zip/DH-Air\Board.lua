-- DH-Air Board.lua
-- The Air Service Board: a resizable window showing the shared queue, role
-- registration, and per-row actions. This is the primary interface for
-- anyone running DH-Air - Warlocks, Clickers, or plain members - not a
-- Warlock-only tool. Opened via /dhair board (minimap left-click switches
-- over to this in a later milestone).
--
-- This file is a RENDERING LAYER ONLY. All the actual logic it displays -
-- sort order, permissions, claims, roster counts - already exists and is
-- tested in Queue.lua/Roster.lua/Sync.lua/Core.lua. Board.lua just reads
-- that state and draws it; it never contains its own business logic, so
-- the only genuinely new risk surface here is layout/rendering itself.

local ADDON_NAME, DHAir = ...

local ROW_HEIGHT = 22
local REFRESH_INTERVAL = 1 -- seconds; throttles the live wait-time ticker

-- Column widths/gaps shared between CreateRow (data rows) and the header
-- buttons, so the header always lines up with its column no matter how the
-- window is resized - both are built from these same numbers, right-to-left,
-- rather than the header using independent left-anchored guesses.
local COL_ROLE_WIDTH = 64
local COL_DEST_WIDTH = 110  -- M5: destination column, between name and wait-time
local COL_WAIT_WIDTH = 64
local COL_WHISPER_WIDTH = 56 -- M5: "Whisper" quick action, next to Summon/Invite
local COL_ACTION_WIDTH = 70
local COL_REMOVE_WIDTH = 20
local COL_GAP = 8
local COL_TIGHT_GAP = 4

local frame
local rowPool = {}       -- reusable row frames, grown as needed, never destroyed
local sortKey, sortDir = "wait", "desc"
local lastRefresh = 0

--------------------------------------------------------------------------
-- Small helpers
--------------------------------------------------------------------------

local function FormatWaitTime(seconds)
    seconds = math.max(0, math.floor(seconds))
    return math.floor(seconds / 60) .. "m " .. (seconds % 60) .. "s"
end

-- Returns every queue entry that currently has a live (non-stale) claim on
-- it, i.e. someone is actively working on summoning them right now. Claims
-- are already broadcast/synced, so this reflects ALL Warlocks, not just
-- whichever one happens to be running the local client.
local function GetActiveSummons()
    local active = {}
    for _, entry in ipairs(DHAir.db.queue) do
        if not entry.summoned then
            local claim = DHAir.GetClaim and DHAir:GetClaim(entry.name)
            if claim and not DHAir:IsClaimStale(claim) then
                table.insert(active, { entry = entry, claim = claim })
            end
        end
    end
    return active
end

-- Determines what the row's action button/text should be for this entry.
-- Returns (mode, clickable) where mode is "summon" | "invite" | "notinraid".
local function GetRowAction(entry)
    local unit = DHAir.FindGroupUnitByName and DHAir.FindGroupUnitByName(entry.name)
    if unit then
        return "summon", true
    end
    if DHAir:HasPermission("invite") then
        return "invite", true
    end
    return "notinraid", false
end

--------------------------------------------------------------------------
-- Row pool
--------------------------------------------------------------------------

local function CreateRow(parent, index)
    local row = CreateFrame("Frame", nil, parent)
    row:SetHeight(ROW_HEIGHT)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -(index - 1) * ROW_HEIGHT)
    row:SetPoint("RIGHT", parent, "RIGHT", 0, 0)

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, 0.03) -- faint stripe, alternated on refresh

    row.roleTag = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.roleTag:SetPoint("LEFT", row, "LEFT", 4, 0)
    row.roleTag:SetWidth(COL_ROLE_WIDTH)
    row.roleTag:SetJustifyH("LEFT")

    row.removeBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.removeBtn:SetSize(COL_REMOVE_WIDTH, 18)
    row.removeBtn:SetText("X")
    row.removeBtn:SetPoint("RIGHT", row, "RIGHT", -2, 0)

    -- 2026-08-06 (k-0010): SecureActionButtonTemplate added alongside the
    -- visual skin template - needed so this button can dispatch an
    -- attribute-driven "/target .../cast ..." click for the "summon" mode
    -- below (see RenderRow). Has no effect on "invite" mode, which never
    -- arms the secure attributes and just uses a plain OnClick as before.
    row.actionBtn = CreateFrame("Button", nil, row, "SecureActionButtonTemplate, UIPanelButtonTemplate")
    row.actionBtn:SetSize(COL_ACTION_WIDTH, 18)
    row.actionBtn:SetPoint("RIGHT", row.removeBtn, "LEFT", -COL_TIGHT_GAP, 0)

    row.actionText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.actionText:SetPoint("RIGHT", row.removeBtn, "LEFT", -COL_TIGHT_GAP, 0)
    row.actionText:SetWidth(COL_ACTION_WIDTH)
    row.actionText:SetJustifyH("CENTER")

    -- M5: "Whisper" quick action - anchored off actionBtn (not actionText),
    -- same "two overlapping widgets share one anchor point" trick already
    -- used for actionBtn/actionText themselves, since actionBtn's position
    -- doesn't move depending on which of the two is currently shown.
    row.whisperBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.whisperBtn:SetSize(COL_WHISPER_WIDTH, 18)
    row.whisperBtn:SetPoint("RIGHT", row.actionBtn, "LEFT", -COL_TIGHT_GAP, 0)
    row.whisperBtn:SetText("Whisper")

    row.waitText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.waitText:SetPoint("RIGHT", row.whisperBtn, "LEFT", -COL_GAP, 0)
    row.waitText:SetWidth(COL_WAIT_WIDTH)
    row.waitText:SetJustifyH("RIGHT")

    -- Destination column - a plain read-only label for EVERY row,
    -- including your own. 2026-08-04 (Loopi-reported): this used to be a
    -- clickable UIPanelButtonTemplate button on your own row, opening a
    -- shared dropdown menu (frame.destDropdown) directly from the row -
    -- but that template's default font is larger than GameFontHighlightSmall
    -- (what every other row's plain label uses), so your own row looked
    -- oversized/out of place next to everyone else's. Picking/changing
    -- your own destination now happens through the "Set/Change
    -- Destination" footer button instead (see CreateBoardFrame/
    -- Board_Refresh) - frame.destDropdown itself is unchanged, just
    -- opened from a different place.
    row.destText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.destText:SetPoint("RIGHT", row.waitText, "LEFT", -COL_GAP, 0)
    row.destText:SetWidth(COL_DEST_WIDTH)
    row.destText:SetJustifyH("LEFT")
    -- Truncate long destination labels (engine auto-ellipsis) instead of
    -- letting them overflow past this column into the wait-time column
    -- next to it - same fix already used for DestinationEditor.lua's
    -- labelText/categoryText.
    row.destText:SetWordWrap(false)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("LEFT", row.roleTag, "RIGHT", 4, 0)
    row.nameText:SetPoint("RIGHT", row.destText, "LEFT", -8, 0)
    row.nameText:SetJustifyH("LEFT")

    return row
end

local function AcquireRow(parent, index)
    if not rowPool[index] then
        rowPool[index] = CreateRow(parent, index)
    end
    return rowPool[index]
end

local function HideRowsFrom(startIndex)
    for i = startIndex, #rowPool do
        rowPool[i]:Hide()
    end
end

--------------------------------------------------------------------------
-- Row rendering
--------------------------------------------------------------------------

local function RenderRow(row, entry, index)
    local myName = UnitName("player")
    local isSelf = DHAir:NormalizeName(entry.name) == DHAir:NormalizeName(myName)
    local shortName = DHAir:NormalizeName(entry.name)
    local onlineStatus = DHAir:IsGuildMemberOnline(entry.name) -- true/false/nil(unknown)
    local isOffline = (onlineStatus == false)

    row.bg:SetColorTexture(1, 1, 1, (index % 2 == 0) and 0.03 or 0.0)
    -- 2026-08-04 (one-click auto-summon redesign): gold tint overrides the
    -- normal zebra stripe on whichever row auto-summon has picked and
    -- claimed but not yet cast on (summonState == "ready") - makes it
    -- obvious at a glance which row the footer's "Confirm Summon" button
    -- refers to, without needing to hunt for it.
    if DHAir.summonState == "ready" and DHAir.pendingEntry
        and DHAir:NormalizeName(entry.name) == DHAir:NormalizeName(DHAir.pendingEntry.name) then
        row.bg:SetColorTexture(1, 0.82, 0, 0.18)
    end

    if entry.role == "summoner" then
        row.roleTag:SetText("|cff8888ffSummoner|r")
    elseif entry.role == "clicker" then
        row.roleTag:SetText("|cffffcc66Clicker|r")
    else
        row.roleTag:SetText("")
    end

    local nameDisplay = shortName .. (isSelf and " (you)" or "")
    if isOffline then
        row.nameText:SetText("|cff888888" .. nameDisplay .. "|r")
    else
        row.nameText:SetText(nameDisplay)
    end

    local waitSeconds = GetTime() - (entry.queuedAt or GetTime())
    row.waitText:SetText(FormatWaitTime(waitSeconds))

    -- Destination cell (DH-Air-Destinations-Design.md §5) - plain
    -- read-only label for every row, "-" if undecided. See CreateRow's
    -- comment: picking/changing YOUR OWN destination is now done via the
    -- footer's Set/Change Destination button, not a per-row control.
    local d = entry.destination and DHAir:GetDestination(entry.destination)
    row.destText:SetText(d and d.label or "-")
    row.destText:Show()

    -- Action button/text - hidden for your own row (you don't summon/invite yourself).
    row.actionBtn:Hide()
    row.actionText:Hide()
    row.whisperBtn:Hide()
    row.removeBtn:Show()

    if isSelf then
        row.removeBtn:SetScript("OnClick", function() DHAir:SelfLeaveQueue() ; DHAir:Board_Refresh() end)
    else
        local mode, clickable = GetRowAction(entry)

        if isOffline then
            row.actionText:SetText("offline")
            row.actionText:Show()
        elseif mode == "summon" then
            row.actionBtn:SetText("Summon")
            row.actionBtn:Show()
            -- 2026-08-06 (k-0010): PreClick, not OnClick - TargetUnit/
            -- CastSpellByName can only be dispatched through this button's
            -- OWN secure "type"/"macrotext" attributes, never called
            -- directly from Lua (see Summon.lua's BeginCast comment).
            -- PreClick runs synchronously right before the secure click
            -- dispatch, in the same real click - it calls ManualSummon
            -- (unchanged: permission/claim/state logic, ending in
            -- BeginCast stashing pendingCastUnit), then arms this SAME
            -- click's macro from whatever BeginCast resolved. Clears the
            -- attribute first so a REFUSED ManualSummon (already
            -- summoning, claimed by someone else, etc.) leaves the click
            -- a no-op instead of firing a stale previous target.
            row.actionBtn:SetScript("OnClick", nil)
            row.actionBtn:SetScript("PreClick", function(self)
                self:SetAttribute("type", nil)
                if DHAir.ManualSummon then DHAir:ManualSummon(entry.name) end
                local unit = DHAir.pendingCastUnit
                DHAir.pendingCastUnit = nil
                if unit then
                    self:SetAttribute("type", "macro")
                    self:SetAttribute("macrotext", DHAir:BuildCastMacro(unit))
                end
            end)
        elseif mode == "invite" and clickable then
            row.actionBtn:SetText("Invite")
            row.actionBtn:Show()
            -- Plain OnClick, not a protected action - InviteUnit/
            -- C_PartyInfo.InviteUnit aren't restricted the way
            -- TargetUnit/CastSpellByName are. PreClick explicitly cleared
            -- since this same pooled button may have been in "summon"
            -- mode (with a PreClick script set) on an earlier render.
            row.actionBtn:SetScript("PreClick", nil)
            row.actionBtn:SetAttribute("type", nil)
            row.actionBtn:SetScript("OnClick", function()
                if C_PartyInfo and C_PartyInfo.InviteUnit then
                    C_PartyInfo.InviteUnit(entry.name)
                else
                    InviteUnit(entry.name)
                end
            end)
        else
            row.actionText:SetText("not in raid")
            row.actionText:Show()
        end

        -- M5: "Whisper" quick action - any non-self row that's currently
        -- online (reuses the isOffline check above - unknown status,
        -- like an online row, still gets the button; only a CONFIRMED
        -- offline status hides it).
        if not isOffline then
            row.whisperBtn:Show()
            row.whisperBtn:SetScript("OnClick", function()
                if ChatFrame_SendTell then
                    ChatFrame_SendTell(entry.name)
                end
            end)
        end

        row.removeBtn:SetScript("OnClick", function()
            DHAir:RequestRemove(entry.name)
            DHAir:Board_Refresh()
        end)
        -- Only leader/assist (or self, handled above) can remove someone else.
        if not DHAir:HasPermission("remove_any") then
            row.removeBtn:Hide()
        end
    end

    row:Show()
end

--------------------------------------------------------------------------
-- Full refresh
--------------------------------------------------------------------------

local function UpdateSortHeaderText()
    if not frame then return end
    frame.sortNameBtn:SetText("Name")
    frame.sortDestBtn:SetText("Destination")
    frame.sortWaitBtn:SetText("Waiting")
end

function DHAir:Board_Refresh()
    if not frame or not frame:IsShown() then return end

    frame.statSummoners:SetText("Summoners ready: " .. self:CountRegistered("summoner"))
    frame.statClickers:SetText("Clickers ready: " .. self:CountRegistered("clicker"))
    frame.statQueue:SetText("In queue: " .. #self.db.queue)

    -- "Currently summoning" section - reflects ALL active claims, from any
    -- Warlock, not just this client's own summon state.
    local active = GetActiveSummons()
    if #active > 0 then
        local lines = {}
        for _, a in ipairs(active) do
            table.insert(lines, self:NormalizeName(a.entry.name) .. " |cff888888(by "
                .. self:NormalizeName(a.claim.by) .. ")|r")
        end
        frame.summoningText:SetText(table.concat(lines, "\n"))
        frame.summoningText:Show()
    else
        frame.summoningText:Hide()
    end

    -- Role/join button states.
    local myName = UnitName("player")
    local myEntry = nil
    for _, e in ipairs(self.db.queue) do
        if self:NormalizeName(e.name) == self:NormalizeName(myName) and not e.summoned then
            myEntry = e
            break
        end
    end
    local inQueue = myEntry ~= nil
    frame.joinBtn:SetText(inQueue and "Leave queue" or "Join queue")

    -- Set/Change Destination footer button (2026-08-04, moved off the own
    -- row - see CreateRow/RenderRow) - only meaningful while queued, since
    -- only a queue entry carries a destination field.
    frame.setDestBtn:SetShown(inQueue)
    if inQueue then
        local mine = myEntry.destination and self:GetDestination(myEntry.destination)
        frame.setDestBtn:SetText(mine and ("Change Destination: " .. mine.label) or "Set Destination")
        -- Re-measure every refresh, same idiom autoSummonBtn already uses
        -- below - anchored by "BOTTOM" (see creation), so growing/shrinking
        -- width stays centered instead of drifting into a neighbor button.
        frame.setDestBtn:SetWidth(frame.setDestBtn:GetFontString():GetStringWidth() + 24)
    end

    -- Abort Summon (2026-08-04, Loopi-requested) - only shown while this
    -- client's own summon state machine isn't idle, i.e. there's actually
    -- something to abort (see Summon.lua's AbortSummon).
    frame.abortBtn:SetShown(DHAir.summonState ~= "idle")

    -- Confirm Summon (2026-08-04, one-click auto-summon redesign) - only
    -- shown while auto-summon has picked and claimed someone but hasn't
    -- cast yet (see Summon.lua's BeginCast/ConfirmSummon). Label carries
    -- the target's name so there's no ambiguity about who a click summons.
    if DHAir.summonState == "ready" and DHAir.pendingEntry then
        frame.confirmSummonBtn:SetText("Confirm Summon: " .. self:NormalizeName(DHAir.pendingEntry.name))
        frame.confirmSummonBtn:SetWidth(frame.confirmSummonBtn:GetFontString():GetStringWidth() + 24)
        frame.confirmSummonBtn:Show()
    else
        frame.confirmSummonBtn:Hide()
    end

    frame.summonerCheck:SetChecked(self:IsRegistered("summoner", myName))
    frame.clickerCheck:SetChecked(self:IsRegistered("clicker", myName))
    frame.autoSummonBtn:SetShown(self:IsRegistered("summoner", myName))
    -- 2026-08-03: auto-summon now only matches queue entries sharing the
    -- Warlock's own chosen destination (Summon.lua's QueueNextAvailable) -
    -- gray the button out and explain why rather than letting it claim
    -- "Start auto-summon" when starting would just refuse (see
    -- RequestStartAutoSummon). No dropdown picker here yet (that's Board
    -- UI still pending, M5) - /dhair warlockdest is the interim way to
    -- set it.
    if not self.db.warlockDestination then
        frame.autoSummonBtn:SetEnabled(false)
        frame.autoSummonBtn:SetText("Pick a destination (/dhair warlockdest)")
    else
        frame.autoSummonBtn:SetEnabled(true)
        frame.autoSummonBtn:SetText((self.db.active and not self.db.paused) and "Stop auto-summon" or "Start auto-summon")
    end
    -- Bug fix (2026-07-27, Loopi-reported): the button was a fixed 110px
    -- wide (set at creation, sized for a short placeholder label), but
    -- both real labels - "Start auto-summon" (17 chars) and "Stop
    -- auto-summon" (16 chars) - render wider than that at GameFontNormal,
    -- so the text overran the button's own edges. Re-measure and resize to
    -- fit whichever label is currently showing, every refresh, instead of
    -- guessing a fixed width - same idiom as Config.lua's Mob Marker page
    -- re-measuring its scroll content width on resize. Anchored by its
    -- LEFT edge (see creation comment above), so growing width only
    -- extends rightward and doesn't disturb its position relative to the
    -- summoner checkbox's label.
    frame.autoSummonBtn:SetWidth(frame.autoSummonBtn:GetFontString():GetStringWidth() + 24)

    frame.clearAllBtn:SetShown(self:HasPermission("clear_all"))

    UpdateSortHeaderText()

    -- Row list.
    local ordered = self:SortedQueue(sortKey, sortDir)
    local content = frame.scrollContent
    content:SetWidth(math.max(1, frame.scrollFrame:GetWidth() - 24))

    for i, entry in ipairs(ordered) do
        local row = AcquireRow(content, i)
        RenderRow(row, entry, i)
    end
    HideRowsFrom(#ordered + 1)
    content:SetHeight(math.max(1, #ordered * ROW_HEIGHT))
end

--------------------------------------------------------------------------
-- Frame construction (built once, first time the Board is opened)
--------------------------------------------------------------------------

local function ApplyResizeBounds(f, minW, minH, maxW, maxH)
    if f.SetResizeBounds then
        pcall(f.SetResizeBounds, f, minW, minH, maxW, maxH)
    else
        pcall(f.SetMinResize, f, minW, minH)
        pcall(f.SetMaxResize, f, maxW, maxH)
    end
end

local function CreateBoardFrame()
    frame = CreateFrame("Frame", "DHAirBoardFrame", UIParent, "BasicFrameTemplateWithInset")
    -- M5: default/min width grew to fit the new destination column + Whisper
    -- button (480 -> 580 default, 420 -> 520 min) - see DH-Air-Destinations-Design.md §5.
    frame:SetSize(580, 420)
    frame:SetPoint("CENTER")
    frame:SetResizable(true)
    ApplyResizeBounds(frame, 520, 300, 1000, 700)
    if frame.TitleText then
        frame.TitleText:SetText("DH-Air - Air Service Board")
    end
    tinsert(UISpecialFrames, "DHAirBoardFrame")

    -- Toplevel raising, opaque background, and title-bar-only dragging -
    -- see Core.lua's InitStandaloneWindow for why.
    DHAir:InitStandaloneWindow(frame)

    -- Resize grip (bottom-right corner drag handle).
    local grip = CreateFrame("Button", nil, frame)
    grip:SetSize(16, 16)
    grip:SetPoint("BOTTOMRIGHT", -4, 4)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetScript("OnMouseDown", function() frame:StartSizing("BOTTOMRIGHT") end)
    grip:SetScript("OnMouseUp", function()
        frame:StopMovingOrSizing()
        DHAir:Board_Refresh()
    end)

    -- Stat row.
    frame.statSummoners = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.statSummoners:SetPoint("TOPLEFT", 12, -30)

    frame.statClickers = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.statClickers:SetPoint("LEFT", frame.statSummoners, "RIGHT", 20, 0)

    frame.statQueue = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.statQueue:SetPoint("LEFT", frame.statClickers, "RIGHT", 20, 0)

    -- Action bar - a single container with an EXPLICIT height, so everything
    -- below it anchors to ITS bottom rather than guessing which sub-element
    -- (the join button vs. the two stacked role checkboxes) happens to be
    -- taller. Avoids the checkboxes silently overlapping whatever comes next.
    local actionBar = CreateFrame("Frame", nil, frame)
    actionBar:SetPoint("TOPLEFT", frame.statSummoners, "BOTTOMLEFT", 0, -10)
    actionBar:SetPoint("RIGHT", frame, "RIGHT", -16, 0)
    actionBar:SetHeight(52)

    frame.joinBtn = CreateFrame("Button", nil, actionBar, "UIPanelButtonTemplate")
    frame.joinBtn:SetSize(100, 22)
    frame.joinBtn:SetPoint("TOPLEFT", actionBar, "TOPLEFT", 0, 0)
    frame.joinBtn:SetScript("OnClick", function()
        local myName = UnitName("player")
        local inQueue = false
        for _, e in ipairs(DHAir.db.queue) do
            if DHAir:NormalizeName(e.name) == DHAir:NormalizeName(myName) and not e.summoned then
                inQueue = true
                break
            end
        end
        if inQueue then DHAir:SelfLeaveQueue() else DHAir:SelfJoinQueue() end
        DHAir:Board_Refresh()
    end)

    local roleGroup = CreateFrame("Frame", nil, actionBar)
    roleGroup:SetPoint("TOPLEFT", frame.joinBtn, "TOPRIGHT", 16, 0)
    roleGroup:SetSize(280, 52)

    frame.summonerCheck = CreateFrame("CheckButton", "DHAirBoardSummonerCheck", roleGroup, "UICheckButtonTemplate")
    frame.summonerCheck:SetPoint("TOPLEFT", roleGroup, "TOPLEFT", 0, 0)
    local summonerLabel = _G[frame.summonerCheck:GetName() .. "Text"]
    summonerLabel:SetText("I'm a summoner")
    frame.summonerCheck:SetScript("OnClick", function(self)
        DHAir:SetRole("summoner", self:GetChecked() and true or false)
        DHAir:Board_Refresh()
    end)

    frame.autoSummonBtn = CreateFrame("Button", nil, roleGroup, "UIPanelButtonTemplate")
    frame.autoSummonBtn:SetSize(110, 20)
    -- Anchored to the CHECKBOX'S TEXT LABEL, not the checkbox control itself -
    -- the checkbox's own clickable square is much narrower than its label,
    -- so anchoring to the control alone put this button underneath the words.
    frame.autoSummonBtn:SetPoint("LEFT", summonerLabel, "RIGHT", 10, 0)
    frame.autoSummonBtn:SetScript("OnClick", function()
        if DHAir.db.active and not DHAir.db.paused then
            DHAir.db.paused = true
            DHAir:Print("Auto-summon paused.")
        elseif DHAir:RequestStartAutoSummon() then
            DHAir:Print("Auto-summon started.")
        end
        DHAir:Board_Refresh()
    end)

    frame.clickerCheck = CreateFrame("CheckButton", "DHAirBoardClickerCheck", roleGroup, "UICheckButtonTemplate")
    frame.clickerCheck:SetPoint("TOPLEFT", frame.summonerCheck, "BOTTOMLEFT", 0, -2)
    _G[frame.clickerCheck:GetName() .. "Text"]:SetText("I'm a clicker")
    frame.clickerCheck:SetScript("OnClick", function(self)
        DHAir:SetRole("clicker", self:GetChecked() and true or false)
        DHAir:Board_Refresh()
    end)

    -- Currently-summoning indicator - anchored to actionBar's BOTTOM, not to
    -- any specific button inside it, so it's always correctly positioned
    -- below whichever sub-element ends up tallest.
    frame.summoningText = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    frame.summoningText:SetPoint("TOPLEFT", actionBar, "BOTTOMLEFT", 0, -8)
    frame.summoningText:SetPoint("RIGHT", -16, 0)
    frame.summoningText:SetJustifyH("LEFT")
    frame.summoningText:SetTextColor(1, 0.82, 0)

    -- Scrollable row list. Created BEFORE the column headers, because the
    -- headers below anchor to scrollFrame's own live geometry rather than
    -- using independent fixed offsets - that's what keeps them lined up
    -- with the actual row columns as the window is resized.
    frame.scrollFrame = CreateFrame("ScrollFrame", "DHAirBoardScrollFrame", frame, "UIPanelScrollFrameTemplate")
    frame.scrollFrame:SetPoint("TOPLEFT", frame.summoningText, "BOTTOMLEFT", 0, -32)
    frame.scrollFrame:SetPoint("BOTTOMRIGHT", -30, 40)

    frame.scrollContent = CreateFrame("Frame", nil, frame.scrollFrame)
    frame.scrollContent:SetSize(1, 1)
    frame.scrollFrame:SetScrollChild(frame.scrollContent)

    -- Sortable column headers - anchored to scrollFrame's edges using the
    -- SAME column widths/gaps as CreateRow, so "Name" and "Waiting" always
    -- sit directly above their actual data column, at any window width.
    frame.sortNameBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.sortNameBtn:SetSize(90, 18)
    frame.sortNameBtn:SetPoint("BOTTOMLEFT", frame.scrollFrame, "TOPLEFT", 8 + COL_ROLE_WIDTH, 4)
    frame.sortNameBtn:SetScript("OnClick", function()
        sortDir = (sortKey == "name") and (sortDir == "asc" and "desc" or "asc") or "asc"
        sortKey = "name"
        DHAir:Board_Refresh()
    end)
    -- 2026-08-03 (Loopi-reported): UIPanelButtonTemplate centers its label
    -- by default, so "Name" rendered ~35px right of nameText's actual left
    -- edge even though the BUTTON's own anchor already lined up with it -
    -- re-anchor the button's fontstring to the button's own LEFT edge and
    -- left-justify it, matching nameText:SetJustifyH("LEFT") below.
    local sortNameFS = frame.sortNameBtn:GetFontString()
    sortNameFS:ClearAllPoints()
    sortNameFS:SetPoint("LEFT", frame.sortNameBtn, "LEFT", 0, 0)
    sortNameFS:SetJustifyH("LEFT")

    -- The scrollbar/content inset (24) plus every column that sits to the
    -- right of the wait-time column (remove button, whisper button, action
    -- button, gaps) - matches exactly what Board_Refresh uses to size
    -- scrollContent, and what CreateRow uses to position waitText, so this
    -- can't drift out of sync with either of them. M5 inserted the
    -- whisper button between actionBtn and waitText, so its width/gap are
    -- now part of this inset too.
    local waitColRightInset = 24 + 2 + COL_REMOVE_WIDTH + COL_TIGHT_GAP + COL_ACTION_WIDTH
        + COL_TIGHT_GAP + COL_WHISPER_WIDTH + COL_GAP

    -- 2026-08-03 (Loopi-reported): was a fixed 90px wide, same as every
    -- other header button, even though its actual data column
    -- (waitText) is only COL_WAIT_WIDTH (64) wide. Since this button is
    -- anchored by its RIGHT edge to line up with waitText's right edge,
    -- the extra ~26px of unwarranted width hung off its LEFT side,
    -- overlapping into the Destination column's own header - that's the
    -- "no space between Destination and Waiting" symptom. Sizing this to
    -- the real column width removes the overlap and reproduces the same
    -- COL_GAP the data rows already have between destText and waitText.
    frame.sortWaitBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.sortWaitBtn:SetSize(COL_WAIT_WIDTH, 18)
    frame.sortWaitBtn:SetPoint("BOTTOMRIGHT", frame.scrollFrame, "TOPRIGHT", -waitColRightInset, 4)
    frame.sortWaitBtn:SetScript("OnClick", function()
        sortDir = (sortKey == "wait") and (sortDir == "asc" and "desc" or "asc") or "desc"
        sortKey = "wait"
        DHAir:Board_Refresh()
    end)
    -- waitText itself is right-justified (see CreateRow) - match the
    -- header's text to the same edge instead of UIPanelButtonTemplate's
    -- default centering, so "Waiting" sits directly above the numbers.
    local sortWaitFS = frame.sortWaitBtn:GetFontString()
    sortWaitFS:ClearAllPoints()
    sortWaitFS:SetPoint("RIGHT", frame.sortWaitBtn, "RIGHT", 0, 0)
    sortWaitFS:SetJustifyH("RIGHT")

    -- M5: "Destination" sort header - sits directly left of "Waiting",
    -- same column-width-derived inset trick, extended past waitColRightInset
    -- by the wait column's own width plus one more gap (destText/destBtn
    -- sit immediately left of waitText in CreateRow).
    local destColRightInset = waitColRightInset + COL_WAIT_WIDTH + COL_GAP

    -- 2026-08-03 (Loopi-reported): same root cause as sortWaitBtn above -
    -- fixed 90px instead of the real COL_DEST_WIDTH (110), and centered
    -- text instead of matching destText's own LEFT justify.
    frame.sortDestBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.sortDestBtn:SetSize(COL_DEST_WIDTH, 18)
    frame.sortDestBtn:SetPoint("BOTTOMRIGHT", frame.scrollFrame, "TOPRIGHT", -destColRightInset, 4)
    frame.sortDestBtn:SetScript("OnClick", function()
        sortDir = (sortKey == "dest") and (sortDir == "asc" and "desc" or "asc") or "asc"
        sortKey = "dest"
        DHAir:Board_Refresh()
    end)
    -- destText itself is left-justified (see CreateRow) - match it.
    local sortDestFS = frame.sortDestBtn:GetFontString()
    sortDestFS:ClearAllPoints()
    sortDestFS:SetPoint("LEFT", frame.sortDestBtn, "LEFT", 0, 0)
    sortDestFS:SetJustifyH("LEFT")

    -- Shared dropdown-menu generator for the destination picker, opened
    -- from the footer's Set/Change Destination button (see Board_Refresh/
    -- setDestBtn below) - ONE menu frame, opened via ToggleDropDownMenu
    -- anchored to whatever triggered it, rather than an oversized
    -- UIDropDownMenuTemplate frame embedded in every pooled row.
    -- 2026-08-04 (Loopi-reported, two bugs):
    -- 1) Picking a destination left the parent level (Eastern Kingdoms/
    --    Kalimdor, or Flight Points/Dungeon Stones) still open instead of
    --    closing the whole menu - per Blizzard's own UIDropDownMenu docs,
    --    selecting an item inside a sub-menu only auto-closes THAT level
    --    by default, not its parent(s); every leaf entry below now calls
    --    CloseDropDownMenus() explicitly after picking.
    -- 2) Flight points weren't showing at all (continent submenu opened
    --    empty, or did nothing) - this used to be 3 menu levels deep
    --    (Flight Points -> Eastern Kingdoms/Kalimdor -> actual flight
    --    points), while Dungeon Stones was always only 2 levels and never
    --    had this problem. Flattened Flight Points down to 2 levels to
    --    match: Eastern Kingdoms and Kalimdor are now their own top-level
    --    arrow entries, each opening its destination list directly -
    --    still grouped by continent as Loopi asked for, just without the
    --    extra hop that was breaking.
    frame.destDropdown = CreateFrame("Frame", "DHAirBoardDestDropdown", frame, "UIDropDownMenuTemplate")
    frame.destDropdown:Hide()
    UIDropDownMenu_Initialize(frame.destDropdown, function(selfFrame, level)
        level = level or 1

        if level == 1 then
            local clearInfo = UIDropDownMenu_CreateInfo()
            clearInfo.text = "(pick a destination)"
            clearInfo.value = ""
            clearInfo.func = function()
                DHAir:SetMyDestination("")
                CloseDropDownMenus()
                DHAir:Board_Refresh()
            end
            UIDropDownMenu_AddButton(clearInfo, level)

            local fpEkInfo = UIDropDownMenu_CreateInfo()
            fpEkInfo.text = "Flight Points - Eastern Kingdoms"
            fpEkInfo.notCheckable = true
            fpEkInfo.hasArrow = true
            fpEkInfo.value = "fp_ek"
            UIDropDownMenu_AddButton(fpEkInfo, level)

            local fpKalInfo = UIDropDownMenu_CreateInfo()
            fpKalInfo.text = "Flight Points - Kalimdor"
            fpKalInfo.notCheckable = true
            fpKalInfo.hasArrow = true
            fpKalInfo.value = "fp_kalimdor"
            UIDropDownMenu_AddButton(fpKalInfo, level)

            local ssInfo = UIDropDownMenu_CreateInfo()
            ssInfo.text = "Dungeon Stones"
            ssInfo.notCheckable = true
            ssInfo.hasArrow = true
            ssInfo.value = "summonstones"
            UIDropDownMenu_AddButton(ssInfo, level)

        elseif level == 2 and UIDROPDOWNMENU_MENU_VALUE == "summonstones" then
            for _, d in ipairs(DHAir.db.destinations) do
                -- Disabled destinations stay in the list (see Queue.lua's
                -- SetDestinationEnabled) but aren't offered for a NEW pick -
                -- same rule ApplyDestination itself enforces server-side,
                -- this is just keeping the menu from offering something
                -- it'd refuse.
                if d.category == "summonstone" and d.enabled ~= false then
                    local info = UIDropDownMenu_CreateInfo()
                    info.text = d.label
                    info.value = d.id
                    info.func = function()
                        DHAir:SetMyDestination(d.id)
                        CloseDropDownMenus()
                        DHAir:Board_Refresh()
                    end
                    UIDropDownMenu_AddButton(info, level)
                end
            end

        elseif level == 2 and (UIDROPDOWNMENU_MENU_VALUE == "fp_ek" or UIDROPDOWNMENU_MENU_VALUE == "fp_kalimdor") then
            local continent = (UIDROPDOWNMENU_MENU_VALUE == "fp_ek") and "Eastern Kingdoms" or "Kalimdor"
            for _, d in ipairs(DHAir.db.destinations) do
                if d.category == "flightpoint" and d.continent == continent and d.enabled ~= false then
                    local info = UIDropDownMenu_CreateInfo()
                    info.text = d.label
                    info.value = d.id
                    info.func = function()
                        DHAir:SetMyDestination(d.id)
                        CloseDropDownMenus()
                        DHAir:Board_Refresh()
                    end
                    UIDropDownMenu_AddButton(info, level)
                end
            end
        end
    end)

    -- Footer.
    frame.clearAllBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.clearAllBtn:SetSize(140, 22)
    frame.clearAllBtn:SetPoint("BOTTOMRIGHT", -16, 10)
    frame.clearAllBtn:SetText("Clear entire queue")
    frame.clearAllBtn:SetScript("OnClick", function()
        if DHAir:RequestClearAll() then
            DHAir:Print("Queue cleared for everyone.")
        end
        DHAir:Board_Refresh()
    end)

    -- M4/M5: opens the destinations editor - always visible (everyone can
    -- view the list read-only; the editor itself hides its edit controls
    -- for non-officers, see DestinationEditor.lua).
    frame.destEditorBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.destEditorBtn:SetSize(140, 22)
    frame.destEditorBtn:SetPoint("BOTTOMLEFT", 16, 10)
    frame.destEditorBtn:SetText("Destinations")
    frame.destEditorBtn:SetScript("OnClick", function()
        if DHAir.DestinationEditor_Toggle then
            DHAir:DestinationEditor_Toggle()
        end
    end)

    -- Set/Change Destination (2026-08-04, moved here from a per-row button
    -- on your own queue row - see CreateRow/RenderRow). Centered between
    -- destEditorBtn/clearAllBtn so its width (re-measured every refresh,
    -- see Board_Refresh, same idiom autoSummonBtn already uses) can grow
    -- or shrink symmetrically without creeping into either neighbor. Only
    -- shown while queued - Board_Refresh toggles it.
    frame.setDestBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.setDestBtn:SetSize(140, 22)
    frame.setDestBtn:SetPoint("BOTTOM", frame, "BOTTOM", 0, 10)
    frame.setDestBtn:SetText("Set Destination")
    frame.setDestBtn:SetScript("OnClick", function()
        if frame.destDropdown then
            ToggleDropDownMenu(1, nil, frame.destDropdown, frame.setDestBtn, 0, 0)
        end
    end)

    -- Abort Summon (2026-08-04, Loopi-requested) - force-resets a stuck
    -- summon (see Summon.lua's AbortSummon) without needing a UI reload.
    -- Only shown while there's actually something to abort - Board_Refresh
    -- toggles it based on DHAir.summonState.
    frame.abortBtn = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    frame.abortBtn:SetSize(110, 22)
    frame.abortBtn:SetPoint("TOPRIGHT", actionBar, "TOPRIGHT", 0, 0)
    frame.abortBtn:SetText("Abort Summon")
    frame.abortBtn:Hide()
    frame.abortBtn:SetScript("OnClick", function()
        DHAir:AbortSummon()
        DHAir:Board_Refresh()
    end)

    -- Confirm Summon (2026-08-04, one-click auto-summon redesign) - the
    -- ONE control that actually casts on whoever auto-summon's FIFO
    -- picker chose. WoW's UI security model doesn't let an addon cast a
    -- spell/target a unit without a real click happening at that exact
    -- moment (see Summon.lua's BeginCast comment) - so auto-summon now
    -- auto-PICKS the next eligible person (still respecting destination
    -- matching, claims, everything TrySummonNext already did) and waits
    -- here for one click per summon, instead of trying and silently
    -- failing to cast on its own. Anchored below abortBtn in the same
    -- corner (both can be visible together - "ready" is itself a
    -- non-idle state, so you can Abort a pick you don't want instead of
    -- confirming it). Gold text so it stands out against the rest of the
    -- action bar - this is the button auto-summon exists to make you not
    -- have to hunt for. Text/width re-measured every refresh, same idiom
    -- autoSummonBtn/setDestBtn already use.
    -- 2026-08-06 (k-0010): SecureActionButtonTemplate added, same reason
    -- and same PreClick pattern as Board's row Summon button - see
    -- CreateRow/RenderRow's comments and Summon.lua's BeginCast/
    -- BuildCastMacro.
    frame.confirmSummonBtn = CreateFrame("Button", nil, frame, "SecureActionButtonTemplate, UIPanelButtonTemplate")
    frame.confirmSummonBtn:SetSize(150, 22)
    frame.confirmSummonBtn:SetPoint("TOPRIGHT", frame.abortBtn, "BOTTOMRIGHT", 0, -4)
    frame.confirmSummonBtn:GetFontString():SetTextColor(1, 0.82, 0)
    frame.confirmSummonBtn:Hide()
    frame.confirmSummonBtn:SetScript("PreClick", function(self)
        self:SetAttribute("type", nil)
        DHAir:ConfirmSummon()
        local unit = DHAir.pendingCastUnit
        DHAir.pendingCastUnit = nil
        if unit then
            self:SetAttribute("type", "macro")
            self:SetAttribute("macrotext", DHAir:BuildCastMacro(unit))
        end
    end)
    -- PostClick (after the secure dispatch, not PreClick/before it) so
    -- the refresh reflects the post-cast state (summonState is already
    -- "casting" by then, same as the original OnClick's timing intent).
    frame.confirmSummonBtn:SetScript("PostClick", function()
        DHAir:Board_Refresh()
    end)

    -- Throttled live ticker: keeps wait times counting up and catches any
    -- state changes without needing every mutation point in the addon to
    -- remember to call Board_Refresh() itself.
    frame:SetScript("OnUpdate", function(self, elapsed)
        lastRefresh = lastRefresh + elapsed
        if lastRefresh >= REFRESH_INTERVAL then
            lastRefresh = 0
            DHAir:Board_Refresh()
        end
    end)
end

--------------------------------------------------------------------------
-- Public API
--------------------------------------------------------------------------

function DHAir:Board_Open()
    if not frame then
        CreateBoardFrame()
    end
    frame:Show()
    lastRefresh = REFRESH_INTERVAL -- force an immediate refresh on open
end

function DHAir:Board_Toggle()
    if frame and frame:IsShown() then
        frame:Hide()
    else
        self:Board_Open()
    end
end
