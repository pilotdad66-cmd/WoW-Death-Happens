-- DH-Air Summon.lua
-- Works through the queue: (if sharing) claim the next free player, target,
-- cast Ritual of Summoning, announce, wait for completion/timeout, then
-- advance to the next player.

local ADDON_NAME, DHAir = ...

local SUMMON_SPELL = "Ritual of Summoning"
local SOUL_SHARD_ITEM_ID = 6265
local CLAIM_GRACE_SECONDS = 0.5 -- window to detect a competing claim before actually casting

DHAir.summonState = "idle" -- "idle" | "claiming" | "casting" | "waiting"
DHAir.currentSummon = nil
DHAir.pendingEntry = nil
DHAir.timeoutHandle = nil
DHAir.claimHandle = nil
DHAir.failCount = 0
DHAir.pausedForShards = false -- true only when THIS addon auto-paused for low shards

-- After this many consecutive failures to cast/complete on the SAME target,
-- auto-summon pauses itself with a clear message instead of retrying forever
-- (protects against silently hammering CastSpellByName / spamming chat if
-- e.g. the Warlock is out of range or the target is invalid).
local MAX_CONSECUTIVE_FAILURES = 3
local RETRY_DELAY_SECONDS = 3

--------------------------------------------------------------------------
-- Helpers
--------------------------------------------------------------------------

-- Finds a party/raid unit token matching a queued player's name.
local function FindGroupUnitByName(name)
    local short = name:match("^([^%-]+)") or name

    if IsInRaid() then
        for i = 1, GetNumGroupMembers() do
            local unit = "raid" .. i
            local uName = UnitName(unit)
            if uName == name or uName == short then
                return unit
            end
        end
    elseif IsInGroup() then
        for i = 1, GetNumGroupMembers() do
            local unit = "party" .. i
            local uName = UnitName(unit)
            if uName == name or uName == short then
                return unit
            end
        end
    end
    return nil
end
DHAir.FindGroupUnitByName = FindGroupUnitByName

-- Returns how many Soul Shards the player is carrying, or nil if the count
-- couldn't be determined (in which case callers should fail open rather
-- than blocking the queue over a missing/renamed API).
local function GetShardCount()
    local ok, count = pcall(GetItemCount, SOUL_SHARD_ITEM_ID)
    if ok and type(count) == "number" then
        return count
    end
    return nil
end
DHAir.GetShardCount = GetShardCount

-- Returns the next queue entry that isn't summoned AND (when sharing) isn't
-- freshly claimed by someone else AND (when guildOnly is on) is actually in
-- the player's guild. This is the one place that makes the shared queue
-- actually avoid double-summoning: everyone skips whatever the current,
-- non-stale claim winner is working on.
function DHAir:QueueNextAvailable(sharing)
    local myName = UnitName("player")
    for _, entry in ipairs(self.db.queue) do
        if not entry.summoned and not (self.db.guildOnly and not self:IsGuildMember(entry.name)) then
            if not sharing then
                return entry
            end
            local claim = self:GetClaim(entry.name)
            if not claim or claim.by == myName or self:IsClaimStale(claim) then
                return entry
            end
        end
    end
    return nil
end

-- Substitutes {target} in a message template with the player's name.
function DHAir:BuildMessage(template, targetName)
    template = template or self.DEFAULT_MESSAGE
    return (template:gsub("{target}", targetName))
end

-- Sends the configured message to each enabled channel that currently applies.
function DHAir:Announce(targetName)
    local msgs = self.db.messages

    if msgs.raid.enabled and IsInRaid() then
        SendChatMessage(self:BuildMessage(msgs.raid.text, targetName), "RAID")
    end

    if msgs.party.enabled and IsInGroup() and not IsInRaid() then
        SendChatMessage(self:BuildMessage(msgs.party.text, targetName), "PARTY")
    end

    if msgs.guild.enabled and IsInGuild() then
        SendChatMessage(self:BuildMessage(msgs.guild.text, targetName), "GUILD")
    end

    if msgs.say.enabled then
        SendChatMessage(self:BuildMessage(msgs.say.text, targetName), "SAY")
    end
end

function DHAir:CancelTimeout()
    if self.timeoutHandle then
        self.timeoutHandle:Cancel()
        self.timeoutHandle = nil
    end
end

function DHAir:CancelClaimTimer()
    if self.claimHandle then
        self.claimHandle:Cancel()
        self.claimHandle = nil
    end
end

--------------------------------------------------------------------------
-- Core loop
--------------------------------------------------------------------------

-- Called after a summon finishes successfully or times out (i.e. NOT a
-- cast failure) to move on to the next player in the queue.
function DHAir:AdvanceQueue()
    self:CancelTimeout()
    self:CancelClaimTimer()
    self.summonState = "idle"
    self.currentSummon = nil
    self.pendingEntry = nil
    self.failCount = 0
    self:TrySummonNext()
end

-- Called whenever the ritual fails to start or is interrupted. Retries the
-- SAME target (a few times, with a short delay) rather than skipping them,
-- since these are usually transient (out of range, briefly out of combat
-- restriction, etc). After too many consecutive failures it stops itself
-- with a clear message instead of retrying forever, and - if sharing - lets
-- go of its claim so another Warlock can pick the target up.
function DHAir:HandleSummonFailure(reason)
    self:CancelTimeout()
    self.summonState = "idle"
    self.failCount = (self.failCount or 0) + 1

    local rawName = self.currentSummon
    local name = rawName and self:NormalizeName(rawName) or "target"

    if self.failCount >= MAX_CONSECUTIVE_FAILURES then
        self.db.paused = true
        self:Print("Auto-summon paused after " .. self.failCount .. " failed attempts to summon "
            .. name .. " (" .. reason .. "). Check your range/target, then /dhair resume.")
        if rawName and self.ReleaseClaim then
            self:ReleaseClaim(rawName) -- let another Warlock take over, since we're giving up
        end
        self.currentSummon = nil
        self.pendingEntry = nil
        self.failCount = 0
        return
    end

    self:Print(reason .. " for " .. name .. " (attempt " .. self.failCount .. "/"
        .. MAX_CONSECUTIVE_FAILURES .. "). Retrying in " .. RETRY_DELAY_SECONDS .. "s...")

    -- Still holding the claim during these quick retries - no need to
    -- release/re-claim over a few-second hiccup.
    C_Timer.NewTimer(RETRY_DELAY_SECONDS, function()
        DHAir.summonState = "idle"
        DHAir:BeginCast()
    end)
end

-- Attempts to start the next summon in the queue, if conditions allow.
-- Safe to call repeatedly (e.g. from GROUP_ROSTER_UPDATE) - it no-ops
-- unless the addon is active, not paused, and idle.
function DHAir:TrySummonNext()
    if not self.db then return end
    if not self.db.active then return end
    if self.db.paused then return end
    if self.summonState ~= "idle" then return end

    local sharing = self.Sync_IsActive and self:Sync_IsActive()
    local entry = self:QueueNextAvailable(sharing)
    if not entry then return end

    local minShards = self.db.minShards or 2
    local shardCount = GetShardCount()
    if shardCount ~= nil and shardCount < minShards then
        self.db.paused = true
        self.pausedForShards = true
        self:Print("Auto-summon paused: only " .. shardCount .. " Soul Shard"
            .. (shardCount == 1 and "" or "s") .. " left (need at least " .. minShards
            .. "). Restock Soul Shards - I'll resume automatically, or use /dhair resume.")
        return
    end

    self.currentSummon = entry.name
    self.pendingEntry = entry

    if sharing then
        local myName = UnitName("player")
        self.summonState = "claiming"
        self:StoreClaim(entry.name, myName)
        self:Sync_Send("CLAIM", entry.name .. "|" .. myName)
        self.claimHandle = C_Timer.NewTimer(CLAIM_GRACE_SECONDS, function()
            DHAir:ResolveClaimAndCast()
        end)
    else
        self:BeginCast()
    end
end

-- Fires after the claim grace window elapses. If we still hold the
-- deterministic tie-break for this player, proceed to actually target and
-- cast; otherwise back off and let TrySummonNext pick a different target.
function DHAir:ResolveClaimAndCast()
    self.claimHandle = nil
    if self.summonState ~= "claiming" then return end -- already handled (e.g. lost the race earlier)

    local name = self.currentSummon
    local claim = self:GetClaim(name)
    local myName = UnitName("player")

    if not claim or claim.by ~= myName then
        self.summonState = "idle"
        self.currentSummon = nil
        self.pendingEntry = nil
        self:TrySummonNext()
        return
    end

    self:BeginCast()
end

-- Targets and casts on self.pendingEntry. Assumes currentSummon/pendingEntry
-- are already set by the caller (TrySummonNext, ResolveClaimAndCast, or a
-- failure retry timer).
function DHAir:BeginCast()
    local entry = self.pendingEntry
    if not entry then
        self.summonState = "idle"
        return
    end

    local unit = FindGroupUnitByName(entry.name)
    if not unit then
        -- Player queued (e.g. via whisper) but not yet showing in the
        -- group roster. GROUP_ROSTER_UPDATE will retry this shortly.
        if self.ReleaseClaim then
            self:ReleaseClaim(entry.name)
        end
        self.summonState = "idle"
        self.currentSummon = nil
        self.pendingEntry = nil
        return
    end

    TargetUnit(unit)
    if not UnitExists("target") then
        if self.ReleaseClaim then
            self:ReleaseClaim(entry.name)
        end
        self.summonState = "idle"
        self.currentSummon = nil
        self.pendingEntry = nil
        return
    end

    self.summonState = "casting"

    local ok = pcall(CastSpellByName, SUMMON_SPELL)
    if not ok then
        self:HandleSummonFailure("Could not cast " .. SUMMON_SPELL .. " (need a Soul Shard and to be a Warlock)")
        return
    end

    -- NOTE: pcall succeeding only means the Lua call itself didn't error -
    -- it does NOT guarantee the ritual actually started (e.g. insufficient
    -- mana or an invalid target fail asynchronously via UNIT_SPELLCAST_FAILED
    -- without erroring here). So we stay in "casting" and wait for the game
    -- to confirm via UNIT_SPELLCAST_SUCCEEDED before announcing or starting
    -- the completion timeout - otherwise a real failed cast would go
    -- unnoticed for the full timeout and then be wrongly marked as summoned.
end

-- Called on BAG_UPDATE. Only takes action if THIS addon paused things for
-- low shards (never touches a manual /dhair pause) - once restocked above
-- the threshold, resumes automatically so the Warlock doesn't have to
-- remember to type /dhair resume mid-run.
function DHAir:OnBagUpdate()
    if not self.db then return end
    if not self.db.paused or not self.pausedForShards then return end

    local minShards = self.db.minShards or 2
    local shardCount = GetShardCount()
    if shardCount ~= nil and shardCount >= minShards then
        self.db.paused = false
        self.pausedForShards = false
        self:Print("Soul Shards restocked (" .. shardCount .. "). Resuming auto-summon.")
        self:TrySummonNext()
    end
end

--------------------------------------------------------------------------
-- Spellcast event handling
--------------------------------------------------------------------------

-- Called from Core.lua's dispatcher for UNIT_SPELLCAST_* events.
function DHAir:OnSpellcastEvent(event, unit, ...)
    if unit ~= "player" then return end
    if self.summonState ~= "casting" and self.summonState ~= "waiting" then return end

    local spellName
    local castGUID, spellID = ...
    if spellID then
        spellName = GetSpellInfo(spellID)
    end

    if event == "UNIT_SPELLCAST_SUCCEEDED" then
        if spellName == SUMMON_SPELL and self.summonState == "casting" then
            self.failCount = 0 -- the ritual actually started fine; forget past retries

            local entry = self.pendingEntry
            local rawName = self.currentSummon or (entry and entry.name)
            local shortName = self:NormalizeName(rawName or "target")

            self:Announce(shortName)
            self:Print("Summoning " .. shortName .. "...")

            self.summonState = "waiting"
            self.timeoutHandle = C_Timer.NewTimer(self.db.summonTimeout or 30, function()
                DHAir:Print(shortName .. " summon timed out, moving to the next player.")
                if entry then
                    DHAir:QueueMarkSummoned(entry.name)
                    if DHAir.ClearClaim then DHAir:ClearClaim(entry.name) end
                    if DHAir.Sync_BroadcastSummoned then DHAir:Sync_BroadcastSummoned(entry.name) end
                end
                DHAir:AdvanceQueue()
            end)
        end
    elseif event == "UNIT_SPELLCAST_FAILED" or event == "UNIT_SPELLCAST_INTERRUPTED" then
        -- Only bail out early if we're still in the casting stage (the ritual
        -- itself failed/was interrupted before completing).
        if self.summonState == "casting" and (spellName == SUMMON_SPELL or spellName == nil) then
            local reason = (event == "UNIT_SPELLCAST_FAILED") and "Summon ritual failed" or "Summon ritual was interrupted"
            self:HandleSummonFailure(reason)
        end
    end
end
