-- DH-Air Minimap.lua
-- Standard LibDataBroker-1.1 / LibDBIcon-1.0 minimap button (CurseForge-compliant).
-- Left-click: toggle auto-summon on/off (auto-invite keeps working either way).
-- Right-click: menu with Config / Pause-Resume / Reset Session.

local ADDON_NAME, DHAir = ...

local LDB = LibStub("LibDataBroker-1.1")
local LDBIcon = LibStub("LibDBIcon-1.0")

-- Same icon the game uses for the Warlock spell Ritual of Summoning.
local SUMMON_ICON = "Interface\\Icons\\Spell_Shadow_Twilight"

local dataObject = LDB:NewDataObject("DHAir", {
    type = "launcher",
    text = "DH-Air",
    icon = SUMMON_ICON,
    OnClick = function(_, buttonPressed)
        if buttonPressed == "LeftButton" then
            DHAir.db.active = not DHAir.db.active
            if DHAir.db.active then
                DHAir:Print("Auto-summon turned ON.")
                DHAir:TrySummonNext()
            else
                DHAir:Print("Auto-summon turned OFF (auto-invite still active).")
            end
            DHAir.Minimap_UpdateIcon()
        elseif buttonPressed == "RightButton" then
            DHAir:Minimap_ShowMenu()
        end
    end,
    OnTooltipShow = function(tooltip)
        if not tooltip or not tooltip.AddLine then return end
        tooltip:AddLine("DH-Air")
        tooltip:AddLine(" ")
        tooltip:AddLine("Left-click: turn auto-summon " .. (DHAir.db.active and "|cffff0000off|r" or "|cff00ff00on|r"))
        tooltip:AddLine("Right-click: menu")
        tooltip:AddLine(" ")
        tooltip:AddLine("Auto-invite: " .. (DHAir.db.autoInvite and "|cff00ff00ON|r" or "|cffff0000OFF|r"))
        local status = DHAir.db.paused and "|cffffff00Paused|r"
            or (DHAir.db.active and "|cff00ff00Active|r" or "|cffff0000Stopped|r")
        tooltip:AddLine("Status: " .. status)
    end,
})

function DHAir.Minimap_UpdateIcon()
    -- LibDBIcon doesn't recolor icons itself; dim the icon when auto-summon is off
    -- so the minimap button visually reflects state at a glance.
    dataObject.iconR = DHAir.db.active and 1 or 0.5
    dataObject.iconG = DHAir.db.active and 1 or 0.5
    dataObject.iconB = DHAir.db.active and 1 or 0.5
end

local menuFrame

function DHAir:Minimap_ShowMenu()
    if not menuFrame then
        menuFrame = CreateFrame("Frame", "DHAirMinimapMenu", UIParent, "UIDropDownMenuTemplate")
    end

    local menu = {
        { text = "DH-Air", isTitle = true, notCheckable = true },
        { text = "Open Config", notCheckable = true, func = function() DHAir:Config_Open() end },
        {
            text = (DHAir.db.paused and "Resume Auto-Summon" or "Pause Auto-Summon"),
            notCheckable = true,
            func = function()
                DHAir.db.paused = not DHAir.db.paused
                DHAir:Print(DHAir.db.paused and "Auto-summon paused." or "Auto-summon resumed.")
                if not DHAir.db.paused then
                    DHAir:TrySummonNext()
                end
            end,
        },
        { text = "Reset Queue/Session", notCheckable = true, func = function() DHAir:QueueReset() end },
        { text = "Cancel", notCheckable = true },
    }

    EasyMenu(menu, menuFrame, "cursor", 0, 0, "MENU")
end

function DHAir.Minimap_Init()
    LDBIcon:Register("DHAir", dataObject, DHAir.db.minimap)
    DHAir.Minimap_UpdateIcon()
end
