-- DH-Air Commands.lua
-- /dhair start | stop | pause | resume | reset | queue | invite on|off | config | help

local ADDON_NAME, DHAir = ...

local function PrintHelp()
    DHAir:Print("Commands:")
    DHAir:Print("  /dhair start   - enable auto-summon")
    DHAir:Print("  /dhair stop    - disable auto-summon (auto-invite keeps working)")
    DHAir:Print("  /dhair pause   - pause auto-summon")
    DHAir:Print("  /dhair resume  - resume auto-summon")
    DHAir:Print("  /dhair reset   - clear the summon queue and session (shared with other DH-Air Warlocks)")
    DHAir:Print("  /dhair queue   - list the current summon queue")
    DHAir:Print("  /dhair shards  - show your current Soul Shard count")
    DHAir:Print("  /dhair share on|off - toggle sharing the queue with other DH-Air Warlocks")
    DHAir:Print("  /dhair peers   - list other DH-Air Warlocks seen recently")
    DHAir:Print("  /dhair sync    - re-request the shared queue from other DH-Air Warlocks")
    DHAir:Print("  /dhair invite on|off - toggle auto-invite")
    DHAir:Print("  /dhair guildonly on|off - only auto-invite/summon guild members")
    DHAir:Print("  /dhair config  - open the configuration window")
end

SLASH_DHAIR1 = "/dhair"
SlashCmdList["DHAIR"] = function(msg)
    msg = (msg or ""):lower():gsub("^%s+", ""):gsub("%s+$", "")
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")

    if cmd == "start" then
        DHAir.db.active = true
        DHAir.db.paused = false
        DHAir.pausedForShards = false
        DHAir.failCount = 0
        DHAir:Print("Auto-summon started.")
        if DHAir.Minimap_UpdateIcon then DHAir.Minimap_UpdateIcon() end
        DHAir:TrySummonNext()

    elseif cmd == "stop" then
        DHAir.db.active = false
        DHAir:Print("Auto-summon stopped. Auto-invite is still active.")
        if DHAir.Minimap_UpdateIcon then DHAir.Minimap_UpdateIcon() end

    elseif cmd == "pause" then
        DHAir.db.paused = true
        DHAir.pausedForShards = false -- this is an explicit manual pause; don't let restocking auto-resume it
        DHAir:Print("Auto-summon paused.")

    elseif cmd == "resume" then
        DHAir.db.paused = false
        DHAir.pausedForShards = false
        DHAir.failCount = 0
        DHAir:Print("Auto-summon resumed.")
        DHAir:TrySummonNext()

    elseif cmd == "reset" then
        local sharing = DHAir.Sync_IsActive and DHAir:Sync_IsActive()
        DHAir:QueueReset()
        if sharing then
            DHAir:Print("Resetting the shared Air Service queue for the whole raid.")
            DHAir:Sync_BroadcastReset()
        end

    elseif cmd == "queue" or cmd == "list" then
        DHAir:QueueList()

    elseif cmd == "shards" then
        local count = DHAir.GetShardCount and DHAir.GetShardCount()
        if count then
            DHAir:Print("Soul Shards: " .. count .. " (minimum to keep summoning: "
                .. (DHAir.db.minShards or 2) .. ")")
        else
            DHAir:Print("Could not determine Soul Shard count.")
        end

    elseif cmd == "share" then
        if rest == "on" then
            DHAir.db.shareQueue = true
            DHAir:Print("Queue sharing enabled. Requesting the current shared queue...")
            if DHAir.Sync_Init then DHAir:Sync_Init() end
        elseif rest == "off" then
            DHAir.db.shareQueue = false
            DHAir:Print("Queue sharing disabled - your queue is now private to you.")
        else
            DHAir:Print("Usage: /dhair share on|off")
        end

    elseif cmd == "peers" then
        if DHAir.PrintPeers then DHAir:PrintPeers() end

    elseif cmd == "sync" then
        if DHAir.Sync_IsActive and DHAir:Sync_IsActive() then
            DHAir:Print("Requesting the current shared queue from other DH-Air Warlocks...")
            DHAir:Sync_Send("SYNCREQ")
        else
            DHAir:Print("Queue sharing is off or you're not in a group.")
        end

    elseif cmd == "config" or cmd == "options" then
        DHAir:Config_Open()

    elseif cmd == "invite" then
        if rest == "on" then
            DHAir.db.autoInvite = true
            DHAir:Print("Auto-invite enabled.")
        elseif rest == "off" then
            DHAir.db.autoInvite = false
            DHAir:Print("Auto-invite disabled.")
        else
            DHAir:Print("Usage: /dhair invite on|off")
        end

    elseif cmd == "guildonly" then
        if rest == "on" then
            DHAir.db.guildOnly = true
            DHAir:Print("Guild members only: ON. Non-guild whispers/queue entries will be ignored.")
            if DHAir.RequestGuildRoster then DHAir:RequestGuildRoster() end
        elseif rest == "off" then
            DHAir.db.guildOnly = false
            DHAir:Print("Guild members only: OFF.")
        else
            DHAir:Print("Usage: /dhair guildonly on|off")
        end

    else
        PrintHelp()
    end
end
