-- DH-Air Queue.lua
-- Manages the ordered summon queue and per-session summon history.

local ADDON_NAME, DHAir = ...

-- Strips a "-Realm" suffix for display / comparison purposes.
function DHAir:NormalizeName(name)
    if not name then return name end
    return name:match("^([^%-]+)") or name
end

-- Adds a player to the bottom of the queue. Returns true if added.
function DHAir:QueueAdd(name)
    if not name or name == "" then return false end
    local db = self.db
    local short = self:NormalizeName(name)

    for _, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            return false -- already queued
        end
    end

    if db.history[short] then
        return false -- already summoned this session, don't re-queue
    end

    table.insert(db.queue, { name = name, summoned = false })
    self:Print(short .. " added to the summon queue (position " .. #db.queue .. ").")

    if self.TrySummonNext then
        self:TrySummonNext()
    end

    return true
end

-- Returns the first not-yet-summoned entry, or nil.
function DHAir:QueueNext()
    for _, entry in ipairs(self.db.queue) do
        if not entry.summoned then
            return entry
        end
    end
    return nil
end

-- Marks a queued player as summoned and records them in session history.
function DHAir:QueueMarkSummoned(name)
    local db = self.db
    local short = self:NormalizeName(name)
    for _, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            entry.summoned = true
        end
    end
    db.history[short] = true
end

-- Removes a player from the queue entirely (does not touch history).
function DHAir:QueueRemove(name)
    local db = self.db
    local short = self:NormalizeName(name)
    for i, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            table.remove(db.queue, i)
            return true
        end
    end
    return false
end

-- Clears the queue and the session history (fresh Air Service session).
function DHAir:QueueReset()
    self.db.queue = {}
    self.db.history = {}
    if self.CancelTimeout then
        self:CancelTimeout()
    end
    self.summonState = "idle"
    self.currentSummon = nil
    self.pendingEntry = nil
    self.failCount = 0
    self.pausedForShards = false
    if self.claims then
        self.claims = {}
    end
    if self.syncBuffers then
        self.syncBuffers = {}
    end
    self:Print("Summon queue and session have been reset.")
end

-- Prints the current queue state to chat.
function DHAir:QueueList()
    local db = self.db
    if #db.queue == 0 then
        self:Print("Summon queue is empty.")
        return
    end
    self:Print("Current summon queue:")
    for i, entry in ipairs(db.queue) do
        local status = entry.summoned and "|cff00ff00(summoned)|r" or "|cffffff00(waiting)|r"
        self:Print(i .. ". " .. self:NormalizeName(entry.name) .. " " .. status)
    end
end
