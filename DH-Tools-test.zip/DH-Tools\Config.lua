-- DH-Tools: Config.lua
-- /dht config window: left-hand page list (Tools, Mob Marker, About) + right
-- content pane. Mirrors DH-Air's Config.lua nav pattern.
--
-- 2026-07-17 decision (Chris): instead of Mob Marker's original two separate
-- pages (Target Icons, Options/hotkey settings - see the ported source in
-- src\HCMobMarker-v2.0.zip's Options.lua), this combines them into ONE
-- scrollable "Mob Marker" page - icons on top, settings below - so the
-- target icon list is reachable in one click instead of two. "Tools" is the
-- new top-level page (module on/off checklist). Layout pixel values below
-- are a best-effort port, unverified in-game - see claude\DH-Tools\STATUS.md.

local ADDON_NAME = ...
local DHTools = DHTools

local frame
local navButtons = {}

--------------------------------------------------------------------------
-- Tools page - master module on/off checklist
--------------------------------------------------------------------------

-- Detects whether another addon exists in this client's AddOns folder at
-- all, regardless of whether it's currently enabled/loaded this session -
-- GetAddOnInfo (unlike IsAddOnLoaded) still finds a disabled addon, which
-- is the right check for "is it installed" rather than "is it active right
-- now." WoW moved this into the C_AddOns namespace at some point; try that
-- first and fall back to the bare global for older/Classic clients - same
-- defensive fallback pattern already used below for SetResizeBounds vs.
-- SetMinResize/SetMaxResize.
local function IsAddOnInstalled(name)
    local getInfo = (C_AddOns and C_AddOns.GetAddOnInfo) or GetAddOnInfo
    if not getInfo then return false end
    local ok, addonName = pcall(getInfo, name)
    return ok and addonName ~= nil
end

-- 2026-07-17 decision (Chris): DH-Air stays a separate, standalone addon -
-- it will NOT become a DH-Tools module. Its row below is a status
-- indicator, not a real toggle (DH-Tools has nothing to enable/disable for
-- a foreign addon - that lives in WoW's own AddOns list), driven by
-- IsAddOnInstalled("DH-Air"): active/checked if it's installed, greyed out
-- with an install-it-separately note if not. DH-Layers has no
-- checkInstalled - there's no code or addon for it to detect at all yet,
-- so it stays a plain "coming soon" placeholder. Neither has a
-- DHTools.RegisterModule entry. Move an entry out of this list entirely
-- if it ever DOES become a real DH-Tools module.
local PLACEHOLDER_MODULES = {
    {
        label = "DH-Air",
        checkInstalled = function() return IsAddOnInstalled("DH-Air") end,
        installedDesc = "Warlock/guild Air Service - auto-invite and auto-summon players in queue order. Runs as its own separate addon.",
        desc = "Warlock/guild Air Service summon coordination. Must be installed separately - it is not bundled into DH-Tools.",
        tag = false, -- no "(coming soon)" - it already exists and is actively developed, just not installed on this client
    },
    {
        label = "DH-Layers",
        desc = "Shows your current WoW layer in a minimap-corner box.",
    },
}

local function CreateToolsPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Modules")

    local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    hint:SetPoint("RIGHT", -16, 0)
    hint:SetJustifyH("LEFT")
    hint:SetWordWrap(true)
    hint:SetText("Turn individual DH-Tools modules on or off. Each module keeps its own slash commands and settings regardless of this switch. Greyed-out rows aren't built yet.")

    -- Built once - moduleOrder is final by the time this page is first
    -- opened (all modules register at file-load time, long before any
    -- slash command can run), and PLACEHOLDER_MODULES is a static list.
    --
    -- Every row anchors to the SAME fixed baseline (hint), not to the
    -- previous row's description - each at its own absolute Y offset
    -- computed from rowNum. (Bug fixed 2026-07-17: anchoring row N to row
    -- N-1's description, which is itself offset +22 from its checkbox to
    -- sit under the label, made every row inherit the accumulated +22 x
    -- drift from all rows before it - row 2 sat 22px right of row 1, row 3
    -- 44px right, etc. Same fixed-baseline fix DH-Air's Messages panel
    -- already uses for its channel rows, for the same reason.)
    -- 56 = enough vertical room for a checkbox (~32px tall for
    -- UICheckButtonTemplate) + the 2px gap before its description + a
    -- single line of GameFontDisableSmall text (~14px) + a few px of
    -- breathing room before the next row starts. 36 (the previous value)
    -- wasn't enough - row N's checkbox started before row N-1's
    -- description had finished, so it crowded/overlapped that text.
    local ROW_BLOCK_HEIGHT = 56 -- vertical space per row: checkbox + its description line
    local checks = {}
    local rowNum = 0

    -- Adds one row (checkbox + a small description line below it).
    -- comingSoon greys out and disables the checkbox; tag controls the
    -- "(...)" label suffix shown in that greyed state - defaults to
    -- "coming soon" but pass tag=false to suppress it entirely (e.g.
    -- DH-Air already exists and is actively developed, just not installed
    -- on this client - "coming soon" would be misleading there) or a
    -- custom string for something else.
    -- Returns the checkbox so callers can wire it up further.
    local function AddRow(labelText, descText, comingSoon, tag)
        rowNum = rowNum + 1
        local yOffset = -14 - (rowNum - 1) * ROW_BLOCK_HEIGHT

        local check = CreateFrame("CheckButton", "DHToolsToolsCheck" .. rowNum, panel, "UICheckButtonTemplate")
        check:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, yOffset)
        local checkText = _G[check:GetName() .. "Text"]

        if comingSoon then
            if tag == false then
                checkText:SetText(labelText)
            else
                checkText:SetText(labelText .. "  |cff888888(" .. (tag or "coming soon") .. ")|r")
            end
            checkText:SetTextColor(0.5, 0.5, 0.5)
            check:SetChecked(false)
            check:Disable()
        else
            checkText:SetText(labelText)
        end

        local desc = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
        desc:SetPoint("TOPLEFT", check, "BOTTOMLEFT", 22, -2)
        desc:SetPoint("RIGHT", -16, 0)
        desc:SetJustifyH("LEFT")
        desc:SetText(descText or "")

        return check
    end

    for _, key in ipairs(DHTools.moduleOrder) do
        local def = DHTools.modules[key]
        local check = AddRow(def.name, def.desc, false)
        check:SetScript("OnClick", function(self)
            DHTools.SetModuleEnabled(key, self:GetChecked() and true or false)
        end)
        checks[key] = check
    end

    for _, ph in ipairs(PLACEHOLDER_MODULES) do
        local installed = ph.checkInstalled and ph.checkInstalled()
        if installed then
            local check = AddRow(ph.label, ph.installedDesc or ph.desc, false)
            check:SetChecked(true)
            -- Status indicator, not a real toggle - there's nothing in
            -- DH-Tools to enable/disable for a separate addon. Revert any
            -- click back to checked rather than leaving it in a confusing
            -- half-toggled state (same "reassert truth" idiom DH-Air's
            -- Board.lua uses for its own authoritative checkboxes).
            check:SetScript("OnClick", function(self) self:SetChecked(true) end)
        else
            AddRow(ph.label, ph.desc, true, ph.tag)
        end
    end

    panel.Refresh = function()
        for key, check in pairs(checks) do
            check:SetChecked(DHTools.IsModuleEnabled(key))
        end
    end

    return panel
end

--------------------------------------------------------------------------
-- Mob Marker page - Target Icons (top) + Settings (bottom), one scrollable
-- page. Target-icon editing ported from src\HCMobMarker-v2.0.zip's
-- Options.lua ("targets" page): edit-then-commit via an Update button, a
-- working[] copy separate from the saved DB until you click it. Settings
-- (hotkey) ported from that same file's "options" page: writes live, no
-- Update needed - preserved as-is, just relocated below the icon list.
--------------------------------------------------------------------------

local MM_ROW_COUNT = 8
local MM_ROW_HEIGHT = 30
local mmRows = {}    -- UI widgets per target-icon row, indexed 1-8
local mmWorking = {} -- mmWorking[i] = { name = "", icon = N } (edit-session copy)

local MODIFIER_OPTIONS = {
    { label = "None", value = "NONE" },
    { label = "Ctrl", value = "CTRL" },
    { label = "Alt", value = "ALT" },
    { label = "Shift", value = "SHIFT" },
}
local BUTTON_OPTIONS = {
    { label = "Left Click", value = "LeftButton" },
    { label = "Right Click", value = "RightButton" },
    { label = "Middle Click", value = "MiddleButton" },
}

local function MM_GetUsedIconsExcluding(excludeRow1, excludeRow2)
    local used = {}
    for i = 1, MM_ROW_COUNT do
        if i ~= excludeRow1 and i ~= excludeRow2 then
            used[mmWorking[i].icon] = true
        end
    end
    return used
end

local function MM_PickRandomUnused(excluding)
    local pool = {}
    for i = 1, MM_ROW_COUNT do
        if not excluding[i] then
            table.insert(pool, i)
        end
    end
    if #pool == 0 then return nil end
    return pool[math.random(#pool)]
end

local function MM_RefreshRowVisual(i)
    local MM = DHTools.MobMarker
    local row, w = mmRows[i], mmWorking[i]
    row.icon:SetTexture(MM.ICON_PATH .. w.icon)
    UIDropDownMenu_SetSelectedValue(row.dropdown, w.icon)
    UIDropDownMenu_SetText(row.dropdown, MM.ICON_LABELS[w.icon])
    if row.edit:GetText() ~= w.name then
        row.edit:SetText(w.name)
    end
end

-- Assigns newIcon to row i. Every row -- blank or not -- always holds a
-- unique icon, so if another row already has newIcon, that row is bumped to
-- a random unused one, regardless of whether it currently has a mob name.
local function MM_SetRowIcon(i, newIcon)
    for j = 1, MM_ROW_COUNT do
        if j ~= i and mmWorking[j].icon == newIcon then
            local used = MM_GetUsedIconsExcluding(i, j)
            used[newIcon] = true
            local pick = MM_PickRandomUnused(used)
            if pick then
                mmWorking[j].icon = pick
                MM_RefreshRowVisual(j)
            end
            break
        end
    end
    mmWorking[i].icon = newIcon
    MM_RefreshRowVisual(i)
end

local function CreateMobMarkerPanel(parent)
    local MM = DHTools.MobMarker

    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local scrollFrame = CreateFrame("ScrollFrame", "DHToolsMobMarkerScroll", panel, "UIPanelScrollFrameTemplate")
    scrollFrame:SetPoint("TOPLEFT", 0, -8)
    scrollFrame:SetPoint("BOTTOMRIGHT", -8, 8)

    local content = CreateFrame("Frame", nil, scrollFrame)
    content:SetSize(1, 640) -- width set in Refresh; height is a generous fixed
                             -- estimate for this page's fixed content - pad
                             -- rather than trim if it's off, see STATUS.md.
    scrollFrame:SetScrollChild(content)

    -- === Target Icons section ===
    local secTitle1 = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    secTitle1:SetPoint("TOPLEFT", 8, -8)
    secTitle1:SetText("Target Icons")

    local colMob = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    colMob:SetPoint("TOPLEFT", secTitle1, "BOTTOMLEFT", 26, -10)
    colMob:SetText("Mob Name")

    local colIcon = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    colIcon:SetPoint("TOPLEFT", secTitle1, "BOTTOMLEFT", 226, -10)
    colIcon:SetText("Icon")

    for i = 1, MM_ROW_COUNT do
        local y = -26 - (i - 1) * MM_ROW_HEIGHT
        local row = {}

        row.icon = content:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(20, 20)
        row.icon:SetPoint("TOPLEFT", secTitle1, "BOTTOMLEFT", 8, y)

        local edit = CreateFrame("EditBox", "DHToolsMMRow" .. i .. "Edit", content, "InputBoxTemplate")
        edit:SetSize(160, 20)
        edit:SetPoint("LEFT", row.icon, "RIGHT", 14, 0)
        edit:SetAutoFocus(false)
        edit:SetMaxLetters(100)
        edit:SetScript("OnEscapePressed", edit.ClearFocus)
        edit:SetScript("OnEnterPressed", edit.ClearFocus)
        edit:SetScript("OnTextChanged", function(self)
            mmWorking[i].name = self:GetText()
        end)
        row.edit = edit

        local dropdown = CreateFrame("Frame", "DHToolsMMRow" .. i .. "Dropdown", content, "UIDropDownMenuTemplate")
        dropdown:SetPoint("LEFT", edit, "RIGHT", 6, -2)
        UIDropDownMenu_SetWidth(dropdown, 90)
        UIDropDownMenu_Initialize(dropdown, function(self, level)
            for _, iconNum in ipairs(MM.ICON_PRIORITY_ORDER) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = MM.ICON_LABELS[iconNum]
                info.icon = MM.ICON_PATH .. iconNum
                info.value = iconNum
                info.func = function() MM_SetRowIcon(i, iconNum) end
                UIDropDownMenu_AddButton(info)
            end
        end)
        row.dropdown = dropdown

        local delBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
        delBtn:SetSize(60, 20)
        delBtn:SetText("Delete")
        -- 2026-07-17 bug fix: this was 26 (a stray leftover from some other
        -- offset in this file), pushing the button ~24px further right than
        -- the original HCMobMarker Options.lua's row (which used 2) - just
        -- enough to clip past the scrollframe's visible width so the right
        -- edge (and the final "e") got cut off. Restored to a tight gap.
        delBtn:SetPoint("LEFT", dropdown, "RIGHT", 4, 2)
        delBtn:SetScript("OnClick", function()
            mmWorking[i].name = ""
            edit:SetText("")
        end)
        row.delBtn = delBtn

        mmRows[i] = row
    end

    local rowsBottom = -26 - (MM_ROW_COUNT - 1) * MM_ROW_HEIGHT - 24 -- bottom edge of row 8

    local clearAllBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
    clearAllBtn:SetSize(100, 22)
    clearAllBtn:SetPoint("TOPLEFT", secTitle1, "BOTTOMLEFT", 8, rowsBottom - 14)
    clearAllBtn:SetText("Clear All")
    clearAllBtn:SetScript("OnClick", function()
        for i = 1, MM_ROW_COUNT do
            mmWorking[i].name = ""
            mmRows[i].edit:SetText("")
        end
    end)

    local saveNote = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    saveNote:SetPoint("TOPLEFT", clearAllBtn, "BOTTOMLEFT", 0, -10)
    saveNote:SetTextColor(1, 0.65, 0.1)
    saveNote:SetText("Changes to the icon list are not saved until you click Update.")

    local updateBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
    updateBtn:SetSize(100, 22)
    updateBtn:SetPoint("TOPLEFT", saveNote, "BOTTOMLEFT", 0, -10)
    updateBtn:SetText("Update")

    local statusText = content:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    statusText:SetPoint("LEFT", updateBtn, "RIGHT", 12, 0)

    updateBtn:SetScript("OnClick", function()
        local newMobs = {}
        for i = 1, MM_ROW_COUNT do
            local w = mmWorking[i]
            if w.name ~= "" then
                newMobs[w.name] = w.icon
            end
        end
        MM.db.mobs = newMobs
        statusText:SetText("|cff33ff99Saved!|r")
        C_Timer.After(2, function() statusText:SetText("") end)
    end)

    -- === Settings section (hotkey marking) ===
    local divider = content:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(1, 1, 1, 0.15)
    divider:SetHeight(1)
    divider:SetPoint("TOPLEFT", updateBtn, "BOTTOMLEFT", -8, -18)
    divider:SetPoint("RIGHT", content, "RIGHT", -8, 0)

    local secTitle2 = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    secTitle2:SetPoint("TOPLEFT", divider, "BOTTOMLEFT", 8, -14)
    secTitle2:SetText("Hotkey Marking")

    local desc = content:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    desc:SetPoint("TOPLEFT", secTitle2, "BOTTOMLEFT", 0, -8)
    desc:SetPoint("RIGHT", content, "RIGHT", -16, 0)
    desc:SetJustifyH("LEFT")
    desc:SetWordWrap(true)
    desc:SetText("Hold the modifier below and click a mob to instantly mark it with the next unused icon. If all 8 icons are already in use, it takes over Skull (evicting whoever currently has it).")

    local modLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    modLabel:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -22)
    modLabel:SetText("Modifier:")

    local modDropdown = CreateFrame("Frame", "DHToolsMMModDropdown", content, "UIDropDownMenuTemplate")
    modDropdown:SetPoint("LEFT", modLabel, "RIGHT", 0, -2)
    UIDropDownMenu_SetWidth(modDropdown, 100)

    local btnLabel = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    btnLabel:SetPoint("TOPLEFT", modLabel, "BOTTOMLEFT", 0, -30)
    btnLabel:SetText("Mouse Button:")

    local btnDropdown = CreateFrame("Frame", "DHToolsMMBtnDropdown", content, "UIDropDownMenuTemplate")
    btnDropdown:SetPoint("LEFT", btnLabel, "RIGHT", 0, -2)
    UIDropDownMenu_SetWidth(btnDropdown, 100)

    local function RefreshHotkeyDropdowns()
        MM.InitDB()
        local hk = MM.db.hotkey
        for _, opt in ipairs(MODIFIER_OPTIONS) do
            if opt.value == hk.modifier then UIDropDownMenu_SetText(modDropdown, opt.label) end
        end
        for _, opt in ipairs(BUTTON_OPTIONS) do
            if opt.value == hk.button then UIDropDownMenu_SetText(btnDropdown, opt.label) end
        end
    end

    UIDropDownMenu_Initialize(modDropdown, function()
        for _, opt in ipairs(MODIFIER_OPTIONS) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt.label
            info.value = opt.value
            info.func = function()
                MM.db.hotkey.modifier = opt.value
                UIDropDownMenu_SetText(modDropdown, opt.label)
            end
            UIDropDownMenu_AddButton(info)
        end
    end)

    UIDropDownMenu_Initialize(btnDropdown, function()
        for _, opt in ipairs(BUTTON_OPTIONS) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt.label
            info.value = opt.value
            info.func = function()
                MM.db.hotkey.button = opt.value
                UIDropDownMenu_SetText(btnDropdown, opt.label)
            end
            UIDropDownMenu_AddButton(info)
        end
    end)

    local resetBtn = CreateFrame("Button", nil, content, "UIPanelButtonTemplate")
    resetBtn:SetSize(140, 22)
    resetBtn:SetPoint("TOPLEFT", btnLabel, "BOTTOMLEFT", 0, -22)
    resetBtn:SetText("Reset to Default")
    resetBtn:SetScript("OnClick", function()
        MM.db.hotkey.modifier = "CTRL"
        MM.db.hotkey.button = "LeftButton"
        RefreshHotkeyDropdowns()
    end)

    local note = content:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    note:SetPoint("TOPLEFT", resetBtn, "BOTTOMLEFT", 0, -14)
    note:SetPoint("RIGHT", content, "RIGHT", -16, 0)
    note:SetJustifyH("LEFT")
    note:SetWordWrap(true)
    note:SetText("Changes here take effect immediately -- no need to click Update.")

    -- === Load / refresh ===
    panel.Refresh = function()
        -- -24 (not -4) to leave room for the scrollbar, matching the value
        -- Board.lua already uses for the same reason - otherwise the
        -- Settings section's right-anchored text (divider/desc/note) can
        -- run under the scrollbar.
        content:SetWidth(math.max(1, scrollFrame:GetWidth() - 24))

        MM.InitDB()
        for i = 1, MM_ROW_COUNT do
            mmWorking[i] = { name = "", icon = MM.ICON_PRIORITY_ORDER[i] }
        end
        for name, icon in pairs(MM.db.mobs) do
            for i = 1, MM_ROW_COUNT do
                if mmWorking[i].icon == icon and mmWorking[i].name == "" then
                    mmWorking[i].name = name
                    break
                end
            end
        end
        for i = 1, MM_ROW_COUNT do
            MM_RefreshRowVisual(i)
        end
        statusText:SetText("")

        RefreshHotkeyDropdowns()
    end

    return panel
end

--------------------------------------------------------------------------
-- Quests page - Milestone 4 (DH-Quests-Design.md). Master share on/off +
-- one checkbox per category, controlling what THIS client broadcasts to
-- the guild. Writes live (no Update button needed - these are plain
-- booleans, not the kind of multi-field edit Mob Marker's Target Icons
-- section needs a commit step for). Per DH-Quests-Design.md's M4 note,
-- these only gate outbound sharing - they never hide what other
-- guildmates have already shared with you (Sync.lua's "receiving is
-- never gated" rule).
--------------------------------------------------------------------------

local QUESTS_CATEGORY_ORDER = { "Individual", "Group", "Elite", "Class" }
local QUESTS_CATEGORY_LABELS = {
    Individual = "Individual quests",
    Group = "Group quests",
    Elite = "Elite quests",
    Class = "Class quests",
}

local function CreateQuestsPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("Quests")

    local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -6)
    hint:SetPoint("RIGHT", -16, 0)
    hint:SetJustifyH("LEFT")
    hint:SetWordWrap(true)
    hint:SetText("Controls what THIS character shares with the guild. Turning a category off only stops you sharing it - you'll still see other guildmates' shared quests either way.")

    local masterCheck = CreateFrame("CheckButton", "DHToolsQuestsMasterCheck", panel, "UICheckButtonTemplate")
    masterCheck:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -16)
    _G[masterCheck:GetName() .. "Text"]:SetText("Share my quests with the guild")
    masterCheck:SetScript("OnClick", function(self)
        DHQuests.db.settings.shareEnabled = self:GetChecked() and true or false
    end)

    local divider = panel:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(1, 1, 1, 0.15)
    divider:SetHeight(1)
    divider:SetPoint("TOPLEFT", masterCheck, "BOTTOMLEFT", 0, -14)
    divider:SetPoint("RIGHT", -16, 0)

    local catTitle = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    catTitle:SetPoint("TOPLEFT", divider, "BOTTOMLEFT", 0, -14)
    catTitle:SetText("Categories to share:")

    local catChecks = {}
    local prevAnchor = catTitle
    for i, cat in ipairs(QUESTS_CATEGORY_ORDER) do
        local check = CreateFrame("CheckButton", "DHToolsQuestsCat" .. cat .. "Check", panel, "UICheckButtonTemplate")
        if i == 1 then
            check:SetPoint("TOPLEFT", prevAnchor, "BOTTOMLEFT", -4, -8)
        else
            check:SetPoint("TOPLEFT", prevAnchor, "BOTTOMLEFT", 0, -4)
        end
        _G[check:GetName() .. "Text"]:SetText(QUESTS_CATEGORY_LABELS[cat])
        check:SetScript("OnClick", function(self)
            DHQuests.db.settings.categories[cat] = self:GetChecked() and true or false
        end)
        catChecks[cat] = check
        prevAnchor = check
    end

    panel.Refresh = function()
        if DHQuests.InitDB then
            DHQuests.InitDB()
        end
        local settings = DHQuests.db and DHQuests.db.settings
        if not settings then return end
        masterCheck:SetChecked(settings.shareEnabled == true)
        for _, cat in ipairs(QUESTS_CATEGORY_ORDER) do
            catChecks[cat]:SetChecked(settings.categories[cat] == true)
        end
    end

    return panel
end

--------------------------------------------------------------------------
-- About page
--------------------------------------------------------------------------

local function CreateAboutPanel(parent)
    local panel = CreateFrame("Frame", nil, parent)
    panel:SetAllPoints()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 16, -16)
    title:SetText("About DH-Tools")

    local body = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    body:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -16)
    body:SetPoint("RIGHT", -16, 0)
    body:SetJustifyH("LEFT")
    body:SetJustifyV("TOP")
    body:SetWordWrap(true)

    panel.Refresh = function()
        local gameVersion = GetBuildInfo()
        local text = "Addon Version: " .. DHTools.VERSION .. "\n"
            .. "Game Version: " .. tostring(gameVersion) .. "\n\n"
            .. "Author: Loopi\n\n"
            .. "The Death Happens guild's master addon - lets you activate or "
            .. "deactivate individual modules from one addon. Type /dht list "
            .. "to see what's installed.\n\n"
            .. "Mob Marker's auto-mark/hotkey/target-icon-list functionality "
            .. "was originally its own addon, HC Mob Marker, also by Loopi - "
            .. "merged directly into DH-Tools as its first module.\n\n"
            .. "Copyright (c) 2026 Loopi. All rights reserved."
        body:SetText(text)
    end

    return panel
end

--------------------------------------------------------------------------
-- Frame / navigation
--------------------------------------------------------------------------

-- WoW added SetResizeBounds as a replacement for the older separate
-- SetMinResize/SetMaxResize calls at different points across client
-- versions - try the new one first, fall back to the old pair. Same
-- helper as DH-Air's Board.lua (the one other DH-Tools/DH-Air window
-- that's resizable).
local function ApplyResizeBounds(f, minW, minH, maxW, maxH)
    if f.SetResizeBounds then
        pcall(f.SetResizeBounds, f, minW, minH, maxW, maxH)
    else
        pcall(f.SetMinResize, f, minW, minH)
        pcall(f.SetMaxResize, f, maxW, maxH)
    end
end

local function SelectPage(key)
    for k, b in pairs(navButtons) do
        if k == key then
            b:LockHighlight()
        else
            b:UnlockHighlight()
        end
    end
    for k, p in pairs(frame.pages) do
        if k == key then
            p:Show()
            if p.Refresh then p.Refresh() end
        else
            p:Hide()
        end
    end
end

-- pageKey: "Tools" | "MobMarker" | "About" (nil defaults to "Tools" on first
-- creation, or leaves whatever page was already showing on later calls).
function DHTools:Config_Open(pageKey)
    if not frame then
        frame = CreateFrame("Frame", "DHToolsConfigFrame", UIParent, "BasicFrameTemplateWithInset")
        frame:SetSize(640, 520)
        frame:SetPoint("CENTER")
        DHTools.InitStandaloneWindow(frame)
        if frame.TitleText then
            frame.TitleText:SetText("DH-Tools Configuration")
        end
        tinsert(UISpecialFrames, "DHToolsConfigFrame")

        -- Resizable by dragging the bottom-right corner grip, like DH-Air's
        -- Board window. Min width is the same as the default (640) rather
        -- than smaller - the Mob Marker page's Target Icons row layout is a
        -- fixed pixel width and doesn't reflow, so letting the window get
        -- narrower than that would just reintroduce clipping on that row.
        -- Height can shrink further since Mob Marker's page scrolls.
        frame:SetResizable(true)
        ApplyResizeBounds(frame, 640, 400, 900, 750)

        local grip = CreateFrame("Button", nil, frame)
        grip:SetSize(16, 16)
        grip:SetPoint("BOTTOMRIGHT", -4, 4)
        grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
        grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
        grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
        grip:SetScript("OnMouseDown", function() frame:StartSizing("BOTTOMRIGHT") end)
        grip:SetScript("OnMouseUp", function()
            frame:StopMovingOrSizing()
            -- Mob Marker's content width tracks the scrollframe's width
            -- (set in its own Refresh) - re-run whichever page is showing
            -- so a resize takes effect immediately instead of only on the
            -- next page switch.
            for _, p in pairs(frame.pages) do
                if p:IsShown() and p.Refresh then
                    p.Refresh()
                end
            end
        end)

        local nav = CreateFrame("Frame", nil, frame)
        nav:SetPoint("TOPLEFT", 12, -32)
        nav:SetPoint("BOTTOMLEFT", 12, 12)
        nav:SetWidth(130)

        local navBg = nav:CreateTexture(nil, "BACKGROUND")
        navBg:SetAllPoints()
        navBg:SetColorTexture(0, 0, 0, 0.25)

        local content = CreateFrame("Frame", nil, frame)
        content:SetPoint("TOPLEFT", nav, "TOPRIGHT", 10, 0)
        content:SetPoint("BOTTOMRIGHT", -12, 12)

        frame.pages = {
            Tools = CreateToolsPanel(content),
            MobMarker = CreateMobMarkerPanel(content),
            Quests = CreateQuestsPanel(content),
            About = CreateAboutPanel(content),
        }

        local pageNames = { "Tools", "MobMarker", "Quests", "About" }
        local pageLabels = { Tools = "Tools", MobMarker = "Mob Marker", Quests = "Quests", About = "About" }
        local prevBtn
        for _, name in ipairs(pageNames) do
            local btn = CreateFrame("Button", nil, nav, "UIPanelButtonTemplate")
            btn:SetSize(112, 24)
            if prevBtn then
                btn:SetPoint("TOPLEFT", prevBtn, "BOTTOMLEFT", 0, -4)
            else
                btn:SetPoint("TOPLEFT", 8, -8)
            end
            btn:SetText(pageLabels[name])
            btn:SetScript("OnClick", function() SelectPage(name) end)
            navButtons[name] = btn
            prevBtn = btn
        end

        SelectPage(pageKey or "Tools")
        frame:Show()
        return
    end

    frame:Show()
    if pageKey then
        SelectPage(pageKey)
    else
        for k, p in pairs(frame.pages) do
            if p:IsShown() and p.Refresh then
                p.Refresh()
            end
        end
    end
end
