-- DH-Tools: Minimap.lua
-- Standard LibDataBroker-1.1 / LibDBIcon-1.0 minimap button.
--
-- Click (either button) toggles a small hand-rolled list of choices
-- anchored under the icon - NOT UIDropDownMenu/EasyMenu. DH-Air's own
-- Minimap.lua deliberately avoided that Blizzard template for its
-- right-click menu after two rounds of live-Classic-Era testing found the
-- click either not registering or the menu not appearing, and gave up
-- chasing a client-specific quirk it couldn't reproduce or debug (see that
-- file's comments). Rather than risk hitting the same wall, this menu is
-- just a plain Frame with plain Buttons on it.
--
-- 2026-07-17: entries are "DH-Tools" (top-level config) and "Target Icons"
-- (config, jumped straight to the Mob Marker page) - Chris wanted the
-- target icon list reachable in one click from the minimap. MENU_ENTRIES
-- below is a plain list, so adding more choices later is a one-line change.
--
-- 2026-07-27 (DH-Quests Milestone 5): added "Shared Quests", opening
-- DHQuests' own Board.lua window directly - a thin adapter entry only
-- (DH-Quests-Design.md's M5 note: no dedicated minimap button/LDB object
-- for DHQuests itself, reuse this existing one instead). Guarded with
-- `DHQuests and DHQuests.Board_Toggle and` since the Quests module could
-- theoretically be absent/disabled - matches the defensive `if
-- DHTools.Config_Open then` checks Core.lua uses for the same reason.

local ADDON_NAME = ...
local DHTools = DHTools

local LDB = LibStub("LibDataBroker-1.1")
local LDBIcon = LibStub("LibDBIcon-1.0")

-- A generic wrench icon - DH-Tools isn't tied to any one module's theme.
local TOOLS_ICON = "Interface\\Icons\\INV_Misc_Wrench_01"

local MENU_ENTRIES = {
    { label = "DH-Tools", onClick = function() DHTools:Config_Open("Tools") end },
    { label = "Target Icons", onClick = function() DHTools:Config_Open("MobMarker") end },
    { label = "Shared Quests", onClick = function()
        if DHQuests and DHQuests.Board_Toggle then
            DHQuests.Board_Toggle()
        end
    end },
}

--------------------------------------------------------------------------
-- Custom choice-list frame (the minimap click menu)
--------------------------------------------------------------------------

local menu
local ENTRY_HEIGHT = 22
local MENU_WIDTH = 140

local function BuildMenu()
    menu = CreateFrame("Frame", "DHToolsMinimapMenu", UIParent)
    menu:SetSize(MENU_WIDTH, #MENU_ENTRIES * ENTRY_HEIGHT + 8)
    menu:SetFrameStrata("DIALOG")
    menu:EnableMouse(true)
    tinsert(UISpecialFrames, "DHToolsMinimapMenu") -- lets Escape close it

    local bg = menu:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.9)

    local border = menu:CreateTexture(nil, "BORDER")
    border:SetColorTexture(1, 1, 1, 0.25)
    border:SetPoint("TOPLEFT", -1, 1)
    border:SetPoint("BOTTOMRIGHT", 1, -1)

    for i, entryDef in ipairs(MENU_ENTRIES) do
        local btn = CreateFrame("Button", nil, menu)
        btn:SetSize(MENU_WIDTH - 8, ENTRY_HEIGHT)
        btn:SetPoint("TOP", 0, -4 - (i - 1) * ENTRY_HEIGHT)

        local highlight = btn:CreateTexture(nil, "HIGHLIGHT")
        highlight:SetAllPoints()
        highlight:SetColorTexture(1, 1, 1, 0.15)

        local text = btn:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        text:SetPoint("LEFT", 6, 0)
        text:SetText(entryDef.label)

        btn:SetScript("OnClick", function()
            menu:Hide()
            entryDef.onClick()
        end)
    end

    menu:Hide()
end

local function ToggleMenu(anchorFrame)
    if not menu then
        BuildMenu()
    end
    if menu:IsShown() then
        menu:Hide()
        return
    end
    menu:ClearAllPoints()
    menu:SetPoint("TOP", anchorFrame, "BOTTOM", 0, -4)
    menu:Show()
end

--------------------------------------------------------------------------
-- LibDataBroker button
--------------------------------------------------------------------------

local dataObject = LDB:NewDataObject("DHTools", {
    type = "launcher",
    text = "DH-Tools",
    icon = TOOLS_ICON,
    OnClick = function(self)
        ToggleMenu(self)
    end,
    OnTooltipShow = function(tooltip)
        if not tooltip or not tooltip.AddLine then return end
        tooltip:AddLine("DH-Tools")
        tooltip:AddLine(" ")
        tooltip:AddLine("Click for a menu: DH-Tools config, Target Icons, or Shared Quests.")
    end,
})

function DHTools.Minimap_Init()
    LDBIcon:Register("DHTools", dataObject, DHTools.db.minimap)
end
