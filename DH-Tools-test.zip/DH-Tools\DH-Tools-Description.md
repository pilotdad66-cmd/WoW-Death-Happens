# DH-Tools

**Version 1.0** | Author: **Loopi** | For: *Death Happens* Hardcore guild

---

## Summary

DH-Tools is the Death Happens guild's all-in-one utility addon: instead of
installing a separate addon for every guild tool, enable or disable each
one individually from a single config window.

- **Module Toggle Framework** — the Tools page (`/dht config`) lists every
  available module with a one-line description and an on/off checkbox.
  Turn on only what you need; more modules will be added here over time.
- **Mob Marker** — automatically marks specific mobs with a raid-target
  icon on mouseover, plus a configurable Ctrl+click hotkey to mark/unmark
  whatever's under your cursor on demand. Fully customizable icon
  assignments per mob and hotkey modifier/mouse button, via `/mm config`.
- **Shared Quests** — see which group and elite quests your online
  guildmates currently have, so you can find people to group up with.
  Broadcasts your own quest log over guild addon messages (Individual,
  Group, Elite, and Class categories, each independently toggleable, and
  entirely opt-in), and shows everyone else's in a sortable, filterable
  window (`/dhq`) — filter to online-only, sort by player, quest, or
  character level, and invite a matching player straight from the row.
- **Minimap Button** — one button for the whole addon; click it for a
  quick-launch menu into DH-Tools' config, the Mob Marker icon list, or
  the Shared Quests window.
- **DH-Air Status** — the Tools page shows whether DH-Air (the guild's
  Warlock summon-coordination addon) is installed. DH-Air stays a separate,
  standalone addon rather than folding into DH-Tools, so this is a status
  indicator, not a toggle — install DH-Air on its own if you want it.

DH-Tools does **not** replace any of its modules' individual settings or
judgment calls — it's a shared shell that lets you pick which guild tools
you actually want running, all managed from one place.
