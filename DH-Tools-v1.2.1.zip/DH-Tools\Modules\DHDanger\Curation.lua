-- DH-Danger :: Curation.lua
-- GENERATED FILE - DO NOT HAND-EDIT.
-- Source: claude\DH-Danger\curation\DH-Danger-Curation.csv
-- Regenerate: powershell -ExecutionPolicy Bypass -File claude\DH-Danger\import-curation.ps1
-- Generated: 2026-08-13 21:39
--
-- HUMAN JUDGEMENT ONLY. Facts live in DangerData.lua, which is
-- regenerated from the import files and the in-game dump. Keeping
-- them apart means re-importing source data cannot destroy curation,
-- and re-curating cannot corrupt facts. Runtime merges this OVER
-- DangerData.
--
-- Absent field = not yet judged. That is NOT the same as false:
-- yells=false means 'confirmed silent, nameplate range is the
-- ceiling'; absent means nobody has checked. Never collapse the two.

local _, ns = ...

ns.Curation = ns.Curation or {}
ns.Curation.generated = "2026-08-13 21:39"

-- [npcID] = { name, zone|zones, level, type, creatureType, surprise, severity,
--             yells, stealth, roams, soloable, include, why }
-- zone is a plain string; a mob that roams across a border carries
-- zones (an array) instead, merged from one CSV row per zone -
-- consumers must read e.zones or {e.zone}, never e.zone alone.
-- type mirrors UnitClassification(): normal|elite|rare|rareelite.
-- creatureType mostly mirrors UnitCreatureType() (e.g. Humanoid); absent
-- means unknown. Hydra/Silithid/Slime are a deliberate exception (Chris,
-- 2026-08-13) - the live API lumps them under Beast/uncategorized, which
-- tells a player nothing, so these three carry their own label instead.
-- level is an integer, or -1 for '??'/skull mobs - see DangerList.lua's
-- schema comment on why -1 must be branched on, never compared.
ns.Curation.npcs = {
	[61]={name="Thuros Lightfingers",zone="Elwynn Forest",level=11,type="rare",creatureType="Humanoid"},  -- Thuros Lightfingers
	[79]={name="Narg the Taskmaster",zone="Elwynn Forest",level=10,type="rare",creatureType="Humanoid"},  -- Narg the Taskmaster
	[99]={name="Morgaine the Sly",zone="Elwynn Forest",level=10,type="rare",creatureType="Humanoid"},  -- Morgaine the Sly
	[100]={name="Gruff Swiftbite",zone="Elwynn Forest",level=12,type="rare",creatureType="Humanoid"},  -- Gruff Swiftbite
	[448]={name="Hogger",zone="Elwynn Forest",level=11,type="elite",creatureType="Humanoid"},  -- Hogger
	[462]={name="Vultros",zone="Westfall",level=26,type="rare",creatureType="Beast"},  -- Vultros
	[471]={name="Mother Fang",zone="Elwynn Forest",level=10,type="rare",creatureType="Beast"},  -- Mother Fang
	[472]={name="Fedfennel",zone="Elwynn Forest",level=12,type="rare",creatureType="Humanoid"},  -- Fedfennel
	[503]={name="Lord Malathrom",zone="Duskwood",level=31,type="rare",creatureType="Undead"},  -- Lord Malathrom
	[506]={name="Sergeant Brashclaw",zone="Westfall",level=18,type="rare",creatureType="Humanoid"},  -- Sergeant Brashclaw
	[507]={name="Fenros",zone="Duskwood",level=32,type="rare",creatureType="Humanoid"},  -- Fenros
	[519]={name="Slark",zone="Westfall",level=15,type="rare",creatureType="Humanoid"},  -- Slark
	[520]={name="Brack",zone="Westfall",level=19,type="rare",creatureType="Humanoid"},  -- Brack
	[521]={name="Lupos",zone="Duskwood",level=23,type="rare",creatureType="Beast"},  -- Lupos
	[534]={name="Nefaru",zone="Duskwood",level=37,type="rare",creatureType="Humanoid"},  -- Nefaru
	[572]={name="Leprithus",zone="Westfall",level=19,type="rare",creatureType="Undead"},  -- Leprithus
	[573]={name="Foe Reaper 4000",zone="Westfall",level=20,type="rare",creatureType="Mechanical"},  -- Foe Reaper 4000
	[574]={name="Naraxis",zone="Duskwood",level=27,type="rare",creatureType="Beast"},  -- Naraxis
	[584]={name="Kazon",zone="Redridge Mountains",level=27,type="rare",creatureType="Humanoid"},  -- Kazon
	[596]={name="Brainwashed Noble",zone="Westfall",level=18,type="rareelite",creatureType="Humanoid"},  -- Brainwashed Noble
	[599]={name="Marisa du'Paige",zone="Westfall",level=18,type="rareelite",creatureType="Humanoid"},  -- Marisa du'Paige
	[603]={name="Grimtooth",zone="Alterac Valley",level=59,type="rare",creatureType="Humanoid"},  -- Grimtooth
	[616]={name="Chatter",zone="Redridge Mountains",level=23,type="rare",creatureType="Beast"},  -- Chatter
	[619]={name="Defias Conjurer",zone="Westfall",level=16,type="elite",creatureType="Humanoid"},  -- Defias Conjurer
	[639]={name="Edwin VanCleef",zone="The Deadmines",level=21,type="rareelite",creatureType="Humanoid"},  -- Edwin VanCleef
	[723]={name="Mosh'Ogg Butcher",zone="Stranglethorn Vale",level=44,type="rareelite",creatureType="Humanoid"},  -- Mosh'Ogg Butcher
	[763]={name="Lost One Chieftain",zone="Swamp of Sorrows",level=39,type="rare",creatureType="Humanoid"},  -- Lost One Chieftain
	[771]={name="Commander Felstrom",zone="Duskwood",level=32,type="rare",creatureType="Undead"},  -- Commander Felstrom
	[947]={name="Rohh the Silent",zone="Redridge Mountains",level=26,type="rare",creatureType="Humanoid"},  -- Rohh the Silent
	[1037]={name="Dragonmaw Battlemaster",zone="Wetlands",level=30,type="rare",creatureType="Humanoid"},  -- Dragonmaw Battlemaster
	[1061]={name="Gan'zulah",zone="Stranglethorn Vale",level=41,type="rare",creatureType="Humanoid"},  -- Gan'zulah
	[1063]={name="Jade",zone="Swamp of Sorrows",level=47,type="rareelite",creatureType="Dragonkin"},  -- Jade
	[1106]={name="Lost One Cook",zone="Swamp of Sorrows",level=37,type="rare",creatureType="Humanoid"},  -- Lost One Cook
	[1112]={name="Leech Widow",zone="Wetlands",level=24,type="rare",creatureType="Beast"},  -- Leech Widow
	[1119]={name="Hammerspine",zone="Dun Morogh",level=12,type="rare",creatureType="Humanoid"},  -- Hammerspine
	[1130]={name="Bjarn",zone="Dun Morogh",level=12,type="rare",creatureType="Beast"},  -- Bjarn
	[1132]={name="Timber",zone="Dun Morogh",level=10,type="rare",creatureType="Beast"},  -- Timber
	[1137]={name="Edan the Howler",zone="Dun Morogh",level=9,type="rare",creatureType="Humanoid"},  -- Edan the Howler
	[1140]={name="Razormaw Matriarch",zone="Wetlands",level=30,type="rare",creatureType="Beast"},  -- Razormaw Matriarch
	[1210]={name="Chok'Sul",zone="Loch Modan",level=22,type="elite",creatureType="Humanoid"},  -- Chok'Sul
	[1225]={name="Ol'Sooty",zone="Loch Modan",level=20,type="elite",creatureType="Beast"},  -- Ol'Sooty
	[1260]={name="Great Father Arctikus",zone="Dun Morogh",level=11,type="rare",creatureType="Humanoid"},  -- Great Father Arctikus
	[1271]={name="Old Icebeard",zone="Dun Morogh",level=11,type="elite",creatureType="Humanoid"},  -- Old Icebeard
	[1388]={name="Vagash",zone="Dun Morogh",level=11,type="elite",creatureType="Humanoid"},  -- Vagash
	[1398]={name="Boss Galgosh",zone="Loch Modan",level=22,type="rare",creatureType="Humanoid"},  -- Boss Galgosh
	[1399]={name="Magosh",zone="Loch Modan",level=21,type="rare",creatureType="Humanoid"},  -- Magosh
	[1424]={name="Master Digger",zone="Westfall",level=15,type="rare",creatureType="Humanoid"},  -- Master Digger
	[1425]={name="Grizlak",zone="Loch Modan",level=15,type="rare",creatureType="Humanoid"},  -- Grizlak
	[1552]={name="Scale Belly",zone="Stranglethorn Vale",level=45,type="rare",creatureType="Beast"},  -- Scale Belly
	[1720]={name="Bruegal Ironknuckle",zone="The Stockade",level=26,type="rareelite",creatureType="Humanoid"},  -- Bruegal Ironknuckle
	[1837]={name="Scarlet Judge",zone="Western Plaguelands",level=60,type="rare",creatureType="Humanoid"},  -- Scarlet Judge
	[1838]={name="Scarlet Interrogator",zone="Western Plaguelands",level=62,type="rareelite",creatureType="Humanoid"},  -- Scarlet Interrogator
	[1839]={name="Scarlet High Clerist",zone="Western Plaguelands",level=63,type="rareelite",creatureType="Humanoid"},  -- Scarlet High Clerist
	[1841]={name="Scarlet Executioner",zone="Western Plaguelands",level=60,type="rareelite",creatureType="Humanoid"},  -- Scarlet Executioner
	[1843]={name="Foreman Jerris",zone="Western Plaguelands",level=63,type="rareelite",creatureType="Humanoid"},  -- Foreman Jerris
	[1844]={name="Foreman Marcrid",zone="Western Plaguelands",level=58,type="rare",creatureType="Humanoid"},  -- Foreman Marcrid
	[1847]={name="Foulmane",zone="Western Plaguelands",level=52,type="rare",creatureType="Undead"},  -- Foulmane
	[1848]={name="Lord Maldazzar",zone="Western Plaguelands",level=56,type="rare",creatureType="Humanoid"},  -- Lord Maldazzar
	[1850]={name="Putridius",zone="Western Plaguelands",level=58,type="rareelite",creatureType="Undead"},  -- Putridius
	[1851]={name="The Husk",zone="Western Plaguelands",level=62,type="rare",creatureType="Elemental"},  -- The Husk
	[1885]={name="Scarlet Smith",zone="Western Plaguelands",level=60,type="rare",creatureType="Humanoid"},  -- Scarlet Smith
	[2090]={name="Ma'ruk Wyrmscale",zone="Wetlands",level=23,type="rare",creatureType="Humanoid"},  -- Ma'ruk Wyrmscale
	[2108]={name="Garneg Charskull",zone="Wetlands",level=29,type="rare",creatureType="Humanoid"},  -- Garneg Charskull
	[2175]={name="Shadowclaw",zone="Darkshore",level=13,type="rare",creatureType="Beast",surprise="stealth",severity=3,stealth=true,roams=true,soloable=false,why="Roaming elite panther in a starter zone. Low-level players have no stealth detection and no escape."},  -- Shadowclaw
	[2184]={name="Lady Moongazer",zone="Darkshore",level=17,type="rare",creatureType="Undead"},  -- Lady Moongazer
	[2186]={name="Carnivous the Breaker",zone="Darkshore",level=16,type="rare",creatureType="Humanoid"},  -- Carnivous the Breaker
	[2191]={name="Licillin",zone="Darkshore",level=14,type="rare",creatureType="Demon"},  -- Licillin
	[2192]={name="Firecaller Radison",zone="Darkshore",level=19,type="rare",creatureType="Humanoid"},  -- Firecaller Radison
	[2258]={name="Stone Fury",zone="Alterac Mountains",level=37,type="rare",creatureType="Elemental"},  -- Stone Fury
	[2447]={name="Narillasanz",zones={"Alterac Mountains","Hillsbrad Foothills"},level=44,type="rareelite",creatureType="Dragonkin"},  -- Narillasanz
	[2452]={name="Skhowl",zone="Alterac Mountains",level=36,type="rare",creatureType="Humanoid"},  -- Skhowl
	[2453]={name="Lo'Grosh",zone="Alterac Mountains",level=39,type="rare",creatureType="Humanoid"},  -- Lo'Grosh
	[2476]={name="Large Loch Crocolisk",zone="Loch Modan",level=22,type="rare",creatureType="Beast"},  -- Large Loch Crocolisk
	[2477]={name="Gradok",zone="Loch Modan",level=21,type="elite",creatureType="Humanoid",roams=true},  -- Gradok
	[2478]={name="Haren Swifthoof",zone="Loch Modan",level=21,type="elite",creatureType="Humanoid",roams=true},  -- Haren Swifthoof
	[2541]={name="Lord Sakrasis",zone="Stranglethorn Vale",level=45,type="rare",creatureType="Humanoid"},  -- Lord Sakrasis
	[2598]={name="Darbel Montrose",zone="Arathi Highlands",level=39,type="rareelite",creatureType="Humanoid"},  -- Darbel Montrose
	[2600]={name="Singer",zone="Arathi Highlands",level=34,type="rare",creatureType="Humanoid"},  -- Singer
	[2601]={name="Foulbelly",zone="Arathi Highlands",level=42,type="rareelite",creatureType="Humanoid"},  -- Foulbelly
	[2602]={name="Ruul Onestone",zone="Arathi Highlands",level=39,type="rareelite",creatureType="Humanoid"},  -- Ruul Onestone
	[2603]={name="Kovork",zone="Arathi Highlands",level=37,type="rare",creatureType="Humanoid"},  -- Kovork
	[2604]={name="Molok the Crusher",zone="Arathi Highlands",level=39,type="rare",creatureType="Humanoid"},  -- Molok the Crusher
	[2605]={name="Zalas Witherbark",zone="Arathi Highlands",level=40,type="rare",creatureType="Humanoid"},  -- Zalas Witherbark
	[2606]={name="Nimar the Slayer",zone="Arathi Highlands",level=37,type="rare",creatureType="Humanoid"},  -- Nimar the Slayer
	[2609]={name="Geomancer Flintdagger",zone="Arathi Highlands",level=40,type="rare",creatureType="Humanoid"},  -- Geomancer Flintdagger
	[2744]={name="Shadowforge Commander",zone="Badlands",level=40,type="rare",creatureType="Humanoid"},  -- Shadowforge Commander
	[2749]={name="Siege Golem",zone="Badlands",level=40,type="rareelite",creatureType="Elemental"},  -- Siege Golem
	[2751]={name="War Golem",zone="Badlands",level=36,type="rare",creatureType="Elemental"},  -- War Golem
	[2752]={name="Rumbler",zone="Badlands",level=45,type="rare",creatureType="Elemental"},  -- Rumbler
	[2753]={name="Barnabus",zone="Badlands",level=39,type="rare",creatureType="Beast"},  -- Barnabus
	[2754]={name="Anathemus",zone="Badlands",level=45,type="rareelite",creatureType="Giant"},  -- Anathemus
	[2779]={name="Prince Nazjak",zone="Arathi Highlands",level=41,type="rare",creatureType="Humanoid"},  -- Prince Nazjak
	[2850]={name="Broken Tooth",zone="Badlands",level=37,type="rare",creatureType="Beast"},  -- Broken Tooth
	[2931]={name="Zaricotl",zone="Badlands",level=55,type="rareelite",creatureType="Beast"},  -- Zaricotl
	[3056]={name="Ghost Howl",zone="Mulgore",level=12,type="rare",creatureType="Beast"},  -- Ghost Howl
	[3068]={name="Mazzranache",zone="Mulgore",level=9,type="rare",creatureType="Beast"},  -- Mazzranache
	[3270]={name="Elder Mystic Razorsnout",zone="The Barrens",level=15,type="rareelite",creatureType="Humanoid"},  -- Elder Mystic Razorsnout
	[3295]={name="Sludge Beast",zone="The Barrens",level=19,type="rare",creatureType="Slime"},  -- Sludge Beast
	[3398]={name="Gesharahan",zone="The Barrens",level=20,type="rareelite",creatureType="Hydra"},  -- Gesharahan
	[3470]={name="Rathorian",zone="The Barrens",level=15,type="rare",creatureType="Demon"},  -- Rathorian
	[3535]={name="Blackmoss the Fetid",zone="Teldrassil",level=13,type="rare",creatureType="Elemental"},  -- Blackmoss the Fetid
	[3581]={name="Sewer Beast",zone="Stormwind City",level=50,type="rare",creatureType="Beast"},  -- Sewer Beast
	[3586]={name="Miner Johnson",zone="The Deadmines",level=19,type="rareelite",creatureType="Humanoid"},  -- Miner Johnson
	[3652]={name="Trigore the Lasher",zone="The Barrens",level=19,type="rareelite",creatureType="Hydra"},  -- Trigore the Lasher
	[3672]={name="Boahn",zone="The Barrens",level=20,type="rareelite",creatureType="Humanoid"},  -- Boahn
	[3735]={name="Apothecary Falthis",zone="Ashenvale",level=22,type="rare",creatureType="Humanoid"},  -- Apothecary Falthis
	[3773]={name="Akkrilus",zone="Ashenvale",level=26,type="rare",creatureType="Demon"},  -- Akkrilus
	[3792]={name="Terrowulf Packlord",zone="Ashenvale",level=32,type="rare",creatureType="Humanoid"},  -- Terrowulf Packlord
	[3872]={name="Deathsworn Captain",zone="Shadowfang Keep",level=25,type="rareelite",creatureType="Undead"},  -- Deathsworn Captain
	[4015]={name="Pridewing Patriarch",zone="Stonetalon Mountains",level=25,type="rare",creatureType="Beast"},  -- Pridewing Patriarch
	[4030]={name="Vengeful Ancient",zone="Stonetalon Mountains",level=30,type="rare",creatureType="Elemental"},  -- Vengeful Ancient
	[4132]={name="Silithid Ravager",zone="Thousand Needles",level=37,type="rare",creatureType="Silithid"},  -- Silithid Ravager
	[4339]={name="Brimgore",zone="Dustwallow Marsh",level=45,type="rareelite",creatureType="Dragonkin"},  -- Brimgore
	[4380]={name="Darkmist Widow",zone="Dustwallow Marsh",level=40,type="rare",creatureType="Beast"},  -- Darkmist Widow
	[4425]={name="Blind Hunter",zone="Razorfen Kraul",level=32,type="rareelite",creatureType="Beast"},  -- Blind Hunter
	[4438]={name="Razorfen Spearhide",zone="Razorfen Kraul",level=29,type="rareelite",creatureType="Humanoid"},  -- Razorfen Spearhide
	[4842]={name="Earthcaller Halmgar",zone="Razorfen Kraul",level=32,type="rareelite",creatureType="Humanoid"},  -- Earthcaller Halmgar
	[5343]={name="Lady Szallah",zone="Feralas",level=46,type="rare",creatureType="Humanoid"},  -- Lady Szallah
	[5345]={name="Diamond Head",zone="Feralas",level=46,type="rare",creatureType="Humanoid"},  -- Diamond Head
	[5346]={name="Bloodroar the Stalker",zone="Feralas",level=49,type="rare",creatureType="Humanoid"},  -- Bloodroar the Stalker
	[5347]={name="Antilus the Soarer",zone="Feralas",level=49,type="rare",creatureType="Beast"},  -- Antilus the Soarer
	[5349]={name="Arash-ethis",zone="Feralas",level=49,type="rare",creatureType="Beast"},  -- Arash-ethis
	[5350]={name="Qirot",zone="Feralas",level=47,type="rare",creatureType="Silithid"},  -- Qirot
	[5352]={name="Old Grizzlegut",zone="Feralas",level=43,type="rare",creatureType="Beast"},  -- Old Grizzlegut
	[5356]={name="Snarler",zone="Feralas",level=42,type="rare",creatureType="Beast"},  -- Snarler
	[5399]={name="Veyzhak the Cannibal",zone="Swamp of Sorrows",level=48,type="rareelite",creatureType="Humanoid"},  -- Veyzhak the Cannibal
	[5400]={name="Zekkis",zone="Swamp of Sorrows",level=48,type="rareelite",creatureType="Undead"},  -- Zekkis
	[5786]={name="Snagglespear",zone="Mulgore",level=9,type="rare",creatureType="Humanoid"},  -- Snagglespear
	[5807]={name="The Rake",zone="Mulgore",level=10,type="rare",creatureType="Beast"},  -- The Rake
	[5823]={name="Death Flayer",zone="Durotar",level=11,type="rare",creatureType="Beast"},  -- Death Flayer
	[5828]={name="Humar the Pridelord",zone="The Barrens",level=23,type="rareelite",creatureType="Beast"},  -- Humar the Pridelord
	[5829]={name="Snort the Heckler",zone="The Barrens",level=17,type="rare",creatureType="Beast"},  -- Snort the Heckler
	[5830]={name="Sister Rathtalon",zone="The Barrens",level=19,type="rareelite",creatureType="Humanoid"},  -- Sister Rathtalon
	[5832]={name="Thunderstomp",zone="The Barrens",level=24,type="rare",creatureType="Beast"},  -- Thunderstomp
	[5834]={name="Azzere the Skyblade",zone="The Barrens",level=25,type="rare",creatureType="Beast"},  -- Azzere the Skyblade
	[5835]={name="Foreman Grills",zone="The Barrens",level=19,type="rare",creatureType="Humanoid"},  -- Foreman Grills
	[5836]={name="Engineer Whirleygig",zone="The Barrens",level=19,type="rare",creatureType="Humanoid"},  -- Engineer Whirleygig
	[5837]={name="Stonearm",zone="The Barrens",level=15,type="rare",creatureType="Humanoid"},  -- Stonearm
	[5838]={name="Brokespear",zone="The Barrens",level=17,type="rare",creatureType="Humanoid"},  -- Brokespear
	[5841]={name="Rocklance",zone="The Barrens",level=17,type="rareelite",creatureType="Humanoid"},  -- Rocklance
	[5842]={name="Takk the Leaper",zone="The Barrens",level=19,type="rareelite",creatureType="Beast"},  -- Takk the Leaper
	[5859]={name="Hagg Taurenbane",zone="The Barrens",level=26,type="rareelite",creatureType="Humanoid"},  -- Hagg Taurenbane
	[5865]={name="Dishu",zone="The Barrens",level=13,type="rare",creatureType="Beast"},  -- Dishu
	[5912]={name="Deviate Faerie Dragon",zone="Wailing Caverns",level=20,type="rareelite",creatureType="Dragonkin"},  -- Deviate Faerie Dragon
	[5928]={name="Sorrow Wing",zone="Stonetalon Mountains",level=27,type="rareelite",creatureType="Beast"},  -- Sorrow Wing
	[5930]={name="Sister Riven",zone="Stonetalon Mountains",level=28,type="rareelite",creatureType="Humanoid"},  -- Sister Riven
	[5931]={name="Foreman Rigger",zone="Stonetalon Mountains",level=24,type="rareelite",creatureType="Humanoid"},  -- Foreman Rigger
	[5932]={name="Taskmaster Whipfang",zone="Stonetalon Mountains",level=22,type="rareelite",creatureType="Humanoid"},  -- Taskmaster Whipfang
	[5933]={name="Achellios the Banished",zone="Thousand Needles",level=31,type="rare",creatureType="Humanoid"},  -- Achellios the Banished
	[5934]={name="Heartrazor",zone="Thousand Needles",level=32,type="rareelite",creatureType="Beast"},  -- Heartrazor
	[5935]={name="Ironeye the Invincible",zone="Thousand Needles",level=37,type="rareelite",creatureType="Beast"},  -- Ironeye the Invincible
	[5937]={name="Vile Sting",zone="Thousand Needles",level=35,type="rareelite",creatureType="Beast"},  -- Vile Sting
	[6118]={name="Varo'then's Ghost",zone="Azshara",level=48,type="rare",creatureType="Undead"},  -- Varo'then's Ghost
	[6228]={name="Dark Iron Ambassador",zone="Gnomeregan",level=33,type="rareelite",creatureType="Humanoid"},  -- Dark Iron Ambassador
	[6488]={name="Fallen Champion",zone="Scarlet Monastery",level=33,type="rareelite",creatureType="Undead"},  -- Fallen Champion
	[6489]={name="Ironspine",zone="Scarlet Monastery",level=33,type="rareelite",creatureType="Undead"},  -- Ironspine
	[6490]={name="Azshir the Sleepless",zone="Scarlet Monastery",level=33,type="rareelite",creatureType="Undead"},  -- Azshir the Sleepless
	[6581]={name="Ravasaur Matriarch",zone="Un'Goro Crater",level=50,type="rare",creatureType="Beast"},  -- Ravasaur Matriarch
	[6582]={name="Clutchmother Zavas",zone="Un'Goro Crater",level=54,type="rare",creatureType="Silithid"},  -- Clutchmother Zavas
	[6583]={name="Gruff",zone="Un'Goro Crater",level=57,type="rareelite",creatureType="Beast"},  -- Gruff
	[6584]={name="King Mosh",zone="Un'Goro Crater",level=60,type="rareelite",creatureType="Beast"},  -- King Mosh
	[6585]={name="Uhk'loc",zone="Un'Goro Crater",level=52,type="rare",creatureType="Beast"},  -- Uhk'loc
	[6646]={name="Monnos the Elder",zone="Azshara",level=53,type="rareelite",creatureType="Giant"},  -- Monnos the Elder
	[6647]={name="Magister Hawkhelm",zone="Azshara",level=52,type="rare",creatureType="Humanoid"},  -- Magister Hawkhelm
	[6648]={name="Antilos",zone="Azshara",level=51,type="rare",creatureType="Beast"},  -- Antilos
	[6649]={name="Lady Sesspira",zone="Azshara",level=51,type="rare",creatureType="Humanoid"},  -- Lady Sesspira
	[6650]={name="General Fangferror",zone="Azshara",level=52,type="rare",creatureType="Humanoid"},  -- General Fangferror
	[6651]={name="Gatekeeper Rageroar",zone="Azshara",level=51,type="rare",creatureType="Humanoid"},  -- Gatekeeper Rageroar
	[6652]={name="Master Feardred",zone="Azshara",level=57,type="rare",creatureType="Demon"},  -- Master Feardred
	[6669]={name="The Threshwackonator 4100",zone="Darkshore",level=20,type="elite",creatureType="Mechanical"},  -- The Threshwackonator 4100
	[7015]={name="Flagglemurk the Cruel",zone="Darkshore",level=16,type="rare",creatureType="Humanoid"},  -- Flagglemurk the Cruel
	[7016]={name="Lady Vespira",zone="Darkshore",level=22,type="rare",creatureType="Humanoid"},  -- Lady Vespira
	[7017]={name="Lord Sinslayer",zone="Darkshore",level=15,type="rare",creatureType="Humanoid"},  -- Lord Sinslayer
	[7053]={name="Klaven Mortwake",zone="Westfall",level=23,type="elite",creatureType="Humanoid"},  -- Klaven Mortwake
	[7057]={name="Digmaster Shovelphlange",zone="Badlands",level=38,type="rareelite",creatureType="Humanoid"},  -- Digmaster Shovelphlange
	[7104]={name="Dessecus",zone="Felwood",level=56,type="rareelite",creatureType="Elemental"},  -- Dessecus
	[7137]={name="Immolatus",zone="Felwood",level=56,type="rareelite",creatureType="Demon"},  -- Immolatus
	[7170]={name="Thragomm",zone="Loch Modan",level=21,type="elite",creatureType="Humanoid",roams=true},  -- Thragomm
	[7895]={name="Ambassador Bloodrage",zone="The Barrens",level=36,type="rareelite",creatureType="Undead"},  -- Ambassador Bloodrage
	[8199]={name="Warleader Krazzilak",zone="Tanaris",level=45,type="rareelite",creatureType="Humanoid"},  -- Warleader Krazzilak
	[8200]={name="Jin'Zallah the Sandbringer",zone="Tanaris",level=46,type="rareelite",creatureType="Humanoid"},  -- Jin'Zallah the Sandbringer
	[8201]={name="Omgorn the Lost",zone="Tanaris",level=50,type="rare",creatureType="Humanoid"},  -- Omgorn the Lost
	[8202]={name="Cyclok the Mad",zone="Tanaris",level=48,type="rare",creatureType="Humanoid"},  -- Cyclok the Mad
	[8203]={name="Kregg Keelhaul",zone="Tanaris",level=47,type="rare",creatureType="Humanoid"},  -- Kregg Keelhaul
	[8204]={name="Soriid the Devourer",zone="Tanaris",level=51,type="rare",creatureType="Silithid"},  -- Soriid the Devourer
	[8205]={name="Haarka the Ravenous",zone="Tanaris",level=50,type="rare",creatureType="Silithid"},  -- Haarka the Ravenous
	[8207]={name="Greater Firebird",zone="Tanaris",level=46,type="rare",creatureType="Beast"},  -- Greater Firebird
	[8208]={name="Murderous Blisterpaw",zone="Tanaris",level=44,type="rare",creatureType="Beast"},  -- Murderous Blisterpaw
	[8210]={name="Razortalon",zone="The Hinterlands",level=44,type="rare",creatureType="Humanoid"},  -- Razortalon
	[8211]={name="Old Cliff Jumper",zone="The Hinterlands",level=42,type="rare",creatureType="Beast"},  -- Old Cliff Jumper
	[8212]={name="The Reak",zone="The Hinterlands",level=50,type="rare",creatureType="Slime"},  -- The Reak
	[8213]={name="Ironback",zone="The Hinterlands",level=51,type="rare",creatureType="Beast"},  -- Ironback
	[8215]={name="Grimungous",zone="The Hinterlands",level=50,type="rareelite",creatureType="Giant"},  -- Grimungous
	[8216]={name="Retherokk the Berserker",zone="The Hinterlands",level=48,type="rare",creatureType="Humanoid"},  -- Retherokk the Berserker
	[8217]={name="Mith'rethis the Enchanter",zone="The Hinterlands",level=52,type="rareelite",creatureType="Humanoid"},  -- Mith'rethis the Enchanter
	[8218]={name="Witherheart the Stalker",zone="The Hinterlands",level=45,type="rare",creatureType="Humanoid"},  -- Witherheart the Stalker
	[8219]={name="Zul'arek Hatefowler",zone="The Hinterlands",level=43,type="rare",creatureType="Humanoid"},  -- Zul'arek Hatefowler
	[8277]={name="Rekk'tilac",zone="Searing Gorge",level=49,type="rare",creatureType="Beast"},  -- Rekk'tilac
	[8278]={name="Smoldar",zone="Searing Gorge",level=53,type="rare",creatureType="Elemental"},  -- Smoldar
	[8279]={name="Faulty War Golem",zone="Searing Gorge",level=46,type="rare",creatureType="Elemental"},  -- Faulty War Golem
	[8280]={name="Shleipnarr",zone="Searing Gorge",level=47,type="rare",creatureType="Demon"},  -- Shleipnarr
	[8281]={name="Scald",zone="Searing Gorge",level=49,type="rare",creatureType="Elemental"},  -- Scald
	[8282]={name="Highlord Mastrogonde",zone="Searing Gorge",level=51,type="rareelite",creatureType="Humanoid"},  -- Highlord Mastrogonde
	[8283]={name="Slave Master Blackheart",zone="Searing Gorge",level=50,type="rare",creatureType="Humanoid"},  -- Slave Master Blackheart
	[8296]={name="Mojo the Twisted",zone="Blasted Lands",level=48,type="rare",creatureType="Humanoid"},  -- Mojo the Twisted
	[8297]={name="Magronos the Unyielding",zone="Blasted Lands",level=57,type="rare",creatureType="Humanoid"},  -- Magronos the Unyielding
	[8298]={name="Akubar the Seer",zone="Blasted Lands",level=54,type="rare",creatureType="Humanoid"},  -- Akubar the Seer
	[8299]={name="Spiteflayer",zone="Blasted Lands",level=60,type="rare",creatureType="Beast"},  -- Spiteflayer
	[8300]={name="Ravage",zone="Blasted Lands",level=51,type="rare",creatureType="Beast"},  -- Ravage
	[8301]={name="Clack the Reaver",zone="Blasted Lands",level=53,type="rare",creatureType="Beast"},  -- Clack the Reaver
	[8302]={name="Deatheye",zone="Blasted Lands",level=49,type="rare",creatureType="Beast"},  -- Deatheye
	[8303]={name="Grunter",zone="Blasted Lands",level=50,type="rare",creatureType="Beast"},  -- Grunter
	[8304]={name="Dreadscorn",zone="Blasted Lands",level=57,type="rare",creatureType="Humanoid"},  -- Dreadscorn
	[8503]={name="Gibblewilt",zone="Dun Morogh",level=11,type="rare",creatureType="Humanoid"},  -- Gibblewilt
	[8660]={name="The Evalcharr",zone="Azshara",level=48,type="rare",creatureType="Beast"},  -- The Evalcharr
	[8923]={name="Panzor the Invincible",zone="Blackrock Depths",level=57,type="rareelite",creatureType="Elemental"},  -- Panzor the Invincible
	[8924]={name="The Behemoth",zone="Blackrock Depths",level=50,type="rareelite",creatureType="Humanoid"},  -- The Behemoth
	[8976]={name="Hematos",zone="Burning Steppes",level=60,type="rareelite",creatureType="Dragonkin"},  -- Hematos
	[8978]={name="Thauris Balgarr",zone="Burning Steppes",level=57,type="rare",creatureType="Humanoid"},  -- Thauris Balgarr
	[8979]={name="Gruklash",zone="Burning Steppes",level=59,type="rare",creatureType="Humanoid"},  -- Gruklash
	[8981]={name="Malfunctioning Reaver",zone="Burning Steppes",level=56,type="rare",creatureType="Elemental"},  -- Malfunctioning Reaver
	[9024]={name="Pyromancer Loregrain",zone="Blackrock Depths",level=52,type="rareelite",creatureType="Humanoid"},  -- Pyromancer Loregrain
	[9025]={name="Lord Roccor",zone="Blackrock Depths",level=51,type="rareelite",creatureType="Elemental"},  -- Lord Roccor
	[9041]={name="Warder Stilgiss",zone="Blackrock Depths",level=56,type="rareelite",creatureType="Humanoid"},  -- Warder Stilgiss
	[9042]={name="Verek",zone="Blackrock Depths",level=55,type="rareelite",creatureType="Demon"},  -- Verek
	[9046]={name="Scarshield Quartermaster",zone="Stranglethorn Vale",level=55,type="rareelite",creatureType="Humanoid"},  -- Scarshield Quartermaster
	[9217]={name="Spirestone Lord Magus",zone="Blackrock Spire",level=58,type="rareelite",creatureType="Humanoid"},  -- Spirestone Lord Magus
	[9218]={name="Spirestone Battle Lord",zone="Blackrock Spire",level=58,type="rareelite",creatureType="Humanoid"},  -- Spirestone Battle Lord
	[9219]={name="Spirestone Butcher",zone="Blackrock Spire",level=57,type="rareelite",creatureType="Humanoid"},  -- Spirestone Butcher
	[9596]={name="Bannok Grimaxe",zone="Blackrock Spire",level=59,type="rareelite",creatureType="Humanoid"},  -- Bannok Grimaxe
	[9602]={name="Hahk'Zor",zone="Burning Steppes",level=57,type="rare",creatureType="Humanoid"},  -- Hahk'Zor
	[9604]={name="Gorgon'och",zone="Burning Steppes",level=55,type="rare",creatureType="Humanoid"},  -- Gorgon'och
	[9718]={name="Ghok Bashguud",zone="Blackrock Spire",level=59,type="rareelite",creatureType="Humanoid"},  -- Ghok Bashguud
	[9736]={name="Quartermaster Zigris",zone="Blackrock Spire",level=59,type="rareelite",creatureType="Humanoid"},  -- Quartermaster Zigris
	[10077]={name="Deathmaw",zone="Burning Steppes",level=59,type="rare",creatureType="Beast"},  -- Deathmaw
	[10078]={name="Terrorspark",zone="Burning Steppes",level=55,type="rare",creatureType="Demon"},  -- Terrorspark
	[10080]={name="Sandarr Dunereaver",zone="Zul'Farrak",level=45,type="rareelite",creatureType="Humanoid"},  -- Sandarr Dunereaver
	[10081]={name="Dustwraith",zone="Zul'Farrak",level=45,type="rareelite",creatureType="Humanoid"},  -- Dustwraith
	[10082]={name="Zerillis",zone="Zul'Farrak",level=45,type="rareelite",creatureType="Humanoid"},  -- Zerillis
	[10119]={name="Volchan",zones={"Redridge Mountains","Burning Steppes"},level=60,type="rareelite",creatureType="Giant"},  -- Volchan
	[10196]={name="General Colbatann",zone="Winterspring",level=56,type="rareelite",creatureType="Dragonkin"},  -- General Colbatann
	[10197]={name="Mezzir the Howler",zone="Winterspring",level=55,type="rare",creatureType="Humanoid"},  -- Mezzir the Howler
	[10198]={name="Kashoch the Reaver",zone="Winterspring",level=60,type="rareelite",creatureType="Giant"},  -- Kashoch the Reaver
	[10199]={name="Grizzle Snowpaw",zone="Winterspring",level=59,type="rare",creatureType="Humanoid"},  -- Grizzle Snowpaw
	[10200]={name="Rak'shiri",zone="Winterspring",level=59,type="rare",creatureType="Beast"},  -- Rak'shiri
	[10201]={name="Lady Hederine",zone="Winterspring",level=61,type="rareelite",creatureType="Demon"},  -- Lady Hederine
	[10202]={name="Azurous",zone="Winterspring",level=59,type="rareelite",creatureType="Dragonkin"},  -- Azurous
	[10263]={name="Burning Felguard",zone="Blackrock Spire",level=56,type="rareelite",creatureType="Demon"},  -- Burning Felguard
	[10358]={name="Fellicent's Shade",zone="Tirisfal Glades",level=12,type="rare",creatureType="Undead"},  -- Fellicent's Shade
	[10359]={name="Sri'skulk",zone="Tirisfal Glades",level=13,type="rare",creatureType="Beast"},  -- Sri'skulk
	[10376]={name="Crystal Fang",zone="Blackrock Spire",level=60,type="rareelite",creatureType="Beast"},  -- Crystal Fang
	[10393]={name="Skul",zone="Stratholme",level=58,type="rareelite",creatureType="Undead"},  -- Skul
	[10509]={name="Jed Runewatcher",zone="Blackrock Spire",level=59,type="rareelite",creatureType="Humanoid"},  -- Jed Runewatcher
	[10559]={name="Lady Vespia",zone="Ashenvale",level=22,type="rare",creatureType="Humanoid"},  -- Lady Vespia
	[10584]={name="Urok Doomhowl",zone="Blackrock Spire",level=60,type="rareelite",creatureType="Humanoid"},  -- Urok Doomhowl
	[10639]={name="Rorgish Jowl",zone="Ashenvale",level=25,type="rare",creatureType="Humanoid"},  -- Rorgish Jowl
	[10640]={name="Oakpaw",zone="Ashenvale",level=27,type="rare",creatureType="Humanoid"},  -- Oakpaw
	[10641]={name="Branch Snapper",zone="Ashenvale",level=26,type="rare",creatureType="Elemental"},  -- Branch Snapper
	[10642]={name="Eck'alom",zone="Ashenvale",level=27,type="rare",creatureType="Elemental"},  -- Eck'alom
	[10643]={name="Mugglefin",zone="Ashenvale",level=23,type="rare",creatureType="Humanoid"},  -- Mugglefin
	[10644]={name="Mist Howler",zone="Ashenvale",level=22,type="rare",creatureType="Beast"},  -- Mist Howler
	[10647]={name="Prince Raze",zone="Ashenvale",level=32,type="rare",creatureType="Demon"},  -- Prince Raze
	[10808]={name="Timmy the Cruel",zone="Stratholme",level=58,type="rareelite",creatureType="Undead"},  -- Timmy the Cruel
	[10809]={name="Stonespine",zone="Stratholme",level=60,type="rareelite",creatureType="Undead"},  -- Stonespine
	[10821]={name="Hed'mush the Rotting",zone="Eastern Plaguelands",level=57,type="rare",creatureType="Undead"},  -- Hed'mush the Rotting
	[10822]={name="Warlord Thresh'jin",zone="Eastern Plaguelands",level=58,type="rare",creatureType="Humanoid"},  -- Warlord Thresh'jin
	[10823]={name="Zul'Brin Warpbranch",zone="Eastern Plaguelands",level=60,type="rare",creatureType="Humanoid"},  -- Zul'Brin Warpbranch
	[10825]={name="Gish the Unmoving",zone="Eastern Plaguelands",level=57,type="rare",creatureType="Undead"},  -- Gish the Unmoving
	[10826]={name="Lord Darkscythe",zone="Eastern Plaguelands",level=57,type="rare",creatureType="Undead"},  -- Lord Darkscythe
	[10827]={name="Deathspeaker Selendre",zone="Eastern Plaguelands",level=56,type="rare",creatureType="Humanoid"},  -- Deathspeaker Selendre
	[10828]={name="High General Abbendis",zone="Eastern Plaguelands",level=59,type="rareelite",creatureType="Humanoid"},  -- High General Abbendis
	[11447]={name="Mushgog",zone="Feralas",level=60,type="rareelite",creatureType="Elemental"},  -- Mushgog
	[11497]={name="The Razza",zone="Feralas",level=60,type="rareelite",creatureType="Beast"},  -- The Razza
	[11498]={name="Skarr the Unbreakable",zone="Feralas",level=58,type="rareelite",creatureType="Humanoid"},  -- Skarr the Unbreakable
	[11688]={name="Cursed Centaur",zone="Desolace",level=43,type="rare",creatureType="Humanoid"},  -- Cursed Centaur
	[12037]={name="Ursol'lok",zone="Ashenvale",level=32,type="rare",creatureType="Beast"},  -- Ursol'lok
	[12123]={name="Reef Shark",zones={"Westfall","Darkshore","Silverpine Forest"},level=22,type="elite",creatureType="Beast"},  -- Reef Shark
	[12237]={name="Meshlok the Harvester",zone="Maraudon",level=48,type="rareelite",creatureType="Elemental"},  -- Meshlok the Harvester
	[12432]={name="Old Vicejaw",zone="Silverpine Forest",level=14,type="rare",creatureType="Beast"},  -- Old Vicejaw
	[14221]={name="Gravis Slipknot",zone="Alterac Mountains",level=36,type="rare",creatureType="Humanoid"},  -- Gravis Slipknot
	[14222]={name="Araga",zone="Alterac Mountains",level=35,type="rare",creatureType="Beast"},  -- Araga
	[14225]={name="Prince Kellen",zone="Desolace",level=33,type="rare",creatureType="Demon"},  -- Prince Kellen
	[14226]={name="Kaskk",zone="Desolace",level=40,type="rare",creatureType="Demon"},  -- Kaskk
	[14227]={name="Hissperak",zone="Desolace",level=37,type="rare",creatureType="Beast"},  -- Hissperak
	[14228]={name="Giggler",zone="Desolace",level=35,type="rare",creatureType="Beast"},  -- Giggler
	[14229]={name="Accursed Slitherblade",zone="Desolace",level=38,type="rare",creatureType="Humanoid"},  -- Accursed Slitherblade
	[14230]={name="Burgle Eye",zone="Dustwallow Marsh",level=38,type="rare",creatureType="Humanoid"},  -- Burgle Eye
	[14231]={name="Drogoth the Roamer",zone="Dustwallow Marsh",level=37,type="rare",creatureType="Elemental"},  -- Drogoth the Roamer
	[14232]={name="Dart",zone="Dustwallow Marsh",level=38,type="rare",creatureType="Beast"},  -- Dart
	[14233]={name="Ripscale",zone="Dustwallow Marsh",level=39,type="rare",creatureType="Beast"},  -- Ripscale
	[14234]={name="Hayoc",zone="Dustwallow Marsh",level=43,type="rare",creatureType="Beast"},  -- Hayoc
	[14235]={name="The Rot",zone="Dustwallow Marsh",level=44,type="rare",creatureType="Slime"},  -- The Rot
	[14236]={name="Lord Angler",zone="Dustwallow Marsh",level=48,type="rare",creatureType="Humanoid"},  -- Lord Angler
	[14237]={name="Oozeworm",zone="Dustwallow Marsh",level=42,type="rare",creatureType="Beast"},  -- Oozeworm
	[14266]={name="Shanda the Spinner",zone="Loch Modan",level=25,type="rare",creatureType="Beast"},  -- Shanda the Spinner
	[14267]={name="Emogg the Crusher",zone="Loch Modan",level=19,type="rareelite",creatureType="Humanoid"},  -- Emogg the Crusher
	[14268]={name="Lord Condar",zone="Loch Modan",level=16,type="rare",creatureType="Beast"},  -- Lord Condar
	[14269]={name="Seeker Aqualon",zone="Redridge Mountains",level=21,type="rare",creatureType="Elemental"},  -- Seeker Aqualon
	[14270]={name="Squiddic",zone="Redridge Mountains",level=19,type="rare",creatureType="Humanoid"},  -- Squiddic
	[14271]={name="Ribchaser",zone="Redridge Mountains",level=17,type="rare",creatureType="Humanoid"},  -- Ribchaser
	[14272]={name="Snarlflare",zone="Redridge Mountains",level=18,type="rare",creatureType="Dragonkin"},  -- Snarlflare
	[14273]={name="Boulderheart",zone="Redridge Mountains",level=25,type="rare",creatureType="Giant"},  -- Boulderheart
	[14276]={name="Scargil",zone="Hillsbrad Foothills",level=30,type="rare",creatureType="Humanoid"},  -- Scargil
	[14277]={name="Lady Zephris",zone="Hillsbrad Foothills",level=33,type="rare",creatureType="Humanoid"},  -- Lady Zephris
	[14278]={name="Ro'Bark",zone="Hillsbrad Foothills",level=28,type="rare",creatureType="Humanoid"},  -- Ro'Bark
	[14279]={name="Creepthess",zone="Hillsbrad Foothills",level=24,type="rare",creatureType="Beast"},  -- Creepthess
	[14280]={name="Big Samras",zone="Hillsbrad Foothills",level=27,type="rare",creatureType="Beast"},  -- Big Samras
	[14281]={name="Jimmy the Bleeder",zone="Alterac Mountains",level=23,type="rare",creatureType="Humanoid"},  -- Jimmy the Bleeder
	[14339]={name="Death Howl",zone="Felwood",level=49,type="rare",creatureType="Beast"},  -- Death Howl
	[14340]={name="Alshirr Banebreath",zone="Felwood",level=54,type="rare",creatureType="Demon"},  -- Alshirr Banebreath
	[14342]={name="Ragepaw",zone="Felwood",level=51,type="rare",creatureType="Humanoid"},  -- Ragepaw
	[14344]={name="Mongress",zone="Felwood",level=50,type="rare",creatureType="Beast"},  -- Mongress
	[14345]={name="The Ongar",zone="Felwood",level=51,type="rare",creatureType="Slime"},  -- The Ongar
	[14424]={name="Mirelow",zone="Wetlands",level=25,type="rare",creatureType="Elemental"},  -- Mirelow
	[14425]={name="Gnawbone",zone="Wetlands",level=25,type="rare",creatureType="Humanoid"},  -- Gnawbone
	[14426]={name="Harb Foulmountain",zone="Thousand Needles",level=27,type="rare",creatureType="Humanoid"},  -- Harb Foulmountain
	[14427]={name="Gibblesnik",zone="Thousand Needles",level=28,type="rare",creatureType="Humanoid"},  -- Gibblesnik
	[14428]={name="Uruson",zone="Teldrassil",level=8,type="rare",creatureType="Humanoid"},  -- Uruson
	[14429]={name="Grimmaw",zone="Teldrassil",level=11,type="rare",creatureType="Humanoid"},  -- Grimmaw
	[14430]={name="Duskstalker",zone="Teldrassil",level=9,type="rare",creatureType="Beast"},  -- Duskstalker
	[14431]={name="Fury Shelda",zone="Teldrassil",level=8,type="rare",creatureType="Humanoid"},  -- Fury Shelda
	[14432]={name="Threggil",zone="Teldrassil",level=6,type="rare",creatureType="Demon"},  -- Threggil
	[14433]={name="Sludginn",zone="Wetlands",level=30,type="rare",creatureType="Slime"},  -- Sludginn
	[14445]={name="Lord Captain Wyrmak",zone="Swamp of Sorrows",level=45,type="rareelite",creatureType="Dragonkin"},  -- Lord Captain Wyrmak
	[14446]={name="Fingat",zone="Swamp of Sorrows",level=43,type="rare",creatureType="Humanoid"},  -- Fingat
	[14447]={name="Gilmorian",zone="Swamp of Sorrows",level=44,type="rare",creatureType="Humanoid"},  -- Gilmorian
	[14448]={name="Molt Thorn",zone="Swamp of Sorrows",level=42,type="rare",creatureType="Elemental"},  -- Molt Thorn
	[14471]={name="Setis",zone="Silithus",level=62,type="rareelite",creatureType="Humanoid"},  -- Setis
	[14472]={name="Gretheer",zone="Silithus",level=58,type="rare",creatureType="Beast"},  -- Gretheer
	[14473]={name="Lapress",zone="Silithus",level=60,type="rareelite",creatureType="Silithid"},  -- Lapress
	[14474]={name="Zora",zone="Silithus",level=59,type="rareelite",creatureType="Silithid"},  -- Zora
	[14475]={name="Rex Ashil",zone="Silithus",level=57,type="rareelite",creatureType="Silithid"},  -- Rex Ashil
	[14476]={name="Krellack",zone="Silithus",level=56,type="rare",creatureType="Beast"},  -- Krellack
	[14477]={name="Grubthor",zone="Silithus",level=58,type="rare",creatureType="Beast"},  -- Grubthor
	[14478]={name="Huricanian",zone="Silithus",level=58,type="rare",creatureType="Elemental"},  -- Huricanian
	[14479]={name="Twilight Lord Everun",zone="Silithus",level=60,type="rare",creatureType="Humanoid"},  -- Twilight Lord Everun
	[14487]={name="Gluggle",zone="Stranglethorn Vale",level=37,type="rare",creatureType="Humanoid"},  -- Gluggle
	[14488]={name="Roloch",zone="Stranglethorn Vale",level=38,type="rare",creatureType="Humanoid"},  -- Roloch
	[14490]={name="Rippa",zone="Stranglethorn Vale",level=44,type="rare",creatureType="Beast"},  -- Rippa
	[14491]={name="Kurmokk",zone="Stranglethorn Vale",level=42,type="rare",creatureType="Beast"},  -- Kurmokk
	[14492]={name="Verifonix",zone="Stranglethorn Vale",level=42,type="rare",creatureType="Humanoid"},  -- Verifonix
	[210549]={name="Defias Scout",zone="Westfall",level=15,type="elite",creatureType="Humanoid"},  -- Defias Scout
}
