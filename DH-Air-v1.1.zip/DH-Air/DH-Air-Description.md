# DH-Air

**Version 1.1** | Author: **Loopi** | For: *Death Happens* Hardcore guild — Air Service

---

## Summary

DH-Air is a Warlock addon built specifically for running the Death Happens guild's
"Air Service" — the process of summoning large numbers of players to a single
location in WoW Classic Hardcore.

Instead of manually tracking whispers, invites, and turns, DH-Air automates the
repetitive parts of the job so the Warlock can focus on watching chat and reacting
to anything unusual:

- **Auto-Invite** — whisper the Warlock "inv" (or a similar phrase) and you're
  automatically invited to the raid/party.
- **Auto-Queue** — everyone who gets invited is automatically added to the bottom
  of the summon queue, in the order they asked.
- **Auto-Summon** — the Warlock works through the queue one player at a time,
  targeting and casting Ritual of Summoning, waiting for each summon to complete
  or time out before moving to the next person. No duplicate summons.
- **Shared Queue Across Multiple Warlocks** — if more than one Warlock in the
  raid is running DH-Air, they automatically share a single summon queue over
  addon messages. Two Warlocks can run Air Service at the same time without
  ever both spending a shard summoning the same player - each player is
  claimed by exactly one Warlock before casting starts. Self-healing if a
  Warlock disconnects mid-summon; catches up automatically if you join or
  reload mid-session.
- **Customizable Chat Announcements** — every time a new summon begins, DH-Air
  can announce it in any combination of Raid, Group, Guild, and `/say` chat.
  Each channel can be turned on/off independently and has its own fully
  editable message template (default: `Please click to help summon
  {target}!`).
- **Minimap Button** — a standard LibDataBroker/LibDBIcon minimap button using
  the same icon as the Warlock spell Ritual of Summoning. Left-click toggles
  auto-summon on/off (auto-invite keeps running either way); right-click opens
  a menu with Config, Pause/Resume, and Reset Session; drag to reposition.
- **Pause / Resume** — hold the queue in place without losing your spot.
- **Session Reset** — wipe the queue and start fresh for a new Air Service run
  (resets it for every linked Warlock, not just you).
- **Automatic Failure Recovery** — if a summon cast fails (e.g. out of range,
  interrupted), DH-Air retries the same player a few times before pausing
  itself with a clear message, instead of silently stalling or spamming chat
  with repeated failed attempts. If you're sharing the queue, giving up also
  frees the player up for another Warlock to take over.
- **Soul Shard Safeguard** — before every summon attempt, DH-Air checks your
  Soul Shard count. If it's below a configurable minimum (default 2),
  auto-summon pauses itself before targeting or announcing anything, so you
  never get a failed cast or a "please click" message for a summon that
  can't actually happen. It resumes automatically once you've restocked.
- **Configuration Window** — `/dhair config` opens a four-page settings
  window (Options, Messages, Sharing, and About), in the style of a standard
  addon options panel.

DH-Air does **not** replace the Warlock's Soul Shards, positioning, or judgment —
it only automates the bookkeeping (who's next, who's already been summoned,
inviting, and announcing) so summon runs go faster and with fewer mistakes.

---

## Help

### Slash Commands

| Command | Effect |
|---|---|
| `/dhair start` | Turns auto-summon **on**. |
| `/dhair stop` | Turns auto-summon **off**. Auto-invite keeps working. |
| `/dhair pause` | Pauses auto-summon without losing the queue. |
| `/dhair resume` | Resumes a paused queue. |
| `/dhair reset` | Clears the summon queue and session (shared with other DH-Air Warlocks, if sharing is on). |
| `/dhair queue` | Prints the current queue and each player's status to chat. |
| `/dhair shards` | Prints your current Soul Shard count and the configured minimum. |
| `/dhair share on` / `off` | Turns queue sharing with other DH-Air Warlocks on or off. |
| `/dhair peers` | Lists other DH-Air Warlocks seen recently in your raid/party. |
| `/dhair sync` | Re-requests the shared queue from other DH-Air Warlocks (useful after a reload). |
| `/dhair invite on` / `off` | Turns the auto-invite whisper trigger on or off. |
| `/dhair config` | Opens the configuration window. |
| `/dhair` (no argument) | Prints this command list. |

### Minimap Button

DH-Air uses the standard LibDataBroker-1.1 / LibDBIcon-1.0 minimap button,
the same system used by most WoW addons, so it behaves like the minimap
icons you're already used to:

- **Left-click**: toggles auto-summon on/off. The icon dims when off.
  (Auto-invite is independent — it keeps running even when auto-summon is off,
  so you can still queue people up while paused/stopped.)
- **Right-click**: opens a quick menu — Open Config, Pause/Resume, Reset
  Queue/Session.
- **Drag**: reposition the button around the minimap.
- Can be hidden entirely from the Options page in `/dhair config`.

### Configuration Window (`/dhair config`)

The window has a page list on the left:

- **Options** — toggle auto-invite, show/hide the minimap button, set the
  summon timeout (10–90 seconds), set the minimum Soul Shards before
  auto-summon pauses itself (default 2), reset the queue/session, and print
  the current queue.
- **Messages** — enable/disable and customize the announcement text for each
  of Raid, Group, Guild, and `/say`. Use `{target}` anywhere in a message and
  it will be replaced with the name of the player currently being summoned.
  A "Restore Default Messages" button resets all four back to their originals.
- **Sharing** — turn shared-queue mode on/off, see whether it's currently
  active (and in which channel), print the list of other DH-Air Warlocks
  seen recently, and manually re-request the shared queue.
- **About** — shows the addon version, the detected game client version, the
  author (Loopi), and the copyright notice.

### How Auto-Invite Works

Whisper the Warlock a short phrase like `inv`, `invite`, `inv me`, `pls inv`,
etc. The Warlock auto-invites you and adds you to the bottom of the summon
queue (and shares that addition with any other DH-Air Warlocks in the raid).
It intentionally only matches short, whole-phrase requests (not a substring
match) so normal conversation whispers aren't mistaken for an invite request.
There's a short cooldown per player to avoid spam if someone's client
re-sends the same whisper.

### How Auto-Summon Works

1. DH-Air looks at the next player in the queue who hasn't been summoned yet
   and, if sharing is on, isn't already claimed by another DH-Air Warlock.
2. It checks your Soul Shard count. If it's below the configured minimum
   (default 2), auto-summon pauses right there - before targeting anyone or
   sending any chat message - and resumes automatically once you've
   restocked above the minimum (or you can `/dhair resume` manually).
3. If sharing, it broadcasts a claim on that player and waits briefly for a
   competing claim from another Warlock before proceeding (see "Shared Queue"
   below for how conflicts are resolved).
4. It targets that player (they must already be in your raid/party — this
   happens automatically once their invite is accepted).
5. It casts Ritual of Summoning and waits for the game to confirm the ritual
   actually started before announcing anything — this avoids announcing (and
   later wrongly marking someone "summoned") if the cast fails silently, e.g.
   from an invalid target.
6. Once confirmed, it announces in whichever of Raid/Group/Guild/`/say` you've
   enabled, using your custom message for each, and starts the completion
   timeout.
7. It waits for the ritual to complete or hit the configurable timeout
   (default 30 seconds) before moving to the next player.
8. Once a player has been summoned in the session, they won't be queued or
   summoned again (by you or, if sharing, by any other linked Warlock) unless
   you `/dhair reset`.

If a cast fails to start or gets interrupted for a reason other than low
shards (out of range, LoS, etc.), DH-Air retries the same player up to 3
times (a few seconds apart) before pausing auto-summon with a clear chat
message, rather than silently stalling forever or hammering the same failed
cast repeatedly. If sharing is on, giving up also releases the claim so
another Warlock can pick that player up. Use `/dhair resume` once you've
resolved the issue.

### Shared Queue (Multiple Warlocks)

If more than one Warlock in your raid or party is running DH-Air with sharing
enabled (the default), they automatically discover each other and share one
summon queue:

- Whoever gets whispered `inv` adds the player to everyone's queue.
- Before casting on a player, a Warlock broadcasts a claim on them. If two
  Warlocks happen to decide on the same player at the same instant, the
  conflict resolves itself automatically and consistently for everyone
  watching - there's no need to coordinate manually or worry about a race
  wasting a shard.
- Once a player is fully summoned (or times out), that's broadcast too, so
  they're marked done everywhere and won't be re-queued or re-summoned.
- If a Warlock disconnects or reloads mid-claim, that claim expires on its
  own after a couple of minutes so the player doesn't get stuck waiting on
  someone who's no longer there.
- Joining mid-session or reloading your UI automatically requests the current
  queue from other DH-Air Warlocks so you catch up (use `/dhair sync` to
  force this manually).
- Turn it off anytime with `/dhair share off` or the Sharing page in
  `/dhair config` if you'd rather keep your queue private.

### Known Limitations

- DH-Air cannot detect the exact moment a bystander clicks to complete the
  summon portal — the game doesn't expose that to addons. It relies on the
  Ritual of Summoning cast being confirmed and then a timeout window
  (adjustable in Options) before advancing. If a summon finishes early, you
  can always `/dhair reset` and re-queue, or simply let the timeout elapse.
- The Warlock still needs Soul Shards and must be positioned appropriately;
  DH-Air only handles targeting, casting, invites, queueing, and
  announcements.
- Requires being in a raid or party for Ritual of Summoning; players must have
  accepted their invite before they can be targeted/summoned.
- Queue sharing is a lightweight, best-effort protocol, not a guaranteed
  distributed lock. It's specifically designed so that the one thing that
  matters most - never double-summoning the same player - holds up even if
  messages are delayed or a Warlock disconnects; minor differences in queue
  *order* across different Warlocks' screens can happen and are harmless.

---

## Changelog

### 1.1 (first published release)
- Initial release.
- Auto-invite on whisper ("inv" and common variants).
- Auto-add invited players to the summon queue.
- Auto-summon loop: target → cast → confirm → announce → wait for
  completion/timeout → advance, with no duplicate summons within a session.
- Shared summon queue across multiple DH-Air Warlocks in the same raid/party,
  with claim-based conflict resolution, self-healing on disconnect, and
  automatic catch-up sync for late joiners/reloads.
- Customizable, independently toggleable announcements for Raid, Group,
  Guild, and `/say`, with a `{target}` placeholder.
- Standard LibDataBroker/LibDBIcon minimap button (Ritual of Summoning icon)
  with on/off toggle and right-click menu (config, pause/resume, reset).
- Pause / Resume for auto-summon.
- Session reset to clear the queue and summon history.
- Automatic retry-then-pause on repeated cast failures, so a bad target or
  bad positioning can't stall the run silently or spam chat.
- Proactive Soul Shard check before every summon attempt: pauses before
  targeting/announcing if shards are below a configurable minimum (default
  2), and resumes automatically once restocked.
- `/dhair` slash commands: start, stop, pause, resume, reset, queue, shards,
  share on/off, peers, sync, invite on/off, config.
- Configuration window (`/dhair config`) with Options, Messages, Sharing, and
  About pages.
