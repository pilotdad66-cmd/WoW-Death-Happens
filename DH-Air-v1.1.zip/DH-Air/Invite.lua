-- DH-Air Invite.lua
-- Detects whispered invite requests and auto-invites + queues the sender.

local ADDON_NAME, DHAir = ...

-- Phrases that trigger an auto-invite. Matched against the whole,
-- trimmed, lower-cased whisper text (not a substring match), so that
-- normal conversation whispers aren't accidentally treated as requests.
local INVITE_PATTERNS = {
    "^inv$", "^invite$",
    "^inv me$", "^invite me$",
    "^inv please$", "^invite please$",
    "^plz inv$", "^pls inv$", "^inv plz$", "^inv pls$",
    "^can i get an? inv$", "^can i get an? invite$",
    "^can i have an? inv$", "^can i have an? invite$",
    "^need inv$", "^need an? invite$",
    "^inv for air$", "^inv for the air service$",
}

local recentInvites = {}
local INVITE_DEBOUNCE_SECONDS = 20

local function MatchesInvitePattern(msg)
    msg = msg:lower()
    msg = msg:gsub("^%s+", ""):gsub("%s+$", "")
    for _, pattern in ipairs(INVITE_PATTERNS) do
        if msg:match(pattern) then
            return true
        end
    end
    return false
end

local function DoInvite(name)
    if C_PartyInfo and C_PartyInfo.InviteUnit then
        C_PartyInfo.InviteUnit(name)
    else
        InviteUnit(name)
    end
end

-- Called from Core.lua's CHAT_MSG_WHISPER handler.
function DHAir:HandleWhisper(msg, sender)
    if not self.db or not self.db.autoInvite then return end
    if not sender or sender == "" then return end
    if not MatchesInvitePattern(msg) then return end

    local now = GetTime()
    if recentInvites[sender] and (now - recentInvites[sender]) < INVITE_DEBOUNCE_SECONDS then
        return -- avoid spamming repeated invites for the same whisper spam
    end
    recentInvites[sender] = now

    DoInvite(sender)
    self:Print("Auto-invited " .. self:NormalizeName(sender) .. ".")
    if self:QueueAdd(sender) then
        if self.Sync_BroadcastAdd then
            self:Sync_BroadcastAdd(sender)
        end
    end
end
