-- DH-Air Core.lua
-- Addon initialization, saved variables, and central event dispatch.

local ADDON_NAME, DHAir = ...
_G.DHAir = DHAir

DHAir.VERSION = "1.1" -- Bump only with Chris's explicit sign-off.

--------------------------------------------------------------------------
-- Defaults / Saved Variables
--------------------------------------------------------------------------

local DEFAULT_MESSAGE = "Please click to help summon {target}!"

local defaults = {
    active = true,          -- auto-summon on/off (auto-invite is independent of this)
    paused = false,         -- pause auto-summon without turning it fully off
    autoInvite = true,      -- whisper "inv" auto-invite feature
    summonTimeout = 30,     -- seconds to wait for a summon before moving on
    minShards = 2,          -- pause auto-summon if Soul Shards drop below this
    shareQueue = true,      -- share the summon queue with other DH-Air Warlocks in the raid/group
    minimap = {
        hide = false,
    },
    -- Per-channel announcement toggles and customizable message text.
    -- {target} is replaced with the player currently being summoned.
    messages = {
        raid  = { enabled = true,  text = DEFAULT_MESSAGE },
        party = { enabled = true,  text = DEFAULT_MESSAGE },
        guild = { enabled = false, text = "Now summoning {target} for the Air Service." },
        say   = { enabled = true,  text = DEFAULT_MESSAGE },
    },
    queue = {},             -- ordered list of { name = "Player", summoned = false }
    history = {},           -- name -> true once summoned this session
}

DHAir.DEFAULT_MESSAGE = DEFAULT_MESSAGE

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then
                dst[k] = {}
            end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

--------------------------------------------------------------------------
-- Utility
--------------------------------------------------------------------------

function DHAir:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff9482c9DH-Air|r: " .. tostring(msg))
end

--------------------------------------------------------------------------
-- Event Frame
--------------------------------------------------------------------------

DHAir.frame = CreateFrame("Frame")
DHAir.frame:RegisterEvent("ADDON_LOADED")
DHAir.frame:RegisterEvent("PLAYER_LOGIN")
DHAir.frame:RegisterEvent("CHAT_MSG_WHISPER")
DHAir.frame:RegisterEvent("GROUP_ROSTER_UPDATE")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_FAILED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_STOP")
DHAir.frame:RegisterEvent("BAG_UPDATE")
DHAir.frame:RegisterEvent("CHAT_MSG_ADDON")

function DHAir.OnEvent(event, ...)
    if event == "CHAT_MSG_WHISPER" then
        local msg, sender = ...
        if DHAir.HandleWhisper then
            DHAir:HandleWhisper(msg, sender)
        end
    elseif event == "GROUP_ROSTER_UPDATE" then
        if DHAir.TrySummonNext then
            DHAir:TrySummonNext()
        end
        if DHAir.Sync_OnRosterChanged then
            DHAir:Sync_OnRosterChanged()
        end
    elseif event == "UNIT_SPELLCAST_SUCCEEDED"
        or event == "UNIT_SPELLCAST_FAILED"
        or event == "UNIT_SPELLCAST_INTERRUPTED"
        or event == "UNIT_SPELLCAST_STOP" then
        if DHAir.OnSpellcastEvent then
            DHAir:OnSpellcastEvent(event, ...)
        end
    elseif event == "BAG_UPDATE" then
        if DHAir.OnBagUpdate then
            DHAir:OnBagUpdate()
        end
    elseif event == "CHAT_MSG_ADDON" then
        if DHAir.Sync_OnAddonMessage then
            DHAir:Sync_OnAddonMessage(...)
        end
    end
end

DHAir.frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loaded = ...
        if loaded == ADDON_NAME then
            DHAirDB = DHAirDB or {}
            CopyDefaults(defaults, DHAirDB)
            DHAir.db = DHAirDB
        end
        return
    elseif event == "PLAYER_LOGIN" then
        DHAir:Print("v" .. DHAir.VERSION .. " loaded. Type /dhair help for commands.")
        if DHAir.Minimap_Init then
            DHAir.Minimap_Init()
        end
        if DHAir.Sync_Init then
            DHAir:Sync_Init()
        end
        return
    end

    DHAir.OnEvent(event, ...)
end)
