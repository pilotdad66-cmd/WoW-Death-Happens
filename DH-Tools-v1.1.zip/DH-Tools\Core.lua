-- DH-Tools: Core.lua
-- Master addon - lets a guild member activate/deactivate individual
-- modules from one addon. See claude\DH-Tools\PROFILE.md for the module
-- registration contract and claude\DH-Tools\DH-Tools-Design.md for the
-- full design/milestone plan.

local ADDON_NAME = ...

DHTools = DHTools or {}
local ns = DHTools
ns.ADDON_NAME = ADDON_NAME
ns.VERSION = "1.0"

-- === Module registry ===
-- Each module file calls DHTools.RegisterModule(key, def) at load time.
-- def = {
--   name = "Display Name",       -- shown in /dht list and the Tools config page
--   desc = "One short line.",    -- optional: shown under the module's row in
--                                -- the Tools config page (Config.lua) - keep
--                                -- it to a single line, small print
--   default = true/false,        -- state on a fresh install (no saved value yet)
--   OnEnable = function() end,   -- optional: called on enable (incl. at login if already on)
--   OnDisable = function() end,  -- optional: called on disable
-- }
-- Saved enable state lives in DHToolsDB.modules[key]. Module-specific data
-- goes in the module's own DHToolsDB.<key> sub-table - Core.lua never
-- touches those.
ns.modules = {}
ns.moduleOrder = {}

function ns.RegisterModule(key, def)
    if ns.modules[key] then
        error("DH-Tools: module '" .. key .. "' already registered")
    end
    ns.modules[key] = def
    table.insert(ns.moduleOrder, key)
end

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99DH-Tools:|r " .. msg)
end

function ns.InitDB()
    if type(DHToolsDB) ~= "table" then
        DHToolsDB = {}
    end
    if type(DHToolsDB.modules) ~= "table" then
        DHToolsDB.modules = {}
    end
    if type(DHToolsDB.minimap) ~= "table" then
        DHToolsDB.minimap = { hide = false }
    end
    ns.db = DHToolsDB
end

-- Sets up a top-level DH-Tools window with the properties every one of them
-- needs: proper click-to-raise behavior, a guaranteed-opaque background
-- (rather than relying entirely on the template's own backdrop), and
-- dragging scoped to a title-bar-height strip only (registering drag on the
-- whole frame breaks addons like MoveAny that add their own drag handling
-- on top of whatever a frame already exposes). Ported from DH-Air's
-- Core.lua (DHAir:InitStandaloneWindow) - same rationale applies here.
-- Every DH-Tools window should call this once, right after creating its frame.
function ns.InitStandaloneWindow(targetFrame, rightInset)
    targetFrame:SetToplevel(true)

    local bg = targetFrame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.9)

    targetFrame:SetMovable(true)
    targetFrame:EnableMouse(true)

    local dragRegion = CreateFrame("Frame", nil, targetFrame)
    dragRegion:SetPoint("TOPLEFT", 0, 0)
    dragRegion:SetPoint("TOPRIGHT", -(rightInset or 28), 0) -- leaves room for a close button
    dragRegion:SetHeight(24)
    dragRegion:EnableMouse(true)
    dragRegion:RegisterForDrag("LeftButton")
    dragRegion:SetScript("OnDragStart", function() targetFrame:StartMoving() end)
    dragRegion:SetScript("OnDragStop", function() targetFrame:StopMovingOrSizing() end)
    return dragRegion
end

-- Returns true/false for whether `key` is currently enabled: saved state
-- if one exists, else the module's own default.
function ns.IsModuleEnabled(key)
    local saved = ns.db.modules[key]
    if saved ~= nil then return saved end
    local def = ns.modules[key]
    return def ~= nil and def.default or false
end

function ns.SetModuleEnabled(key, enabled)
    local def = ns.modules[key]
    if not def then
        ns.Print("Unknown module: '" .. tostring(key) .. "'. Type /dht list.")
        return
    end
    local wasEnabled = ns.IsModuleEnabled(key)
    ns.db.modules[key] = enabled
    if enabled and not wasEnabled then
        if def.OnEnable then def.OnEnable() end
        ns.Print(def.name .. " enabled.")
    elseif not enabled and wasEnabled then
        if def.OnDisable then def.OnDisable() end
        ns.Print(def.name .. " disabled.")
    end
end

local function ActivateEnabledModules()
    for _, key in ipairs(ns.moduleOrder) do
        if ns.IsModuleEnabled(key) then
            local def = ns.modules[key]
            if def.OnEnable then def.OnEnable() end
        end
    end
end

local function ListModules()
    ns.Print(("Modules (v%s):"):format(ns.VERSION))
    for _, key in ipairs(ns.moduleOrder) do
        local def = ns.modules[key]
        local state = ns.IsModuleEnabled(key) and "|cff33ff99on|r" or "|cffff3333off|r"
        ns.Print(("  %s - %s (%s)"):format(key, def.name, state))
    end
end

-- === Boot ===
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        ns.InitDB()
    elseif event == "PLAYER_LOGIN" then
        ActivateEnabledModules()
        if ns.Minimap_Init then
            ns.Minimap_Init()
        end
        ns.Print(("loaded (v%s). Type /dht help for commands."):format(ns.VERSION))
    end
end)

-- === Slash commands ===
SLASH_DHTOOLS1 = "/dht"
SLASH_DHTOOLS2 = "/dhtools"

SlashCmdList["DHTOOLS"] = function(msg)
    msg = msg or ""
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()

    if cmd == "list" or cmd == "" then
        ListModules()
    elseif cmd == "on" then
        ns.SetModuleEnabled(rest, true)
    elseif cmd == "off" then
        ns.SetModuleEnabled(rest, false)
    elseif cmd == "config" or cmd == "options" then
        if ns.Config_Open then
            ns:Config_Open("Tools")
        else
            ns.Print("Config UI didn't load correctly.")
        end
    elseif cmd == "help" then
        ns.Print(("Commands (v%s):"):format(ns.VERSION))
        ns.Print("  /dht list          - show modules and their on/off state")
        ns.Print("  /dht on <module>   - enable a module")
        ns.Print("  /dht off <module>  - disable a module")
        ns.Print("  /dht config        - open the config window")
        ns.Print("  /dht help          - show this list")
        ns.Print("Each module keeps its own slash commands too (e.g. /mm for Mob Marker).")
    else
        ns.Print("Unknown command: '" .. cmd .. "'. Type /dht help.")
    end
end
