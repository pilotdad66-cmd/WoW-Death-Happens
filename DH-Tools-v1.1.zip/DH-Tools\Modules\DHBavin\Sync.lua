-- DH-Tools: Modules\DHBavin\Sync.lua
-- Milestone 2 (see this folder's DH-Bavin-Design.md): full guild sync
-- protocol for recipient/editors/priority-list. Ports DH-Quests' own
-- Sync.lua pattern almost directly (prefix registration, delta
-- broadcasts, a SYNCREQ/SYNCDATA full-state handshake for late joiners,
-- manual chunking) - see that file for the precedent this mirrors.
-- Replaces Core.lua's Milestone 1 minimal broadcast-only RECIPIENT/
-- EDITORS path (Core.lua's SetRecipient/SetEditors now call into this
-- file's Sync_BroadcastRecipient/Sync_BroadcastEditors instead of
-- talking to C_ChatInfo directly).
--
-- PROTOCOL (all messages are "TYPE|payload", sent via
-- C_ChatInfo.SendAddonMessage to GUILD unless noted; nothing is sent if
-- the player isn't in a guild):
--
--   RECIPIENT|charName      - sender (must be guild leader, verified by
--                             the RECEIVER's own roster cache) is setting
--                             the current recipient; empty charName means
--                             "cleared"
--   EDITORS|n1,n2,...       - sender (must be guild leader) is replacing
--                             the full editor list (comma-joined; an
--                             empty string means "no editors")
--   ITEM|itemID:itemLink    - sender (must currently be the recipient or
--                             an editor, verified by the receiver's own
--                             synced copy of recipient/editors) added or
--                             updated this priority-list entry
--   ITEMGONE|itemID         - sender (same authorization) removed this
--                             entry
--   SYNCREQ                 - "I just joined/reloaded, please send me
--                             your current state" (unconditional - see
--                             GATING below)
--   SYNCDATA|i/total|chunk  - chunked full-state reply to a SYNCREQ,
--                             WHISPERed directly back to the requester
--                             (not broadcast). Reassembled chunks decode
--                             to "recipient|editors|items", where items
--                             is semicolon-joined "itemID:itemLink"
--                             entries. recipient/editors can never
--                             contain "|" (character names can't), so
--                             splitting the reassembled string on the
--                             first two "|" characters is safe even
--                             though itemLink strings themselves are
--                             full of "|" (color codes/hyperlink
--                               escapes) - that's exactly why item
--                             entries are joined with ";" instead and
--                             placed last, not "|".
--
-- GATING: SYNCREQ is unconditional once in a guild (doesn't reveal
-- anything about the requester). A SYNCDATA reply is answered by ANY
-- client, not just the recipient/editors/guild leader - it's relaying
-- already-established state, not asserting new authority, so it isn't
-- re-gated by IsGuildLeader/CanEditList on receipt (same "answering is
-- never gated" idiom DH-Quests' own SYNCREQ handling uses) - this is
-- also required by the Design doc: a late joiner must learn the current
-- recipient "even if the guild leader is offline right now... from
-- whoever answers the handshake." Only actual STATE CHANGES
-- (RECIPIENT/EDITORS/ITEM/ITEMGONE) are re-verified against the
-- receiver's own local state before being applied - never a
-- self-asserted claim in the message itself. This is guild-social-trust
-- security, not cryptographic (same accepted limitation as DH-Air's own
-- permission model - stated plainly there and in PROFILE.md).

local DHTools = DHTools
local ns = DHTools.Bavin

local PREFIX = "DHBavinV1"
-- Assumes no single "itemID:itemLink" entry ever exceeds this length once
-- chunked into a SYNCDATA reply - real item hyperlinks run roughly
-- 60-160 characters, comfortably under this. See ChunkEncoded's comment
-- (ported from DH-Quests, including its 2026-07-27 off-by-one fix) for
-- what happens if that assumption is ever violated.
local MAX_CHUNK_CHARS = 200

-- ns.priorityList[itemID] = { itemID=, itemLink=, addedBy=, addedAt= }.
-- Milestone 3 formally owns "local store & event wiring" for this, but
-- the sync protocol needs somewhere to decode incoming ITEM/SYNCDATA
-- entries into now - same precedent as DH-Quests' Sync.lua populating
-- ns.peers well ahead of that module's own M5 display layer. addedBy/
-- addedAt are LOCAL bookkeeping only (per Design doc, itemLink is cached
-- "so the editor UI can show icon/name/quality without a live tooltip
-- query") - they are NOT part of the wire payload, so a receiving
-- client's copy of addedBy/addedAt reflects ITS OWN receipt, not
-- necessarily the original adder's.
ns.priorityList = ns.priorityList or {}
ns.syncBuffers = ns.syncBuffers or {} -- sender -> { total = n, chunks = {} }

--------------------------------------------------------------------------
-- Low-level send/receive
--------------------------------------------------------------------------

local function AddonSendMessage(text, channel, target)
    if C_ChatInfo and C_ChatInfo.SendAddonMessage then
        C_ChatInfo.SendAddonMessage(PREFIX, text, channel, target)
    elseif SendAddonMessage then
        SendAddonMessage(PREFIX, text, channel, target)
    end
end

local function RegisterPrefix()
    if C_ChatInfo and C_ChatInfo.RegisterAddonMessagePrefix then
        pcall(C_ChatInfo.RegisterAddonMessagePrefix, PREFIX)
    elseif RegisterAddonMessagePrefix then
        pcall(RegisterAddonMessagePrefix, PREFIX)
    end
end

-- Guild-only by design, same as DH-Quests (no RAID/PARTY fallback).
function ns.Sync_Channel()
    if IsInGuild and IsInGuild() then return "GUILD" end
    return nil
end

function ns.Sync_IsActive()
    return ns.Sync_Channel() ~= nil
end

function ns.Sync_Send(msgType, payload)
    local channel = ns.Sync_Channel()
    if not channel then return end
    local text = payload and (msgType .. "|" .. payload) or msgType
    AddonSendMessage(text, channel)
end

function ns.Sync_SendTo(msgType, payload, targetName)
    local text = payload and (msgType .. "|" .. payload) or msgType
    AddonSendMessage(text, "WHISPER", targetName)
end

-- Called from Core.lua on PLAYER_LOGIN. Registers the prefix and asks
-- the guild for current state - SYNCREQ is unconditional (see GATING
-- above), so this fires regardless of the local player's own role.
function ns.Sync_Init()
    RegisterPrefix()
    if ns.Sync_IsActive() then
        ns.Sync_Send("SYNCREQ")
    end
end

--------------------------------------------------------------------------
-- Outbound: RECIPIENT / EDITORS delta broadcasts
--------------------------------------------------------------------------
-- Called from Core.lua's SetRecipient/SetEditors AFTER the guild-leader
-- gate has already passed and local state is already updated - these
-- just announce the change.

function ns.Sync_BroadcastRecipient(name)
    ns.Sync_Send("RECIPIENT", name or "")
end

function ns.Sync_BroadcastEditors(list)
    ns.Sync_Send("EDITORS", table.concat(list or {}, ","))
end

--------------------------------------------------------------------------
-- Priority list: public API + delta broadcasts
--------------------------------------------------------------------------
-- Public entry points a future Milestone 4 editor UI (and today's /dhb
-- additem/removeitem test aid in Core.lua) call directly - gated by
-- CanEditList locally before touching anything, mirroring SetRecipient/
-- SetEditors's own "check first, then mutate, then broadcast" shape.

function ns.AddItem(itemID, itemLink)
    if not ns.CanEditList(UnitName("player")) then return false end
    ns.priorityList[itemID] = {
        itemID = itemID,
        itemLink = itemLink,
        addedBy = UnitName("player"),
        addedAt = GetTime(),
    }
    ns.Sync_BroadcastItem(itemID, itemLink)
    return true
end

function ns.RemoveItem(itemID)
    if not ns.CanEditList(UnitName("player")) then return false end
    ns.priorityList[itemID] = nil
    ns.Sync_BroadcastItemGone(itemID)
    return true
end

function ns.Sync_BroadcastItem(itemID, itemLink)
    ns.Sync_Send("ITEM", itemID .. ":" .. (itemLink or ""))
end

function ns.Sync_BroadcastItemGone(itemID)
    ns.Sync_Send("ITEMGONE", tostring(itemID))
end

--------------------------------------------------------------------------
-- Full-state encode/decode (for SYNCREQ/SYNCDATA)
--------------------------------------------------------------------------

local function EncodeItems()
    local parts = {}
    for itemID, entry in pairs(ns.priorityList) do
        table.insert(parts, itemID .. ":" .. (entry.itemLink or ""))
    end
    return table.concat(parts, ";")
end

-- Splits a reassembled items-string back into { {itemID=, itemLink=}, ... }.
local function DecodeItemEntries(data)
    local entries = {}
    for entry in data:gmatch("[^;]+") do
        local itemID, itemLink = entry:match("^(%d+):(.*)$")
        if itemID then
            table.insert(entries, { itemID = tonumber(itemID), itemLink = itemLink })
        end
    end
    return entries
end

-- Splits an already-encoded string into <=MAX_CHUNK_CHARS pieces,
-- preferring to cut right after a ";" entry boundary where one exists in
-- the window (purely cosmetic - keeps individual item entries whole
-- within a chunk for readability/debugging).
--
-- 2026-07-29 rewrite: the original version (ported verbatim from
-- DH-Quests' ChunkEncoded) DROPPED the separator character at each cut
-- point and relied on the receiver blindly re-inserting a ";" between
-- every chunk on reassembly (table.concat(chunks, ";")). That's only
-- correct if EVERY cut in the original string really was a ";" - true
-- for DH-Quests, where the whole encoded payload is nothing but
-- ";"-joined entries. DH-Bavin's payload is NOT that: it's
-- "recipient|editorsCSV|itemsList", and only the last part uses ";" -
-- the recipient/editors header has none. Any chunk boundary landing in
-- that header (guaranteed for most payloads, since the header comes
-- first) took the "no separator found" branch, which did a bare hard
-- cut - and reassembly still inserted a fabricated ";" there anyway,
-- corrupting the recipient|editors|items split on the receiving end.
-- Fixed by never dropping a character in the first place: each chunk is
-- an exact substring, so reassembly is a plain concat with no separator
-- and is correct regardless of where any cut lands.
local function ChunkEncoded(encoded)
    local chunks = {}
    local remaining = encoded
    while #remaining > 0 do
        if #remaining <= MAX_CHUNK_CHARS then
            table.insert(chunks, remaining)
            remaining = ""
        else
            local window = remaining:sub(1, MAX_CHUNK_CHARS)
            local sepPos = window:find(";[^;]*$")
            local cutAt = sepPos or MAX_CHUNK_CHARS
            table.insert(chunks, remaining:sub(1, cutAt))
            remaining = remaining:sub(cutAt + 1)
        end
    end
    return chunks
end

-- Replies to a SYNCREQ from `targetName` with our current full state
-- (recipient, editors, priority list), chunked and whispered directly
-- back to avoid flooding guild chat. Answered unconditionally - see the
-- file header's GATING note on why this isn't restricted to the
-- recipient/editors/guild leader.
function ns.Sync_SendState(targetName)
    local recipient = (ns.db and ns.db.recipient) or ""
    local editors = table.concat((ns.db and ns.db.editors) or {}, ",")
    local items = EncodeItems()
    -- recipient/editors can never contain "|" (character names can't),
    -- so using it as the separator here - distinct from items' own ";"
    -- separator - is safe. See file header for why this ordering matters.
    local payload = recipient .. "|" .. editors .. "|" .. items

    local chunks = ChunkEncoded(payload)
    local total = #chunks
    for i, chunk in ipairs(chunks) do
        ns.Sync_SendTo("SYNCDATA", i .. "/" .. total .. "|" .. chunk, targetName)
    end
end

--------------------------------------------------------------------------
-- Incoming message handling
--------------------------------------------------------------------------

-- Registered from Core.lua's CHAT_MSG_ADDON handler.
function ns.Sync_OnAddonMessage(prefix, message, _channel, sender)
    if prefix ~= PREFIX then return end
    if not ns.db then return end

    local myName = UnitName("player")
    local senderShort = ns.NormalizeName(sender)
    if senderShort == myName then return end -- ignore our own echo

    local msgType, rest = message:match("^([^|]+)|?(.*)$")
    if not msgType then return end

    -- TESTING_ALLOW_ANYONE_TO_MANAGE (Core.lua) bypasses the guild-leader
    -- check below - see its comment above CanManageRecipient.
    local skipLeaderCheck = ns.TESTING_ALLOW_ANYONE_TO_MANAGE

    if msgType == "RECIPIENT" then
        if not skipLeaderCheck and not ns.IsGuildLeader(senderShort) then return end
        ns.db.recipient = (rest ~= "" and rest) or nil

    elseif msgType == "EDITORS" then
        if not skipLeaderCheck and not ns.IsGuildLeader(senderShort) then return end
        local list = {}
        if rest ~= "" then
            for name in rest:gmatch("[^,]+") do
                table.insert(list, name)
            end
        end
        ns.db.editors = list

    elseif msgType == "ITEM" then
        if not ns.CanEditList(senderShort) then return end
        local itemID, itemLink = rest:match("^(%d+):(.*)$")
        if itemID then
            itemID = tonumber(itemID)
            ns.priorityList[itemID] = {
                itemID = itemID,
                itemLink = itemLink,
                addedBy = senderShort,
                addedAt = GetTime(),
            }
        end

    elseif msgType == "ITEMGONE" then
        if not ns.CanEditList(senderShort) then return end
        local itemID = tonumber(rest)
        if itemID then
            ns.priorityList[itemID] = nil
        end

    elseif msgType == "SYNCREQ" then
        ns.Sync_SendState(sender)

    elseif msgType == "SYNCDATA" then
        local header, data = rest:match("^(%d+/%d+)|(.*)$")
        if not header then return end
        local i, total = header:match("^(%d+)/(%d+)$")
        i, total = tonumber(i), tonumber(total)
        if not i or not total then return end

        ns.syncBuffers[sender] = ns.syncBuffers[sender] or { total = total, chunks = {} }
        local buf = ns.syncBuffers[sender]
        buf.chunks[i] = data

        local received = 0
        for _ in pairs(buf.chunks) do received = received + 1 end
        if received >= buf.total then
            -- Plain concat, no inserted separator - each chunk is an
            -- exact substring (see ChunkEncoded's 2026-07-29 comment),
            -- so this is the exact original payload regardless of where
            -- any cut landed.
            local fullData = table.concat(buf.chunks)
            ns.syncBuffers[sender] = nil

            local recipient, editorsStr, itemsEncoded = fullData:match("^([^|]*)|([^|]*)|(.*)$")
            if recipient then
                -- Relayed state, not a fresh claim - not re-gated by
                -- IsGuildLeader (see file header's GATING note).
                ns.db.recipient = (recipient ~= "" and recipient) or nil
                local list = {}
                if editorsStr ~= "" then
                    for name in editorsStr:gmatch("[^,]+") do
                        table.insert(list, name)
                    end
                end
                ns.db.editors = list
                for _, entry in ipairs(DecodeItemEntries(itemsEncoded)) do
                    ns.priorityList[entry.itemID] = {
                        itemID = entry.itemID,
                        itemLink = entry.itemLink,
                        addedBy = nil,
                        addedAt = GetTime(),
                    }
                end
            end
        end
    end
end
