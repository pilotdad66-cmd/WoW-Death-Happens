# DH-Bavin v1.0 - Design & Milestone Plan
created: 2026-07-28

Every guild member mails spare items to the same collector character (today,
Bavin). This module lets that collector (or anyone the guild leader
delegates) publish a priority want-list, highlights matching items in
every guildmate's own bags, and adds a one-click mailbox helper that
attaches a matching item and addresses the mail to whoever the guild
leader has currently designated as the collector. This doc is the working
plan; STATUS.md tracks which milestone is actually in progress. Once code
and this doc diverge, the code is ground truth (same convention as
DH-Air-v2-Design.md and DH-Quests-Design.md).

## Naming note
The module is named DH-Bavin for recognition (Bavin is who this solves a
problem for today), but the *recipient* is a configurable role, not a
hardcoded character - see "Recipient designation" below. If the collector
role ever passes to someone else, the module name stays DH-Bavin; only
its config changes.

## Decisions made 2026-07-28

**Packaging: DH-Tools module, integrated (not standalone-optional).**
Ships as a DH-Tools module from the start - config page + minimap entry
via DH-Tools' framework, same visible pattern as Mob Marker and Quests.
Unlike DH-Quests, there is no stated intent to spin this off as its own
addon later, so it does not need DH-Quests' "standalone-optionality"
scaffolding. It still gets its own subfolder and namespace
(src\DH-Tools\Modules\DHBavin\) purely for code organization, since it has
enough moving parts (sync protocol, bag hook, mailbox hook, config page)
to warrant separate files the way DHQuests' does.

**Open decision for Chris: SavedVariables placement.** Two options:
(a) DHToolsDB.bavin sub-table, per DH-Tools' normal module contract
(Mob Marker's pattern), or (b) its own top-level DHBavinDB table, per
DH-Quests' pattern (chosen there for standalone-optionality, which
doesn't apply here). Recommendation: (a), since there's no spinoff
intent - but flagging as open rather than assuming, per README's
system-maintenance rule. Default to (a) unless corrected before M1.

**Command:** `/dhb`, matching `/mm` and `/dhq` convention.

## Recipient designation (guild leader only)

Only one character at a time is "the collector" - the mailbox helper
addresses mail to this character. The guild leader sets it from the
Bavin config page (a dropdown built from the local guild roster cache,
same roster cache pattern DH-Air/DH-Quests already build from
GetGuildRosterInfo, online or offline members both selectable).

Broadcast on change: `RECIPIENT|charName`. A receiving client only
accepts this if the sender is verified, against the RECEIVER's OWN
guild roster cache, to hold rankIndex 0 (Guild Master) at the moment
of receipt - never self-asserted. This is the same idiom DH-Air's
Sync.lua already uses for raid-leader/assist verification (see its
HasPermission checks) applied to guild rank instead of raid rank.

The current recipient is part of the SYNCREQ/SYNCDATA handshake payload
(like DH-Quests' peer state), so a player who logs in after the setting
was last changed - even if the guild leader is offline right now - still
learns the current recipient from whoever answers the handshake.

If no recipient has ever been set, the module is inert: no highlighting,
no mailbox helper, and the config page tells the guild leader it needs
configuring.

## Editor delegation (guild leader only)

The current recipient can always edit their own priority list. The
guild leader can additionally name other guild members as editors -
this is additive, not a replacement of the recipient's own edit rights.

Broadcast on change: `EDITORS|name1,name2,...` (full replace list, same
"send the whole small set" simplicity as other short lists in this
codebase). Same guild-leader-verification rule as RECIPIENT above.
Editor set is also part of the SYNCREQ/SYNCDATA handshake.

The Bavin config page's editor picker is a multi-select built from the
same guild roster cache as the recipient dropdown (again, online or
offline members both selectable, since roster data persists for offline
members).

## Priority list data model

A set of entries, keyed by itemID (the only reliable match key):
`{ itemID, itemLink (cached for display only), addedBy, addedAt }`.
Editors add entries either by shift-click-linking an item into an edit
box (standard addon idiom) or, while their own bags are open, an
"add to Bavin's list" button on a matching bag slot - both paths resolve
to itemID immediately, itemLink is stored only so the editor UI can show
icon/name/quality without a live tooltip query.

Broadcasts on change: `ITEM|itemID:itemLink` and `ITEMGONE|itemID`,
gated the same way as RECIPIENT/EDITORS - sender must be, per the
RECEIVER's own synced copy of recipient+editors, currently authorized to
edit. Like DH-Air's own permission model, this is guild-social-trust
security (a modified client could still forge a message) not
cryptographic proof - stated plainly here rather than assumed solved,
same spirit as DH-Air's own documented limitation.

## Guild sync protocol (Milestone 2)

Direct port of DH-Air's Sync.lua / DH-Quests' Sync.lua pattern rather
than a fresh design: prefix registration (`DHBavinV1`), delta broadcasts
(RECIPIENT/EDITORS/ITEM/ITEMGONE) to GUILD, a SYNCREQ/SYNCDATA handshake
on login for late joiners carrying full state (recipient, editors,
entire priority list), and manual chunking at the same ~200-char budget
DH-Air/DH-Quests use - revisit only if in-game testing shows throttling
problems, per existing precedent.

## In-bag highlighting (Milestone 5)

Every client with a recipient configured hooks its own container item
buttons and draws a highlight (border/glow) on any slot whose itemID is
in the current priority list. This is a Blizzard-frame hook, not a
standalone window (bag frames can't be replaced), so the exact hook
point against this client's Classic Era bag button templates
(Interface 11509) is NOT yet verified - flagged as a real risk, same
category as DH-Quests' GetQuestLogTitle field-order surprise in M1.

## Mailbox helper (Milestone 5)

Only active while Blizzard's SendMailFrame is open (MAIL_SHOW event) and
a recipient is configured:
- A "Fill recipient" button sets the To field to the configured
  collector's name - a button, not silent auto-fill, so it never
  overwrites something the player already typed.
- Any bag slot matching the priority list gets an overlay button that
  picks the item up (PickupContainerItem) and drops it into the next
  open attachment slot. Bulk-mailing addons (e.g. Postal) already
  automate this exact action, so it's precedented, but the precise call
  sequence against this client's SendMailAttachment buttons is NOT yet
  verified in-game - flagged as a risk, same spirit as the bag-hook risk
  above.

## Milestones

**M1 - Data model & permission plumbing.** Guild-roster-verified
guild-leader check (rankIndex 0, read from the same roster-cache pattern
DH-Air/DH-Quests already build). RECIPIENT/EDITORS local storage and
broadcast (no priority list yet). Bavin config page stub: recipient
dropdown + editor multi-select, guild-leader-only, read-only view for
everyone else.

**M2 - Guild sync protocol.** Port Sync.lua pattern (prefix `DHBavinV1`).
ITEM/ITEMGONE deltas, SYNCREQ/SYNCDATA handshake carrying recipient,
editors, and the full priority list.

**M3 - Local store & event wiring.** Priority-list cache; re-verify
recipient/editor authorization on GUILD_ROSTER_UPDATE (guild leader
changes, an editor leaves the guild, etc. - authorization is always
re-checked live against current roster, never cached permanently).

**M4 - Settings UI.** Full Bavin config page: guild-leader controls
(recipient dropdown, editor multi-select) plus the priority-list editor
(item-link input, remove buttons) shown to the recipient and any current
editor. Reachable via `/dhb config` plus DH-Tools' own Tools page.

**M5 - Bag highlighting & mailbox helper.** The two Blizzard-frame-hook
features, isolated into their own milestone given their unverified-API
risk (see both sections above) - mirrors how DH-Quests isolated Board.lua
into its own milestone as the newest/least-proven piece.

**M6 - Test & package.** Headless Lua harness mirroring DH-Quests'
tests\harness.lua, including permission-check tests modeled on DH-Air's
harness_shared_queue.lua leader/assist tests (recipient/editor grants and
refusals, verified-by-receiver-not-self-asserted). Confirm
build-test-zip.ps1 -Module DH-Tools stages the new subfolder correctly.
In-game test pass with Chris before any milestone is called done, per
README's testing rule.

## Deferred to a later version (not in this plan)
- Auto-filling the mail body/subject.
- A "claimed" state so two guildmates don't both mail the same rare item
  redundantly (nice-to-have, not core to v1).
- Any UI for the recipient to mark an item "received" and remove it from
  the list automatically (v1 requires manual list edits).
