-- DH-Tools: Modules\DHBavin\Core.lua
-- "Bavin" module - lets the guild's designated mail collector (or
-- guild-leader-delegated editors) publish a priority want-list; matching
-- items get highlighted in every guildmate's bags plus a mailbox helper
-- to send them. See claude\DH-Bavin\PROFILE.md and this folder's
-- DH-Bavin-Design.md for the full concept and 6-milestone plan.
--
-- MILESTONE 1: guild-roster-verified guild-leader permission check
-- (rankIndex 0), RECIPIENT/EDITORS local storage, config page.
--
-- MILESTONE 2 (this file's networking bits moved OUT to Sync.lua): full
-- guild sync protocol - see Sync.lua's header for the wire format.
-- RECIPIENT/EDITORS sending now goes through Sync.lua's broadcast
-- functions instead of this file talking to C_ChatInfo directly, and
-- CHAT_MSG_ADDON/PLAYER_LOGIN below call into Sync.lua's entry points
-- (ns.Sync_OnAddonMessage/ns.Sync_Init) - same split DH-Quests' own
-- Core.lua/Sync.lua use. No bag hook or mailbox hook yet (M5).
--
-- Ships as a normal DH-Tools module (DHTools.RegisterModule), unlike
-- DH-Quests: no standalone-spinoff scaffolding. SavedVariables live in
-- their own top-level DHBavinDB (plain, account-wide - see ns.InitDB's
-- comment below for why this changed 2026-07-29 from the originally
-- decided DHToolsDB.bavin sub-table), see PROFILE.md.

local DHTools = DHTools
DHTools.Bavin = DHTools.Bavin or {}
local ns = DHTools.Bavin

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99DH-Bavin:|r " .. msg)
end

-- 2026-07-29: ns.db is DHBavinDB, its own top-level SavedVariables (see
-- DH-Tools.toc) - NOT DHToolsDB.bavin anymore, and deliberately plain
-- SavedVariables, not SavedVariablesPerCharacter. Recipient/editors are a
-- GUILD-wide setting, not a per-character preference the way Mob
-- Marker's icon list is - the old per-character scope (DHToolsDB.bavin)
-- meant switching characters, or logging a fresh alt, showed an empty
-- recipient/editor list even though it had just been set on another
-- character, with nothing to restore it short of some other guildmate
-- happening to be online to answer this client's SYNCREQ. This is
-- exactly the symptom Chris hit 2026-07-29. DHBavinDB is shared by every
-- character on THIS WoW account, so that specific case no longer
-- depends on sync at all. Getting the guild leader's setting onto every
-- OTHER guildmate's own computer (a different account entirely) is
-- still, and can only be, the SYNCREQ/SYNCDATA handshake's job (see
-- Sync.lua) - that part remains unverified in real two-player testing,
-- see STATUS.md.
function ns.InitDB()
    DHTools.InitDB() -- still needed: module enable/disable state (per-
                      -- character, intentionally - see PROFILE.md) lives
                      -- in DHToolsDB.modules, unrelated to this DB.
    if type(DHBavinDB) ~= "table" then
        DHBavinDB = {}
    end
    ns.db = DHBavinDB
    if type(ns.db.editors) ~= "table" then
        ns.db.editors = {}
    end
    -- One-time migration: carry forward anything already saved under the
    -- old per-character location so this character's own prior test data
    -- (recipient/editors set before this fix) isn't lost by the move.
    local oldDb = DHTools.db and DHTools.db.bavin
    if type(oldDb) == "table" then
        if ns.db.recipient == nil and oldDb.recipient then
            ns.db.recipient = oldDb.recipient
        end
        if #ns.db.editors == 0 and oldDb.editors and #oldDb.editors > 0 then
            ns.db.editors = oldDb.editors
        end
    end
    -- ns.db.recipient stays nil until the guild leader sets one - the
    -- module is inert (no highlighting/mailbox helper, once those land in
    -- M5) until then, per Design doc's "Recipient designation" section.
end

--------------------------------------------------------------------------
-- Guild roster cache (rankIndex-aware)
--------------------------------------------------------------------------
-- Mirrors DH-Air/DH-Quests' own Core.lua roster-cache pattern
-- (normalizedName -> {...}), extended with rankIndex - unlike either of
-- those modules, Bavin's permission model needs to know who's rank 0
-- (Guild Master). Rebuilt on GUILD_ROSTER_UPDATE.
ns.guildRoster = ns.guildRoster or {}

local function NormalizeName(name)
    return name and name:match("^([^-]+)") or name
end
ns.NormalizeName = NormalizeName

function ns.RequestGuildRoster()
    if not IsInGuild() then return end
    if C_GuildInfo and C_GuildInfo.GuildRoster then
        pcall(C_GuildInfo.GuildRoster)
    elseif GuildRoster then
        pcall(GuildRoster)
    end
end

function ns.UpdateGuildRosterCache()
    for k in pairs(ns.guildRoster) do ns.guildRoster[k] = nil end
    if not IsInGuild() then return end

    local numMembers = GetNumGuildMembers and GetNumGuildMembers() or 0
    for i = 1, numMembers do
        local name, _, rankIndex, _, _, _, _, _, isOnline = GetGuildRosterInfo(i)
        if name then
            ns.guildRoster[NormalizeName(name)] = { online = (isOnline == true), rankIndex = rankIndex }
        end
    end
end

-- Sorted list of every known guild member's normalized name (online or
-- offline both included) - feeds the recipient dropdown and editor
-- picker, per Design doc's "online or offline both selectable" note.
function ns.GetRosterNames()
    local names = {}
    for name in pairs(ns.guildRoster) do
        table.insert(names, name)
    end
    table.sort(names)
    return names
end

--------------------------------------------------------------------------
-- Permission model
--------------------------------------------------------------------------
-- TEMPORARY (Chris, 2026-07-28): true bypasses every guild-leader check
-- below (both CanManageRecipient's local gate AND Sync.lua's
-- receive-side verification of incoming RECIPIENT/EDITORS messages) so
-- Chris can test recipient/editor assignment on a character that isn't
-- actually the guild leader. Set back to false (or delete this override
-- and its call sites here and in Sync.lua) before treating the real
-- permission enforcement as verified - the design doc's whole permission
-- model assumes this is off. Lives on `ns` (not a plain local) so
-- Sync.lua can see it too.
ns.TESTING_ALLOW_ANYONE_TO_MANAGE = true

-- TEMPORARY (Chris, 2026-08-03): named full-permission override,
-- mirroring DH-Air's own Core.lua FULL_PERMISSION_OVERRIDE_NAME idiom
-- exactly - Loopidot always counts as the guild leader for Bavin's
-- purposes, independent of actual guild rank AND independent of
-- TESTING_ALLOW_ANYONE_TO_MANAGE above (that flag is meant to be turned
-- off eventually per its own comment; this override is not - it's meant
-- to stick around). Baked into IsGuildLeader itself, not a separate
-- check at each call site, so every caller honors it identically: the
-- LOCAL CanManageRecipient gate below, AND Sync.lua's RECEIVE-SIDE
-- verification of incoming RECIPIENT/EDITORS broadcasts (both call
-- ns.IsGuildLeader, never trusting a self-asserted claim in the message
-- itself - same idiom DH-Air's UnitHasAuthority/IsGuildOfficer use for
-- their own Loopidot override).
local FULL_PERMISSION_OVERRIDE_NAME = "Loopidot"

-- True only if `name` is verifiably rankIndex 0 (Guild Master) in THIS
-- client's own guild roster cache right now - never trusts a
-- self-asserted claim in a network message. Fails CLOSED (false) if the
-- roster hasn't loaded or the name isn't a known member: an unverifiable
-- admin action should be refused, not allowed through - unlike DH-Air's
-- IsGuildMember, which fails open for its own lower-stakes purpose.
function ns.IsGuildLeader(name)
    if not name then return false end
    if FULL_PERMISSION_OVERRIDE_NAME and NormalizeName(name) == FULL_PERMISSION_OVERRIDE_NAME then
        return true
    end
    local entry = ns.guildRoster[NormalizeName(name)]
    return entry ~= nil and entry.rankIndex == 0
end

-- Whether the LOCAL player can manage the recipient/editors list right now.
function ns.CanManageRecipient()
    if ns.TESTING_ALLOW_ANYONE_TO_MANAGE then return true end
    return ns.IsGuildLeader(UnitName("player"))
end

-- Whether `name` currently has edit rights on the priority list: either
-- they're the recipient, or the guild leader has additively named them an
-- editor. The priority list itself doesn't exist until M3 - this is here
-- now so M1's config-page stub can show who has edit rights, and so M2/M3
-- can reuse it unchanged.
function ns.CanEditList(name)
    if not name or not ns.db then return false end
    local norm = NormalizeName(name)
    if ns.db.recipient and NormalizeName(ns.db.recipient) == norm then return true end
    for _, editor in ipairs(ns.db.editors) do
        if NormalizeName(editor) == norm then return true end
    end
    return false
end

--------------------------------------------------------------------------
-- RECIPIENT / EDITORS: local set + broadcast
--------------------------------------------------------------------------
-- Sending/receiving now lives in Sync.lua (Milestone 2's full protocol) -
-- these just update local state (guild-leader-gated) and hand off to
-- Sync.lua's broadcast functions, same call-through pattern DH-Quests'
-- Core.lua uses for its own Sync_BroadcastQuest/Sync_BroadcastQuestGone.
-- Returns true/false so the config page can show a refusal instead of
-- silently no-opping.
function ns.SetRecipient(name)
    if not ns.CanManageRecipient() then return false end
    ns.db.recipient = name
    if ns.Sync_BroadcastRecipient then ns.Sync_BroadcastRecipient(name) end
    return true
end

-- Full-replace, guild-leader-only - same "send the whole small set"
-- simplicity as the Design doc's other short lists.
function ns.SetEditors(list)
    if not ns.CanManageRecipient() then return false end
    ns.db.editors = list
    if ns.Sync_BroadcastEditors then ns.Sync_BroadcastEditors(list) end
    return true
end

--------------------------------------------------------------------------
-- Event wiring
--------------------------------------------------------------------------
ns.frame = CreateFrame("Frame")
ns.frame:RegisterEvent("PLAYER_LOGIN")
ns.frame:RegisterEvent("GUILD_ROSTER_UPDATE")
ns.frame:RegisterEvent("CHAT_MSG_ADDON")
-- 2026-08-03: gated on DHTools.IsModuleEnabled("bavin"), same contract
-- every other module follows (see claude\DH-Tools\PROFILE.md) - this was
-- previously the one module that never checked it at all, so disabling
-- Bavin in the Tools config page didn't actually stop anything (roster
-- caching, guild sync init, and incoming CHAT_MSG_ADDON traffic all kept
-- running). One check at the top of the shared handler covers all three
-- events, same "return immediately" style Mob Marker's event handler
-- uses.
ns.frame:SetScript("OnEvent", function(_, event, ...)
    if not DHTools.IsModuleEnabled("bavin") then return end
    if event == "PLAYER_LOGIN" then
        if ns.Sync_Init then ns.Sync_Init() end
        ns.RequestGuildRoster()
        if ns.TESTING_ALLOW_ANYONE_TO_MANAGE then
            ns.Print("|cffff3333TESTING MODE:|r guild-leader check is disabled - anyone can set the recipient/editors. See TESTING_ALLOW_ANYONE_TO_MANAGE in Core.lua.")
        end
    elseif event == "GUILD_ROSTER_UPDATE" then
        ns.UpdateGuildRosterCache()
    elseif event == "CHAT_MSG_ADDON" then
        if ns.Sync_OnAddonMessage then ns.Sync_OnAddonMessage(...) end
    end
end)

--------------------------------------------------------------------------
-- Slash command
--------------------------------------------------------------------------
local function ShowHelp()
    ns.Print("Commands:")
    ns.Print("  /dhb                  - show the current recipient/editors/item count")
    ns.Print("  /dhb config           - open the Bavin settings page")
    ns.Print("  /dhb items            - list the priority list's current items")
    ns.Print("  /dhb additem <link>   - shift-click an item after typing this to add it (recipient/editor only) - temporary test aid ahead of Milestone 4's real editor UI")
    ns.Print("  /dhb removeitem <id>  - remove an item by itemID (recipient/editor only)")
    ns.Print("  /dhb on               - enable the Bavin module")
    ns.Print("  /dhb off              - disable the Bavin module")
    ns.Print("  /dhb help             - show this list")
    ns.Print("Recipient/editors are set from the config page (guild leader only).")
end

local function ShowStatus()
    if not ns.db then
        ns.Print("Not initialized yet.")
        return
    end
    ns.Print("Recipient: " .. (ns.db.recipient or "|cffff3333not set|r"))
    if #ns.db.editors == 0 then
        ns.Print("Editors: none")
    else
        ns.Print("Editors: " .. table.concat(ns.db.editors, ", "))
    end
    local itemCount = 0
    if ns.priorityList then
        for _ in pairs(ns.priorityList) do itemCount = itemCount + 1 end
    end
    ns.Print("Priority list: " .. itemCount .. " item(s) - see /dhb items")
end

-- Temporary test aid for the priority-list protocol ahead of Milestone
-- 4's real editor UI (same idiom DH-Quests used: an ad-hoc slash command
-- to exercise the sync protocol before real UI existed for it - see that
-- module's history of a since-removed "/dhq broadcast" test aid).
local function ShowItems()
    if not ns.priorityList or next(ns.priorityList) == nil then
        ns.Print("Priority list is empty.")
        return
    end
    for itemID, entry in pairs(ns.priorityList) do
        ns.Print(itemID .. ": " .. (entry.itemLink or "?"))
    end
end

SLASH_DHBAVIN1 = "/dhb"
SlashCmdList["DHBAVIN"] = function(msg)
    msg = msg or ""
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()

    if cmd == "" then
        ShowStatus()
    elseif cmd == "config" then
        if DHTools.Config_Open then
            DHTools:Config_Open("Bavin")
        else
            ns.Print("Config UI didn't load correctly.")
        end
    elseif cmd == "items" then
        ShowItems()
    elseif cmd == "additem" then
        if not ns.AddItem then
            ns.Print("Priority-list sync didn't load correctly.")
            return
        end
        local itemID = rest:match("item:(%d+)")
        if not itemID then
            ns.Print("Usage: /dhb additem <shift-click an item link here>")
            return
        end
        if ns.AddItem(tonumber(itemID), rest) then
            ns.Print("Added to the priority list: " .. rest)
        else
            ns.Print("Refused - you must be the recipient or an editor.")
        end
    elseif cmd == "removeitem" then
        if not ns.RemoveItem then
            ns.Print("Priority-list sync didn't load correctly.")
            return
        end
        local itemID = tonumber(rest) or rest:match("item:(%d+)")
        itemID = tonumber(itemID)
        if not itemID then
            ns.Print("Usage: /dhb removeitem <itemID or item link>")
            return
        end
        if ns.RemoveItem(itemID) then
            ns.Print("Removed itemID " .. itemID .. " from the priority list.")
        else
            ns.Print("Refused - you must be the recipient or an editor.")
        end
    elseif cmd == "on" then
        DHTools.SetModuleEnabled("bavin", true)
    elseif cmd == "off" then
        DHTools.SetModuleEnabled("bavin", false)
    elseif cmd == "help" then
        ShowHelp()
    else
        ns.Print("Unknown command: '" .. cmd .. "'")
        ShowHelp()
    end
end

--------------------------------------------------------------------------
-- Register with DH-Tools
--------------------------------------------------------------------------
DHTools.RegisterModule("bavin", {
    name = "Bavin",
    desc = "Lets the guild's mail collector publish a priority want-list. Bag highlighting and the mailbox helper land in a later milestone.",
    default = true,
    OnEnable = ns.InitDB,
})
