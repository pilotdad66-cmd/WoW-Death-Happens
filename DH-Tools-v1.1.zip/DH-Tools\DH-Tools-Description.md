# DH-Tools

**Version 1.1** | Author: **Loopi** | For: *Death Happens* Hardcore guild

---

## Summary

DH-Tools is the Death Happens guild's all-in-one utility addon: instead of
installing a separate addon for every guild tool, enable or disable each
one individually from a single config window.

- **Module Toggle Framework** — the Tools page (`/dht config`) lists every
  available module with a one-line description and an on/off checkbox.
  Turn on only what you need; more modules will be added here over time.
- **Mob Marker** — automatically marks specific mobs with a raid-target
  icon on mouseover, plus a configurable Ctrl+click hotkey to mark/unmark
  whatever's under your cursor on demand. Fully customizable icon
  assignments per mob and hotkey modifier/mouse button, via `/mm config`.
- **Shared Quests** — see which group and elite quests your online
  guildmates currently have, so you can find people to group up with.
  Broadcasts your own quest log over guild addon messages (Individual,
  Group, Elite, and Class categories, each independently toggleable, and
  entirely opt-in), and shows everyone else's in a sortable, filterable
  window (`/dhq`) — filter to online-only, sort by player, quest, or
  character level, and invite a matching player straight from the row.
- **Bavin Wants** — a guild-wide priority want-list: see it anytime from
  the minimap menu ("Bavin Wants → See List") or `/dhb items`. The guild
  leader (or a designated editor) manages the recipient and the list from
  a dedicated Config page.
- **DH-Air Submenu** — quick access to DH-Air's Board and Config windows,
  its destination picker (grouped by Flight Points/continent and Dungeon
  Stones, plus an officer-gated Destination Config shortcut), and one-click
  toggles for Join Queue, Am Summoner, Am Clicker, Auto Invite, and Auto
  Summons, color-coded green/red for current state — all without leaving
  the minimap menu. DH-Air itself stays a separate, standalone addon; this
  is a thin shortcut into it, shown only if DH-Air is installed.
- **Minimap Button** — left-click opens DH-Tools' own Config window
  directly; right-click opens the full menu (Mob Marker, Quests, DH-Air,
  Bavin Wants, Settings, About), with expandable submenus for anything
  with more than one option.
- **DH-Air Status** — the Tools page shows whether DH-Air (the guild's
  Warlock summon-coordination addon) is installed. DH-Air stays a separate,
  standalone addon rather than folding into DH-Tools, so this is a status
  indicator, not a toggle — install DH-Air on its own if you want it.

DH-Tools does **not** replace any of its modules' individual settings or
judgment calls — it's a shared shell that lets you pick which guild tools
you actually want running, all managed from one place.

---

## Changelog

### 1.1 (first published release, beta)
- **Module Toggle Framework** — Tools page (`/dht config`) lists every
  module with a one-line description and an on/off checkbox; Mob Marker,
  Shared Quests, and Bavin Wants all correctly stop responding to events
  when turned off (not just their own slash commands).
- **Mob Marker** — auto-marks specific mobs with a raid-target icon on
  mouseover or nameplate sighting, plus a configurable Ctrl+click hotkey.
- **Shared Quests** — opt-in guild quest-sharing and lookup window.
- **Bavin Wants** — guild-wide want-list, viewable by everyone, editable
  by the guild leader or a designated editor (with a testing override
  currently enabled — see in-game notes).
- **Minimap menu** — real expandable-submenu dropdown (left-click: Config,
  right-click: full menu) covering every module above plus a DH-Air
  shortcut submenu.
- **DH-Air integration** — status indicator on the Tools page, plus the
  minimap's DH-Air submenu described above, for the separately-installed
  DH-Air addon.

This is the first CurseForge release and is tagged **beta** — the module
framework, Bavin Wants, and the minimap menu have not yet been verified
against a live multi-user guild session (see in-game notes / report issues
to Loopi).
