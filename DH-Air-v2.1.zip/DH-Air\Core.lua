-- DH-Air Core.lua
-- Addon initialization, saved variables, and central event dispatch.

local ADDON_NAME, DHAir = ...
_G.DHAir = DHAir

DHAir.VERSION = "2.0" -- Bump only with Chris's explicit sign-off.

--------------------------------------------------------------------------
-- Defaults / Saved Variables
--------------------------------------------------------------------------

local DEFAULT_MESSAGE = "Please click to help summon {target}!"

local defaults = {
    active = true,          -- auto-summon on/off (auto-invite is independent of this)
    paused = false,         -- pause auto-summon without turning it fully off
    autoInvite = true,      -- whisper "inv" auto-invite feature
    summonTimeout = 30,     -- seconds to wait for a summon before moving on
    minShards = 2,          -- pause auto-summon if Soul Shards drop below this
    shareQueue = true,      -- share the summon queue with other DH-Air Warlocks in the raid/group
    guildOnly = true,       -- only auto-invite/auto-summon players in your guild
    minimap = {
        hide = false,
    },
    -- Per-channel announcement toggles and customizable message text.
    -- {target} is replaced with the player currently being summoned.
    messages = {
        raid    = { enabled = true,  text = DEFAULT_MESSAGE },
        party   = { enabled = true,  text = DEFAULT_MESSAGE },
        guild   = { enabled = false, text = "Now summoning {target} for the Air Service." },
        say     = { enabled = true,  text = DEFAULT_MESSAGE },
        whisper = { enabled = true,  text = "You're being summoned - please stand by!" },
    },
    queue = {},             -- ordered list of { name, summoned, role, queuedAt, destination }
    history = {},           -- name -> true once summoned this session

    -- Destinations feature (M1, see DH-Air-Destinations-Design.md): guild-
    -- wide list of { id, label, category } a queued player can pick from.
    -- CopyDefaults only fills missing KEYS, not array contents, so an
    -- empty table here just means "seed it from DEFAULT_DESTINATIONS on
    -- first load" - see the ADDON_LOADED handler below. Never reset by
    -- CopyDefaults once populated, so officer edits (M4) persist normally.
    destinations = {},
    -- officerRankThreshold (M3, DH-Air-Destinations-Design.md §3/§7):
    -- guild rankIndex <= this counts as "officer" for IsGuildOfficer.
    -- Default 3 is Chris's explicit call for Death Happens' actual rank
    -- ladder (2026-08-03), not the design doc's original rank<=4 guess -
    -- Guild Master (rank 0) can change it via Config or /dhair officerrank.
    officerRankThreshold = 3,
    -- db.warlockDestination (2026-08-03 addition, see design doc's
    -- "auto-summon destination matching" section) intentionally has NO
    -- entry here - it's local-only Warlock operating state (which
    -- destination auto-summon currently services), not a guild-wide
    -- setting, and defaults to nil (unset) simply by never being
    -- initialized. Set via SetWarlockDestination (Queue.lua), read via
    -- QueueNextAvailable's filter (Summon.lua).

    -- v2.0: guild-wide roster/registration (see Roster.lua)
    roster = {
        summoners = {},     -- [normalizedName] = { lastSeen = <local GetTime()> }
        clickers  = {},     -- same shape
    },
    codePhrase = "air",             -- /raid chat phrase that self-queues the sender
    autoPromote = true,             -- auto-promote registered Summoners to assistant
    autoPromoteGuildOnly = true,    -- ...but only guild members, by default
}

DHAir.DEFAULT_MESSAGE = DEFAULT_MESSAGE

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then
                dst[k] = {}
            end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

--------------------------------------------------------------------------
-- Utility
--------------------------------------------------------------------------

function DHAir:Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff9482c9DH-Air|r: " .. tostring(msg))
end

--------------------------------------------------------------------------
-- Guild roster cache (for the "guild members only" option)
--------------------------------------------------------------------------

DHAir.guildRoster = {} -- normalizedName -> { online = true|false }

-- Asks the game to (re)fetch the guild roster. The actual data isn't
-- necessarily available until GUILD_ROSTER_UPDATE fires afterward.
function DHAir:RequestGuildRoster()
    if not IsInGuild() then return end
    if C_GuildInfo and C_GuildInfo.GuildRoster then
        pcall(C_GuildInfo.GuildRoster)
    elseif GuildRoster then
        pcall(GuildRoster)
    end
end

-- Rebuilds the local guild-membership cache (including online status) from
-- whatever roster data the client currently has (called on GUILD_ROSTER_UPDATE).
function DHAir:UpdateGuildRosterCache()
    for k in pairs(self.guildRoster) do
        self.guildRoster[k] = nil
    end

    if not IsInGuild() then return end

    local numMembers = GetNumGuildMembers and GetNumGuildMembers() or 0
    for i = 1, numMembers do
        local name, _, rankIndex, _, _, _, _, _, isOnline = GetGuildRosterInfo(i)
        if name then
            self.guildRoster[self:NormalizeName(name)] = { online = (isOnline == true), rankIndex = rankIndex }
        end
    end
end

-- Returns true if name is a known member of the player's own guild. Fails
-- open (returns true) if the player isn't in a guild or the roster hasn't
-- loaded yet, since we'd rather occasionally allow a non-guildie through
-- than silently brick auto-invite for everyone because of a timing gap.
function DHAir:IsGuildMember(name)
    if not name then return false end
    if not IsInGuild() then return true end
    if next(self.guildRoster) == nil then return true end
    return self.guildRoster[self:NormalizeName(name)] ~= nil
end

-- Returns true/false if we have a definite answer, or nil if we can't tell
-- (not a guild member, or the roster hasn't loaded) - callers should treat
-- nil as "unknown", not as "offline", since we only have real signal for
-- guild members with a loaded roster.
function DHAir:IsGuildMemberOnline(name)
    if not name then return nil end
    local entry = self.guildRoster[self:NormalizeName(name)]
    if not entry then return nil end
    return entry.online
end

--------------------------------------------------------------------------
-- Permission model (v2.0)
--------------------------------------------------------------------------

-- Resolves `name` to a raid/party unit token and checks leader/assistant
-- status for THAT unit - not necessarily the local player. This is the one
-- function used both to decide what the local player can do, AND to verify
-- an incoming permission-gated broadcast against the receiver's OWN trusted
-- knowledge of the raid roster - never trusting a self-asserted claim baked
-- into the message itself.
-- TEMPORARY (Chris, 2026-08-03): named full-permission override - bypasses
-- every UnitHasAuthority check unconditionally for this one character, both
-- the LOCAL check (via HasPermission -> UnitHasAuthority(self)) and the
-- RECEIVE-SIDE verification other clients run on an incoming broadcast (via
-- Sync.lua's direct UnitHasAuthority(sender) calls for REMOVE/CLEARALL/
-- SETPHRASE) - same "bypass both sides" idiom as DH-Bavin's
-- TESTING_ALLOW_ANYONE_TO_MANAGE, but scoped to one name instead of
-- everyone. Remove this override (or set FULL_PERMISSION_OVERRIDE_NAME to
-- nil) before treating real permission enforcement as verified. Covers
-- BOTH UnitHasAuthority-routed actions (remove_any/clear_all/set_phrase/
-- invite) via the check below, AND the M3 guild-officer-rank actions
-- (edit_destinations/set_officer_threshold) via the identical check baked
-- into IsGuildOfficer/HasPermission's set_officer_threshold branch, since
-- neither of those routes through UnitHasAuthority itself.
local FULL_PERMISSION_OVERRIDE_NAME = "Loopidot"

function DHAir:UnitHasAuthority(name)
    if FULL_PERMISSION_OVERRIDE_NAME and name
        and self:NormalizeName(name) == FULL_PERMISSION_OVERRIDE_NAME then
        return true
    end
    if not IsInGroup() then return true end -- nobody's grouped yet; anyone can act

    local myName = UnitName("player")
    local unit
    if self:NormalizeName(name) == self:NormalizeName(myName) then
        unit = "player"
    elseif self.FindGroupUnitByName then
        unit = self.FindGroupUnitByName(name)
    end
    if not unit then return false end -- can't verify - fail closed

    return (UnitIsGroupLeader(unit) == true) or (UnitIsGroupAssistant(unit) == true)
end

-- Real guild-officer-rank check (M3, DH-Air-Destinations-Design.md §3),
-- replacing the interim leader/assist gate `edit_destinations` used since
-- M2. Fails CLOSED (false) if unverifiable - same reasoning as
-- DH-Bavin's IsGuildLeader: this gates a write action, unlike
-- IsGuildMember's deliberately fail-open check for a lower-stakes purpose.
-- Carries the same Loopidot bypass UnitHasAuthority has, since this
-- doesn't route through that function.
function DHAir:IsGuildOfficer(name)
    if not name then return false end
    if FULL_PERMISSION_OVERRIDE_NAME
        and self:NormalizeName(name) == FULL_PERMISSION_OVERRIDE_NAME then
        return true
    end
    local entry = self.guildRoster[self:NormalizeName(name)]
    return entry ~= nil and entry.rankIndex ~= nil
        and entry.rankIndex <= (self.db.officerRankThreshold or 3)
end

--------------------------------------------------------------------------
-- Shared window utility
--------------------------------------------------------------------------

-- Sets up a top-level DH-Air window with the properties every one of them
-- needs: proper click-to-raise behavior (so two overlapping DH-Air windows
-- correctly stack based on which you last interacted with, rather than
-- staying stuck in creation order), a guaranteed-opaque background (rather
-- than relying entirely on the template's own backdrop, which may not fully
-- cover every pixel), and dragging scoped to a title-bar-height strip only.
--
-- On that last point: registering drag on an entire frame means clicking
-- ANYWHERE moves the window, and interacts badly with addons like MoveAny
-- that wrap whatever draggable region a frame already exposes with their
-- own click-to-pick-up/click-to-drop behavior - scoping it to a slim strip
-- at the top keeps that behavior confined to where it belongs.
--
-- Every DH-Air window should call this ONCE, right after creating its
-- frame, instead of setting these properties up by hand.
function DHAir:InitStandaloneWindow(targetFrame, rightInset)
    targetFrame:SetToplevel(true)

    local bg = targetFrame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.9)

    targetFrame:SetMovable(true)
    targetFrame:EnableMouse(true)

    local dragRegion = CreateFrame("Frame", nil, targetFrame)
    dragRegion:SetPoint("TOPLEFT", 0, 0)
    dragRegion:SetPoint("TOPRIGHT", -(rightInset or 28), 0) -- leaves room for a close button
    dragRegion:SetHeight(24)
    dragRegion:EnableMouse(true)
    dragRegion:RegisterForDrag("LeftButton")
    dragRegion:SetScript("OnDragStart", function() targetFrame:StartMoving() end)
    dragRegion:SetScript("OnDragStop", function() targetFrame:StopMovingOrSizing() end)
    return dragRegion
end

-- Single entry point for every permission-gated action, checked LOCALLY by
-- the receiver against trusted Blizzard data (never a self-asserted claim
-- in a network message). In 2.2 this is where guild-officer-rank checks get
-- added, without touching any of the call sites below.
function DHAir:HasPermission(action)
    if action == "remove_any" or action == "clear_all" or action == "set_phrase" or action == "invite" then
        return self:UnitHasAuthority(UnitName("player"))
    elseif action == "edit_destinations" then
        -- M3 (DH-Air-Destinations-Design.md §3): real guild-officer rank
        -- check, replacing the interim leader/assist gate M2 shipped with.
        -- Inherits the Loopidot testing override via IsGuildOfficer itself.
        return self:IsGuildOfficer(UnitName("player"))
    elseif action == "set_officer_threshold" then
        -- Guild Master (rankIndex 0) only - officers must not be able to
        -- widen their own gate by lowering the threshold. Deliberately
        -- does NOT call IsGuildOfficer (that checks <= threshold, which
        -- would let an officer raise/lower the very setting that defines
        -- who's an officer). Loopidot's testing override is still honored
        -- here directly, same as every other permission-gated action.
        local myName = UnitName("player")
        if FULL_PERMISSION_OVERRIDE_NAME
            and self:NormalizeName(myName) == FULL_PERMISSION_OVERRIDE_NAME then
            return true
        end
        local entry = self.guildRoster[self:NormalizeName(myName)]
        return entry ~= nil and entry.rankIndex == 0
    end
    return false
end

-- Requests changing the officer rank threshold. Guild-Master-only (see
-- HasPermission "set_officer_threshold" above) - the /dhair officerrank
-- slash command's target, mirroring RequestSetPhrase's own
-- validate-then-gate-then-apply shape (Queue.lua).
function DHAir:RequestSetOfficerThreshold(rankIndex)
    rankIndex = tonumber(rankIndex)
    if not rankIndex or rankIndex < 0 then
        self:Print("Usage: /dhair officerrank <N> (a guild rank index, 0 = Guild Master)")
        return false
    end

    if not self:HasPermission("set_officer_threshold") then
        self:Print("Only the Guild Master can change the officer rank threshold.")
        return false
    end

    self.db.officerRankThreshold = rankIndex
    return true
end

--------------------------------------------------------------------------
-- Event Frame
--------------------------------------------------------------------------

DHAir.frame = CreateFrame("Frame")
DHAir.frame:RegisterEvent("ADDON_LOADED")
DHAir.frame:RegisterEvent("PLAYER_LOGIN")
DHAir.frame:RegisterEvent("CHAT_MSG_WHISPER")
DHAir.frame:RegisterEvent("CHAT_MSG_RAID")
DHAir.frame:RegisterEvent("CHAT_MSG_RAID_LEADER")
DHAir.frame:RegisterEvent("GROUP_ROSTER_UPDATE")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_FAILED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
DHAir.frame:RegisterEvent("UNIT_SPELLCAST_STOP")
DHAir.frame:RegisterEvent("BAG_UPDATE")
DHAir.frame:RegisterEvent("CHAT_MSG_ADDON")
DHAir.frame:RegisterEvent("GUILD_ROSTER_UPDATE")

function DHAir.OnEvent(event, ...)
    if event == "CHAT_MSG_WHISPER" then
        local msg, sender = ...
        if DHAir.HandleWhisper then
            DHAir:HandleWhisper(msg, sender)
        end
    elseif event == "CHAT_MSG_RAID" or event == "CHAT_MSG_RAID_LEADER" then
        local msg, sender = ...
        if DHAir.HandleRaidChat then
            DHAir:HandleRaidChat(msg, sender)
        end
    elseif event == "GROUP_ROSTER_UPDATE" then
        if DHAir.TrySummonNext then
            DHAir:TrySummonNext()
        end
        if DHAir.Sync_OnRosterChanged then
            DHAir:Sync_OnRosterChanged()
        end
    elseif event == "UNIT_SPELLCAST_SUCCEEDED"
        or event == "UNIT_SPELLCAST_FAILED"
        or event == "UNIT_SPELLCAST_INTERRUPTED"
        or event == "UNIT_SPELLCAST_STOP" then
        if DHAir.OnSpellcastEvent then
            DHAir:OnSpellcastEvent(event, ...)
        end
    elseif event == "BAG_UPDATE" then
        if DHAir.OnBagUpdate then
            DHAir:OnBagUpdate()
        end
    elseif event == "CHAT_MSG_ADDON" then
        if DHAir.Sync_OnAddonMessage then
            DHAir:Sync_OnAddonMessage(...)
        end
    elseif event == "GUILD_ROSTER_UPDATE" then
        DHAir:UpdateGuildRosterCache()
    end
end

DHAir.frame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loaded = ...
        if loaded == ADDON_NAME then
            DHAirDB = DHAirDB or {}
            CopyDefaults(defaults, DHAirDB)
            DHAir.db = DHAirDB

            -- GetTime() resets on a full client restart (but NOT on /reload),
            -- so a queuedAt saved from a previous session could be a huge,
            -- nonsensical number relative to the fresh clock. Reset any entry
            -- whose queuedAt is impossible (in the "future" relative to now).
            for _, entry in ipairs(DHAir.db.queue) do
                if not entry.queuedAt or entry.queuedAt > GetTime() then
                    entry.queuedAt = GetTime()
                end
            end

            -- One-time seed of the destinations list from the built-in
            -- starter set (Destinations.lua) - only runs while the list is
            -- still empty, so it never overwrites officer edits (M4) made
            -- on a previous login. Copies plain fields rather than
            -- inserting DEFAULT_DESTINATIONS' own tables directly, so
            -- later per-entry edits can't accidentally mutate the shared
            -- defaults table.
            if #DHAir.db.destinations == 0 then
                for _, d in ipairs(DHAir.DEFAULT_DESTINATIONS or {}) do
                    -- 2026-08-03: was hardcoded `enabled = true` regardless
                    -- of DEFAULT_DESTINATIONS' own data - now respects
                    -- `d.enabled` (defaulting true when the field is
                    -- absent), since some starter entries (The Stockade,
                    -- Ragefire Chasm, The Deadmines) are meant to seed
                    -- disabled by default. See Destinations.lua.
                    table.insert(DHAir.db.destinations, { id = d.id, label = d.label, category = d.category, continent = d.continent, enabled = (d.enabled ~= false) })
                end
            else
                -- 2026-08-03 migration: `continent` was added to
                -- DEFAULT_DESTINATIONS' flightpoint entries AFTER the seed
                -- above already ran on any existing install (the seed only
                -- fires once, while the list is empty - see comment
                -- above), so an already-populated db.destinations would
                -- otherwise be stuck with no continent field forever,
                -- breaking the Board/Minimap destination pickers' new
                -- "Flight Points > continent" grouping. Backfills ONLY the
                -- continent field, matched by id, and ONLY where it's
                -- currently missing - never touches label/enabled, so
                -- officer edits (M4) to those survive untouched.
                local byId = {}
                for _, d in ipairs(DHAir.DEFAULT_DESTINATIONS or {}) do
                    byId[d.id] = d
                end
                for _, entry in ipairs(DHAir.db.destinations) do
                    if entry.category == "flightpoint" and not entry.continent then
                        local default = byId[entry.id]
                        if default and default.continent then
                            entry.continent = default.continent
                        end
                    end
                end
            end
        end

        -- 2026-08-03 one-time migration: Chris wants The Stockade back as a
        -- selectable destination but disabled by default, and Ragefire
        -- Chasm/The Deadmines switched to disabled by default too (all three
        -- reachable without a summon). The seed loop above already handles
        -- fresh installs correctly via `d.enabled`, but any client whose
        -- destinations list was already populated before this change needs
        -- retrofitting here. Runs unconditionally (not nested in the
        -- if/else above) so it covers both cases; the version flag makes it
        -- a one-time-only pass so it never fights an officer who
        -- re-enables one of these three on purpose afterward.
        if not DHAir.db.migratedStockadeDefaults_20260803 then
            local existingIds = {}
            for _, entry in ipairs(DHAir.db.destinations) do
                existingIds[entry.id] = true
                if entry.id == "ragefirechasm" or entry.id == "deadmines" then
                    entry.enabled = false
                end
            end
            if not existingIds["thestockade"] then
                table.insert(DHAir.db.destinations, {
                    id = "thestockade",
                    label = "The Stockade (Stormwind City)",
                    category = "summonstone",
                    enabled = false,
                })
            end
            DHAir.db.migratedStockadeDefaults_20260803 = true
        end

        return
    elseif event == "PLAYER_LOGIN" then
        DHAir:Print("v" .. DHAir.VERSION .. " loaded. Type /dhair help for commands.")
        if DHAir.Minimap_Init then
            DHAir.Minimap_Init()
        end
        if DHAir.Sync_Init then
            DHAir:Sync_Init()
        end
        DHAir:RequestGuildRoster()
        return
    end

    DHAir.OnEvent(event, ...)
end)
