HCMobMarker = HCMobMarker or {}
local ns = HCMobMarker

ns.ADDON_NAME = "HCMobMarker"
ns.VERSION = "2.0"

-- Icon name/number aliases
ns.ICON_NAMES = {
    ["star"] = 1, ["circle"] = 2, ["diamond"] = 3, ["purple"] = 3,
    ["triangle"] = 4, ["moon"] = 5, ["square"] = 6,
    ["cross"] = 7, ["x"] = 7, ["skull"] = 8,
}
ns.ICON_LABELS = {
    [1] = "Star", [2] = "Circle", [3] = "Diamond", [4] = "Triangle",
    [5] = "Moon", [6] = "Square", [7] = "Cross", [8] = "Skull",
}
ns.ICON_PATH = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_"

-- Full 8-icon priority order used for row/dropdown display and hotkey
-- marking: Skull, Cross, Triangle, Diamond, Square, Circle, Moon, Star.
ns.ICON_PRIORITY_ORDER = { 8, 7, 4, 3, 6, 2, 5, 1 }

-- 6-icon priority order used for /mm add auto-assign (never Moon or Star).
local AUTO_ICON_ORDER = { 8, 7, 4, 3, 6, 2 }

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99HCMobMarker:|r " .. msg)
end

function ns.InitDB()
    if type(HCMobMarkerDB) ~= "table" then
        HCMobMarkerDB = {}
    end
    if HCMobMarkerDB.enabled == nil then
        HCMobMarkerDB.enabled = true
    end
    if type(HCMobMarkerDB.mobs) ~= "table" then
        HCMobMarkerDB.mobs = {}
    end
    if type(HCMobMarkerDB.hotkey) ~= "table" then
        HCMobMarkerDB.hotkey = { modifier = "CTRL", button = "LeftButton" }
    end
end

function ns.ParseIcon(input)
    if not input then return nil end
    input = tostring(input):lower()
    local n = tonumber(input)
    if n and n >= 1 and n <= 8 then return n end
    return ns.ICON_NAMES[input]
end

-- Returns the first icon in `order` not currently used by any mob, or nil.
function ns.PickIconFromOrder(order)
    local used = {}
    for _, icon in pairs(HCMobMarkerDB.mobs) do
        used[icon] = true
    end
    for _, icon in ipairs(order) do
        if not used[icon] then
            return icon
        end
    end
    return nil
end

function ns.PickAutoIcon()
    return ns.PickIconFromOrder(AUTO_ICON_ORDER)
end

-- Assigns `icon` to `name`, bumping whichever other mob currently holds that
-- icon to a random unused one. Returns true on success, or false, "full" if
-- this would be a brand-new 9th mob and all 8 icon slots are already taken.
function ns.AssignMobIcon(name, icon)
    local mobs = HCMobMarkerDB.mobs
    local isNewMob = mobs[name] == nil

    if isNewMob then
        local count = 0
        for _ in pairs(mobs) do count = count + 1 end
        if count >= 8 then
            return false, "full"
        end
    end

    for otherName, otherIcon in pairs(mobs) do
        if otherName ~= name and otherIcon == icon then
            local used = { [icon] = true }
            for n2, i2 in pairs(mobs) do
                if n2 ~= otherName and n2 ~= name then
                    used[i2] = true
                end
            end
            local free = {}
            for i = 1, 8 do
                if not used[i] then
                    table.insert(free, i)
                end
            end
            if #free > 0 then
                mobs[otherName] = free[math.random(#free)]
            end
            break
        end
    end

    mobs[name] = icon
    return true
end

-- Marks `name` via the hotkey: next unused icon in full priority order
-- (skull..star). If the list is already full (8/8), Skull is stolen from
-- whoever currently has it -- that mob is evicted from the list entirely
-- to make room, since there's nowhere left to bump it to.
function ns.HotkeyMark(name)
    ns.InitDB()
    local mobs = HCMobMarkerDB.mobs

    if mobs[name] then
        -- Already tracked: hotkey click on it now acts like /mm remove.
        mobs[name] = nil
        SetRaidTarget("mouseover", 0)
        ns.Print(("Removed '%s' from the list."):format(name))
        return
    end

    local count = 0
    for _ in pairs(mobs) do count = count + 1 end

    local icon
    if count < 8 then
        icon = ns.PickIconFromOrder(ns.ICON_PRIORITY_ORDER)
    end

    if not icon then
        icon = 8
        for otherName, otherIcon in pairs(mobs) do
            if otherIcon == 8 then
                mobs[otherName] = nil
                break
            end
        end
    end

    mobs[name] = icon
    SetRaidTarget("mouseover", icon)
    ns.Print(("Marked '%s' with %s."):format(name, ns.ICON_LABELS[icon]))
end

local function ShowHelp()
    ns.Print(("Commands (v%s):"):format(ns.VERSION))
    ns.Print("  /mm add [icon] [mob name]  - icon and name are both optional (mouseover a mob to grab its name; skip the icon to auto-pick one)")
    ns.Print("  /mm remove [mob name]      - mouseover a mob and omit the name to remove whatever's under your cursor")
    ns.Print("  /mm list                   - show the current list")
    ns.Print("  /mm clear                  - wipe the list")
    ns.Print("  /mm config                 - open the settings window")
    ns.Print("  /mm on | off | toggle      - enable/disable auto-marking")
    ns.Print("  /mm help                   - show this list")
    ns.Print("Icons: 1 star, 2 circle, 3 diamond, 4 triangle, 5 moon, 6 square, 7 cross, 8 skull (names work too)")
    ns.Print("Auto-pick order when no icon is given: skull, cross, triangle, diamond, square, circle (never moon or star)")
    ns.Print("Hotkey: hold the configured modifier (default Ctrl) and click a mob to mark it with the next unused icon -- configurable under /mm config, Options page")
end

-- === Core marking logic ===
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("UPDATE_MOUSEOVER_UNIT")

frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ns.ADDON_NAME then
        ns.InitDB()
        ns.Print(("loaded (v%s). Type /mm help for commands."):format(ns.VERSION))

    elseif event == "UPDATE_MOUSEOVER_UNIT" then
        if not HCMobMarkerDB or not HCMobMarkerDB.enabled then return end
        if not UnitExists("mouseover") then return end
        if UnitIsPlayer("mouseover") then return end
        if UnitIsDead("mouseover") then return end

        local name = UnitName("mouseover")
        if not name then return end

        local icon = HCMobMarkerDB.mobs[name]
        if icon and GetRaidTargetIndex("mouseover") ~= icon then
            SetRaidTarget("mouseover", icon)
        end
    end
end)

-- === Hotkey click-to-mark ===
local function IsConfiguredModifierDown()
    local mod = HCMobMarkerDB.hotkey.modifier
    if mod == "CTRL" then
        return IsControlKeyDown()
    elseif mod == "ALT" then
        return IsAltKeyDown()
    elseif mod == "SHIFT" then
        return IsShiftKeyDown()
    else
        return true -- "NONE" -- no modifier required
    end
end

WorldFrame:HookScript("OnMouseDown", function(self, mouseButton)
    if not HCMobMarkerDB or not HCMobMarkerDB.enabled then return end
    local hk = HCMobMarkerDB.hotkey
    if not hk or mouseButton ~= hk.button then return end
    if not IsConfiguredModifierDown() then return end
    if not UnitExists("mouseover") or UnitIsPlayer("mouseover") or UnitIsDead("mouseover") then return end

    ns.HotkeyMark(UnitName("mouseover"))
end)

-- === Slash commands ===
SLASH_HCMOBMARKER1 = "/mm"
SLASH_HCMOBMARKER2 = "/hcmark"

SlashCmdList["HCMOBMARKER"] = function(msg)
    ns.InitDB()
    msg = msg or ""
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()

    if cmd == "add" then
        local icon, name

        if rest == "" then
            icon = nil
            name = ""
        else
            local firstToken, remainder = rest:match("^(%S+)%s*(.-)$")
            local parsedIcon = ns.ParseIcon(firstToken)
            if parsedIcon then
                icon = parsedIcon
                name = remainder
            else
                icon = nil
                name = rest
            end
        end

        if name == "" then
            if UnitExists("mouseover") and not UnitIsPlayer("mouseover") then
                name = UnitName("mouseover")
            else
                ns.Print("No mob name given, and nothing valid is under your mouse. Either mouse over the mob first, or type its name.")
                return
            end
        end

        if not icon then
            icon = ns.PickAutoIcon()
            if not icon then
                ns.Print("All six auto-assign icons (skull, cross, triangle, diamond, square, circle) are already in use. Remove one, or specify moon/star manually: /mm add moon " .. name)
                return
            end
        end

        local ok, reason = ns.AssignMobIcon(name, icon)
        if not ok then
            if reason == "full" then
                ns.Print("Your list is full (8/8). Remove a mob before adding another.")
            end
            return
        end
        ns.Print(("Now marking '%s' with %s."):format(name, ns.ICON_LABELS[icon]))

    elseif cmd == "remove" or cmd == "del" or cmd == "delete" then
        local name = rest
        if name == "" and UnitExists("mouseover") then
            name = UnitName("mouseover")
        end
        if name == "" or not HCMobMarkerDB.mobs[name] then
            ns.Print("Usage: /mm remove <mob name> (or mouseover the mob and just type /mm remove)")
            return
        end
        HCMobMarkerDB.mobs[name] = nil
        ns.Print(("Removed '%s' from the list."):format(name))

    elseif cmd == "list" then
        local count = 0
        for name, icon in pairs(HCMobMarkerDB.mobs) do
            count = count + 1
            ns.Print(("%s -> %s"):format(name, ns.ICON_LABELS[icon]))
        end
        if count == 0 then
            ns.Print("List is empty. Add mobs with /mm add [icon] [mob name].")
        end

    elseif cmd == "clear" then
        HCMobMarkerDB.mobs = {}
        ns.Print("Cleared the mob list.")

    elseif cmd == "config" or cmd == "options" then
        if ns.OpenConfig then
            ns.OpenConfig()
        else
            ns.Print("Config UI didn't load correctly.")
        end

    elseif cmd == "on" then
        HCMobMarkerDB.enabled = true
        ns.Print("Enabled.")

    elseif cmd == "off" then
        HCMobMarkerDB.enabled = false
        ns.Print("Disabled.")

    elseif cmd == "toggle" then
        HCMobMarkerDB.enabled = not HCMobMarkerDB.enabled
        ns.Print(HCMobMarkerDB.enabled and "Enabled." or "Disabled.")

    elseif cmd == "help" or cmd == "" then
        ShowHelp()

    else
        ns.Print("Unknown command: '" .. cmd .. "'")
        ShowHelp()
    end
end
