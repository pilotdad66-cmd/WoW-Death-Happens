HCMobMarker = HCMobMarker or {}
local ns = HCMobMarker

local ROW_COUNT = 8
local rows = {}      -- UI widgets per row, indexed 1-8 (fixed screen position, top to bottom)
local working = {}   -- working[i] = { name = "", icon = N }  (edit-session copy)
local panel

local pages = {}       -- pages.targets / pages.options / pages.about -> page content frames
local navButtons = {}  -- navButtons.targets / .options / .about -> nav button widgets
local currentPage

local function GetUsedIconsExcluding(excludeRow1, excludeRow2)
    local used = {}
    for i = 1, ROW_COUNT do
        if i ~= excludeRow1 and i ~= excludeRow2 then
            used[working[i].icon] = true
        end
    end
    return used
end

local function PickRandomUnused(excluding)
    local pool = {}
    for i = 1, ROW_COUNT do
        if not excluding[i] then
            table.insert(pool, i)
        end
    end
    if #pool == 0 then return nil end
    return pool[math.random(#pool)]
end

local function RefreshRowVisual(i)
    local row, w = rows[i], working[i]
    row.icon:SetTexture(ns.ICON_PATH .. w.icon)
    UIDropDownMenu_SetSelectedValue(row.dropdown, w.icon)
    UIDropDownMenu_SetText(row.dropdown, ns.ICON_LABELS[w.icon])
    if row.edit:GetText() ~= w.name then
        row.edit:SetText(w.name)
    end
end

-- Assigns newIcon to row i. Every row -- blank or not -- always holds a
-- unique icon, so if another row already has newIcon, that row is bumped to
-- a random unused icon regardless of whether it currently has a mob name.
local function SetRowIcon(i, newIcon)
    for j = 1, ROW_COUNT do
        if j ~= i and working[j].icon == newIcon then
            local used = GetUsedIconsExcluding(i, j)
            used[newIcon] = true
            local pick = PickRandomUnused(used)
            if pick then
                working[j].icon = pick
                RefreshRowVisual(j)
            end
            break
        end
    end

    working[i].icon = newIcon
    RefreshRowVisual(i)
end

-- === Page: Target Icons ===
local function BuildTargetsPage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetAllPoints(parent)

    local colMob = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    colMob:SetPoint("TOPLEFT", 34, -2)
    colMob:SetText("Mob Name")

    local colIcon = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    colIcon:SetPoint("TOPLEFT", 234, -2)
    colIcon:SetText("Icon")

    for i = 1, ROW_COUNT do
        local y = -22 - (i - 1) * 30
        local row = {}

        row.icon = page:CreateTexture(nil, "ARTWORK")
        row.icon:SetSize(20, 20)
        row.icon:SetPoint("TOPLEFT", 2, y)

        local edit = CreateFrame("EditBox", "HCMobMarkerRow" .. i .. "Edit", page, "InputBoxTemplate")
        edit:SetSize(160, 20)
        edit:SetPoint("LEFT", row.icon, "RIGHT", 14, 0)
        edit:SetAutoFocus(false)
        edit:SetMaxLetters(100)
        edit:SetScript("OnEscapePressed", edit.ClearFocus)
        edit:SetScript("OnEnterPressed", edit.ClearFocus)
        edit:SetScript("OnTextChanged", function(self)
            working[i].name = self:GetText()
        end)
        row.edit = edit

        local dropdown = CreateFrame("Frame", "HCMobMarkerRow" .. i .. "Dropdown", page, "UIDropDownMenuTemplate")
        dropdown:SetPoint("LEFT", edit, "RIGHT", 6, -2)
        UIDropDownMenu_SetWidth(dropdown, 95)
        UIDropDownMenu_Initialize(dropdown, function(self, level)
            for _, iconNum in ipairs(ns.ICON_PRIORITY_ORDER) do
                local info = UIDropDownMenu_CreateInfo()
                info.text = ns.ICON_LABELS[iconNum]
                info.icon = ns.ICON_PATH .. iconNum
                info.value = iconNum
                info.func = function()
                    SetRowIcon(i, iconNum)
                end
                UIDropDownMenu_AddButton(info)
            end
        end)
        row.dropdown = dropdown

        local delBtn = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
        delBtn:SetSize(60, 20)
        delBtn:SetText("Delete")
        delBtn:SetPoint("LEFT", dropdown, "RIGHT", 2, 2)
        delBtn:SetScript("OnClick", function()
            working[i].name = ""
            edit:SetText("")
        end)
        row.delBtn = delBtn

        rows[i] = row
    end

    local clearAllBtn = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
    clearAllBtn:SetSize(100, 22)
    clearAllBtn:SetPoint("BOTTOMLEFT", 2, 0)
    clearAllBtn:SetText("Clear All")
    clearAllBtn:SetScript("OnClick", function()
        for i = 1, ROW_COUNT do
            working[i].name = ""
            rows[i].edit:SetText("")
        end
    end)

    local saveNote = page:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    saveNote:SetPoint("BOTTOM", 0, 30)
    saveNote:SetTextColor(1, 0.65, 0.1)
    saveNote:SetText("Changes are not saved until you click Update.")

    local statusText = page:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    statusText:SetPoint("BOTTOM", 0, 6)
    page.statusText = statusText

    local updateBtn = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
    updateBtn:SetSize(100, 22)
    updateBtn:SetPoint("BOTTOMRIGHT", 0, 0)
    updateBtn:SetText("Update")
    updateBtn:SetScript("OnClick", function()
        local newMobs = {}
        for i = 1, ROW_COUNT do
            local w = working[i]
            if w.name ~= "" then
                newMobs[w.name] = w.icon
            end
        end
        HCMobMarkerDB.mobs = newMobs
        statusText:SetText("|cff33ff99Saved!|r")
        C_Timer.After(2, function()
            statusText:SetText("")
        end)
    end)

    return page
end

local function LoadTargetsFromDB()
    ns.InitDB()
    for i = 1, ROW_COUNT do
        working[i] = { name = "", icon = ns.ICON_PRIORITY_ORDER[i] }
    end
    for name, icon in pairs(HCMobMarkerDB.mobs) do
        for i = 1, ROW_COUNT do
            if working[i].icon == icon and working[i].name == "" then
                working[i].name = name
                break
            end
        end
    end
    for i = 1, ROW_COUNT do
        RefreshRowVisual(i)
    end
    if pages.targets then
        pages.targets.statusText:SetText("")
    end
end

-- === Page: Options (hotkey config) ===
local MODIFIER_OPTIONS = {
    { label = "None", value = "NONE" },
    { label = "Ctrl", value = "CTRL" },
    { label = "Alt", value = "ALT" },
    { label = "Shift", value = "SHIFT" },
}
local BUTTON_OPTIONS = {
    { label = "Left Click", value = "LeftButton" },
    { label = "Right Click", value = "RightButton" },
    { label = "Middle Click", value = "MiddleButton" },
}

local function BuildOptionsPage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetAllPoints(parent)

    local heading = page:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    heading:SetPoint("TOPLEFT", 2, -2)
    heading:SetText("Hotkey Marking")

    local desc = page:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    desc:SetPoint("TOPLEFT", heading, "BOTTOMLEFT", 0, -10)
    desc:SetWidth(380)
    desc:SetJustifyH("LEFT")
    desc:SetText("Hold the modifier below and click a mob to instantly mark it with the next unused icon. If all 8 icons are already in use, it takes over Skull (evicting whoever currently has it).")

    local modLabel = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    modLabel:SetPoint("TOPLEFT", desc, "BOTTOMLEFT", 0, -22)
    modLabel:SetText("Modifier:")

    local modDropdown = CreateFrame("Frame", "HCMobMarkerModDropdown", page, "UIDropDownMenuTemplate")
    modDropdown:SetPoint("LEFT", modLabel, "RIGHT", 0, -2)
    UIDropDownMenu_SetWidth(modDropdown, 100)

    local btnLabel = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    btnLabel:SetPoint("TOPLEFT", modLabel, "BOTTOMLEFT", 0, -30)
    btnLabel:SetText("Mouse Button:")

    local btnDropdown = CreateFrame("Frame", "HCMobMarkerBtnDropdown", page, "UIDropDownMenuTemplate")
    btnDropdown:SetPoint("LEFT", btnLabel, "RIGHT", 0, -2)
    UIDropDownMenu_SetWidth(btnDropdown, 100)

    local function RefreshDropdowns()
        ns.InitDB()
        local hk = HCMobMarkerDB.hotkey
        for _, opt in ipairs(MODIFIER_OPTIONS) do
            if opt.value == hk.modifier then UIDropDownMenu_SetText(modDropdown, opt.label) end
        end
        for _, opt in ipairs(BUTTON_OPTIONS) do
            if opt.value == hk.button then UIDropDownMenu_SetText(btnDropdown, opt.label) end
        end
    end

    UIDropDownMenu_Initialize(modDropdown, function()
        for _, opt in ipairs(MODIFIER_OPTIONS) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt.label
            info.value = opt.value
            info.func = function()
                HCMobMarkerDB.hotkey.modifier = opt.value
                UIDropDownMenu_SetText(modDropdown, opt.label)
            end
            UIDropDownMenu_AddButton(info)
        end
    end)

    UIDropDownMenu_Initialize(btnDropdown, function()
        for _, opt in ipairs(BUTTON_OPTIONS) do
            local info = UIDropDownMenu_CreateInfo()
            info.text = opt.label
            info.value = opt.value
            info.func = function()
                HCMobMarkerDB.hotkey.button = opt.value
                UIDropDownMenu_SetText(btnDropdown, opt.label)
            end
            UIDropDownMenu_AddButton(info)
        end
    end)

    local resetBtn = CreateFrame("Button", nil, page, "UIPanelButtonTemplate")
    resetBtn:SetSize(140, 22)
    resetBtn:SetPoint("TOPLEFT", btnLabel, "BOTTOMLEFT", 0, -22)
    resetBtn:SetText("Reset to Default")
    resetBtn:SetScript("OnClick", function()
        HCMobMarkerDB.hotkey.modifier = "CTRL"
        HCMobMarkerDB.hotkey.button = "LeftButton"
        RefreshDropdowns()
    end)

    local note = page:CreateFontString(nil, "ARTWORK", "GameFontDisableSmall")
    note:SetPoint("TOPLEFT", resetBtn, "BOTTOMLEFT", 0, -14)
    note:SetWidth(380)
    note:SetJustifyH("LEFT")
    note:SetText("Changes here take effect immediately -- no need to click Update.")

    page.RefreshDropdowns = RefreshDropdowns
    return page
end

-- === Page: About ===
local function BuildAboutPage(parent)
    local page = CreateFrame("Frame", nil, parent)
    page:SetAllPoints(parent)

    local title = page:CreateFontString(nil, "ARTWORK", "GameFontNormalLarge")
    title:SetPoint("TOPLEFT", 2, -2)
    title:SetText("HC Mob Marker")

    local verLine = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    verLine:SetPoint("TOPLEFT", title, "BOTTOMLEFT", 0, -14)
    verLine:SetText("Addon Version: " .. ns.VERSION)

    local gameVerLine = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    gameVerLine:SetPoint("TOPLEFT", verLine, "BOTTOMLEFT", 0, -6)
    local gameVersion = GetBuildInfo()
    gameVerLine:SetText("Game Version: " .. (gameVersion or "Unknown"))

    local authorLine = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    authorLine:SetPoint("TOPLEFT", gameVerLine, "BOTTOMLEFT", 0, -16)
    authorLine:SetText("Author: Loopi")

    local copyrightLine = page:CreateFontString(nil, "ARTWORK", "GameFontNormalSmall")
    copyrightLine:SetPoint("TOPLEFT", authorLine, "BOTTOMLEFT", 0, -8)
    copyrightLine:SetText("\194\169 " .. date("%Y") .. " Loopi. All rights reserved.")

    local donateHeader = page:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    donateHeader:SetPoint("TOPLEFT", copyrightLine, "BOTTOMLEFT", 0, -22)
    donateHeader:SetText("Support the Author")

    local donateText = page:CreateFontString(nil, "ARTWORK", "GameFontHighlightSmall")
    donateText:SetPoint("TOPLEFT", donateHeader, "BOTTOMLEFT", 0, -8)
    donateText:SetWidth(320)
    donateText:SetJustifyH("LEFT")
    donateText:SetText("Donation links coming soon.")
    page.donateText = donateText

    return page
end

-- === Nav ===
local function ShowPage(key)
    currentPage = key
    for k, pg in pairs(pages) do
        if k == key then pg:Show() else pg:Hide() end
    end
    for k, btn in pairs(navButtons) do
        if k == key then
            btn.text:SetTextColor(1, 0.82, 0)
        else
            btn.text:SetTextColor(1, 1, 1)
        end
    end
end

local function CreateNavButton(parent, key, label, yOffset)
    local btn = CreateFrame("Button", nil, parent)
    btn:SetSize(108, 22)
    btn:SetPoint("TOPLEFT", 0, yOffset)

    local text = btn:CreateFontString(nil, "ARTWORK", "GameFontNormal")
    text:SetAllPoints()
    text:SetJustifyH("LEFT")
    text:SetText(label)
    btn.text = text

    btn:SetScript("OnClick", function() ShowPage(key) end)
    btn:SetScript("OnEnter", function()
        if currentPage ~= key then text:SetTextColor(1, 1, 0.6) end
    end)
    btn:SetScript("OnLeave", function()
        if currentPage ~= key then text:SetTextColor(1, 1, 1) end
    end)

    navButtons[key] = btn
    return btn
end

local function BuildPanel()
    local f = CreateFrame("Frame", "HCMobMarkerConfigFrame", UIParent, "BasicFrameTemplateWithInset")
    f:SetSize(580, 430)
    f:SetPoint("CENTER")
    f:SetMovable(true)
    f:EnableMouse(true)
    f:SetFrameStrata("DIALOG")
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", f.StartMoving)
    f:SetScript("OnDragStop", f.StopMovingOrSizing)
    f.TitleText:SetText("HC Mob Marker")

    UISpecialFrames = UISpecialFrames or {}
    tinsert(UISpecialFrames, "HCMobMarkerConfigFrame") -- lets Escape close it (edits are discarded, same as clicking the X)

    -- Version header, top right -- a small backdrop "box" containing two aligned lines
    local verBox = f:CreateTexture(nil, "BACKGROUND")
    verBox:SetColorTexture(0, 0, 0, 0.25)
    verBox:SetSize(150, 36)
    verBox:SetPoint("TOPRIGHT", -16, -26)

    local addonVerText = f:CreateFontString(nil, "OVERLAY")
    addonVerText:SetFontObject("GameFontNormalSmall")
    addonVerText:SetPoint("TOPLEFT", verBox, "TOPLEFT", 8, -6)
    addonVerText:SetWidth(134)
    addonVerText:SetJustifyH("LEFT")
    addonVerText:SetText("Addon " .. ns.VERSION)

    local gameVerText = f:CreateFontString(nil, "OVERLAY")
    gameVerText:SetFontObject("GameFontNormalSmall")
    gameVerText:SetPoint("TOPLEFT", addonVerText, "BOTTOMLEFT", 0, -4)
    gameVerText:SetWidth(134)
    gameVerText:SetJustifyH("LEFT")
    gameVerText:SetTextColor(0.78, 0.78, 0.78)
    gameVerText:SetText("Game  " .. (GetBuildInfo() or "?"))

    -- Left nav pane
    local navPanel = CreateFrame("Frame", nil, f)
    navPanel:SetPoint("TOPLEFT", 14, -70)
    navPanel:SetSize(110, 280)

    local divider = f:CreateTexture(nil, "ARTWORK")
    divider:SetColorTexture(1, 1, 1, 0.15)
    divider:SetSize(1, 280)
    divider:SetPoint("TOPLEFT", navPanel, "TOPRIGHT", 8, 0)

    CreateNavButton(navPanel, "targets", "Target Icons", 0)
    CreateNavButton(navPanel, "options", "Options", -26)
    CreateNavButton(navPanel, "about", "About", -52)

    -- Content area to the right of the nav pane
    local contentArea = CreateFrame("Frame", nil, f)
    contentArea:SetPoint("TOPLEFT", divider, "TOPRIGHT", 10, -4)
    contentArea:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -16, 16)

    pages.targets = BuildTargetsPage(contentArea)
    pages.options = BuildOptionsPage(contentArea)
    pages.about = BuildAboutPage(contentArea)

    f:SetScript("OnShow", function()
        LoadTargetsFromDB()
        if pages.options.RefreshDropdowns then
            pages.options.RefreshDropdowns()
        end
        ShowPage("targets")
    end)

    f:Hide()
    panel = f
end

function ns.OpenConfig()
    if not panel then
        BuildPanel()
    end
    panel:Show()
end
