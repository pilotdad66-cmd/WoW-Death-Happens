# DH-Tools

**Version 1.1.2** | Author: **Loopi** | For: *Death Happens* Hardcore guild

---

## Summary

DH-Tools is the Death Happens guild's all-in-one utility addon: instead of
installing a separate addon for every guild tool, enable or disable each
one individually from a single config window.

- **Module Toggle Framework** — the Tools page (`/dht config`) lists every
  available module with a one-line description and an on/off checkbox.
  Turn on only what you need; more modules will be added here over time.
- **Mob Marker** — automatically marks specific mobs with a raid-target
  icon on mouseover, plus a configurable Ctrl+click hotkey to mark/unmark
  whatever's under your cursor on demand. Fully customizable icon
  assignments per mob and hotkey modifier/mouse button, via `/mm config`.
- **Shared Quests** — see which group and elite quests your online
  guildmates currently have, so you can find people to group up with.
  Broadcasts your own quest log over guild addon messages (Individual,
  Group, Elite, and Class categories, each independently toggleable, and
  entirely opt-in), and shows everyone else's in a sortable, filterable
  window (`/dhq`) — filter to online-only, sort by player, quest, or
  character level, and invite a matching player straight from the row.
- **Bavin Wants** — a guild-wide priority want-list for the designated mail
  collector: matching items are highlighted in every guildmate's own bags
  with a gold border, plus a mailbox helper ("Fill Recipient" button and a
  one-click attach for matching items while the mailbox is open). The
  recipient (or a designated editor) manages who gets items and the list
  itself from a searchable, type-to-filter editor (`/dhb priority`). Also
  shows a "Bavin Points" donation-priority value in item tooltips for
  ~7,000 items, editable live by the recipient/editors (`/dhb points`).
  Recipient/editor access is automatically revoked the moment someone
  leaves the guild.
- **DH-Air Submenu** — quick access to DH-Air's Board and Config windows,
  its destination picker (grouped by Flight Points/continent and Dungeon
  Stones, plus an officer-gated Destination Config shortcut), and one-click
  toggles for Join Queue, Am Summoner, Am Clicker, Auto Invite, and Auto
  Summons, color-coded green/red for current state — all without leaving
  the minimap menu. DH-Air itself stays a separate, standalone addon; this
  is a thin shortcut into it, shown only if DH-Air is installed.
- **Minimap Button** — left-click opens DH-Tools' own Config window
  directly; right-click opens the full menu (Mob Marker, Quests, DH-Air,
  Bavin Wants, Settings, About), with expandable submenus for anything
  with more than one option.
- **DH-Air Status** — the Tools page shows whether DH-Air (the guild's
  Warlock summon-coordination addon) is installed. DH-Air stays a separate,
  standalone addon rather than folding into DH-Tools, so this is a status
  indicator, not a toggle — install DH-Air on its own if you want it.

DH-Tools does **not** replace any of its modules' individual settings or
judgment calls — it's a shared shell that lets you pick which guild tools
you actually want running, all managed from one place.

---

## Changelog

### 1.1.2
- **Bavin Points editor: itemID is now editable per item**, so a wrong
  itemID from the original import can be corrected directly (`/dhb
  points` - search a name, edit the itemID box, Save).
- **Bavin Points editor: new "Add a new item" form** to add an item
  outright (name, itemID, points) instead of only being able to edit an
  item that was already in the shipped list.
- **Bavin recipient/editor permissions tightened.** Only Bavin and Loopi
  can set who the current mail recipient is; only guild officers (rank 3
  or higher) and Loopi can set who else can edit the priority list and
  points.
- **Mail window button renamed "Bavin Wants"**, now fills the recipient's
  full name (with realm) and also auto-attaches every bag item on the
  priority list to the open mail in one click, not just the recipient
  field.
- **Bavin Points editor: fixed the itemID/points column headers not
  lining up with the values below them**, and added an explicit Save
  button so it's clear how to commit an edit.

### 1.1.1
- **New: Bavin Points.** Item tooltips show a "Bavin Points" donation-
  priority value for ~7,000 items. The recipient/editors can override any
  item's value live (`/dhb points`), and it updates in tooltips
  immediately for everyone.
- **New: Priority list rebuilt around a searchable editor.** `/dhb priority`
  opens a type-to-filter Add/Remove window (same style as the Points
  editor) instead of the old shift-click-a-link-only workflow. The list is
  now keyed by item name instead of item ID, matching Bavin Points and
  avoiding a mismatch on items that have several differently-valued
  random-suffix versions sharing one ID.
- **New: bag highlighting and a mailbox helper.** Any bag item on the
  priority list gets a gold border, guild-wide, for everyone (informational
  only, not tied to edit permission). While the mailbox is open, a "Fill
  Recipient" button fills in the current recipient's name, and matching
  items get a small mail icon you can click to attach them directly. **This
  is the newest, least-tested part of this release** - the bag-highlight
  and mailbox hooks haven't been through a full in-game pass yet on every
  setup. If bag highlighting or the mailbox button doesn't appear, please
  report it rather than assume it's just you.
- **Fixed: departed-member access.** A recipient or editor who leaves the
  guild now automatically loses list-edit access the moment the roster
  updates, instead of only on the next time the list happens to be
  re-saved.
- **Fixed: the priority list could be lost on relog.** It used to live in
  memory only, rebuilt each login purely from other online guildmates'
  broadcasts - if nobody else happened to be online, it came back empty.
  It's now saved locally like everything else.
- **Fixed: the DH-Air submenu's "Set Destination" → Flight Points menu**
  never opened (nested one level deeper than it should have been) -
  matches the fix in DH-Air 2.1.1; update both together.

### 1.1 (first published release, beta)
- **Module Toggle Framework** — Tools page (`/dht config`) lists every
  module with a one-line description and an on/off checkbox; Mob Marker,
  Shared Quests, and Bavin Wants all correctly stop responding to events
  when turned off (not just their own slash commands).
- **Mob Marker** — auto-marks specific mobs with a raid-target icon on
  mouseover or nameplate sighting, plus a configurable Ctrl+click hotkey.
- **Shared Quests** — opt-in guild quest-sharing and lookup window.
- **Bavin Wants** — guild-wide want-list, viewable by everyone, editable
  by the guild leader or a designated editor (with a testing override
  currently enabled — see in-game notes).
- **Minimap menu** — real expandable-submenu dropdown (left-click: Config,
  right-click: full menu) covering every module above plus a DH-Air
  shortcut submenu.
- **DH-Air integration** — status indicator on the Tools page, plus the
  minimap's DH-Air submenu described above, for the separately-installed
  DH-Air addon.

This is the first CurseForge release and is tagged **beta** — the module
framework, Bavin Wants, and the minimap menu have not yet been verified
against a live multi-user guild session (see in-game notes / report issues
to Loopi).
