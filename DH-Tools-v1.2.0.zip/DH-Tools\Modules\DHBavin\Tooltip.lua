-- DH-Tools: Modules\DHBavin\Tooltip.lua
-- Adds a "Bavin Points: N" line to any item tooltip whose exact display
-- name appears in ItemPoints.lua's ns.ITEM_POINTS table (or has a live
-- in-game override on top of it - see Core.lua's "Item points" section)
-- - see ItemPoints.lua's header for why the lookup is by name, not
-- itemID (random-suffix rare items share one base itemID but price
-- differently per suffix). Read-only informational display, no
-- permission gate - this doesn't reveal anything guildmates can't
-- already see in the source spreadsheet (or, for a live edit, in the
-- Points Editor itself - PointsEditor.lua).
--
-- Uses ns.GetItemPoints(name), NOT ns.ITEM_POINTS[name] directly, so a
-- Points Editor override is reflected here immediately instead of only
-- after the next addon release ships a regenerated ItemPoints.lua.
--
-- Hooked via GameTooltip:HookScript("OnTooltipSetItem", ...) - the
-- standard, low-risk tooltip-extension idiom (unlike Bavin's still-
-- unbuilt M5 bag-highlight hook, which has real unverified API risk -
-- see PROFILE.md's Known risks). Works everywhere GameTooltip:SetItem
-- gets called - bags, merchant, mail, trade, loot, chat links - since
-- it hooks the shared GameTooltip object, not any one frame. Also hooks
-- ItemRefTooltip (the tooltip shown for chat-linked items specifically),
-- which is a separate frame from GameTooltip.

local DHTools = DHTools
DHTools.Bavin = DHTools.Bavin or {}
local ns = DHTools.Bavin

-- 2026-08-06 (Chris): trying the spreadsheet's richer column-P summary
-- line ("<name>: <points> pts to Bavin; <price/source>", e.g. "crafted
-- by an @Alchemist" or "(est. AH value)") in place of the plain "Bavin
-- Points: N" line, on a trial basis - Chris wants to see how it looks
-- in-game before committing to it, with an easy one-line revert if it's
-- too much text for a tooltip. Flip this back to false to instantly
-- restore the old plain-points line - no other code changes needed.
local USE_DETAIL_LINE = true

local function FormatPoints(points)
    if points == math.floor(points) then
        return string.format("%d", points)
    end
    return string.format("%.2f", points)
end

-- 2026-08-06 (Chris, revised same day): the tooltip line is now colored
-- on a four-band scale using the GAME'S OWN item-quality palette, so a
-- glance reads the same way gear rarity does - white/green/blue/purple
-- as value climbs. This replaces the earlier two-tier gold/green
-- experiment (>10 = green, everything else gold) entirely.
--
--   points <= 0              RED     (see RedColor - not a quality band)
--   points >  0  and <= 1    white   (Common)
--   points >  1  and <= 10   green   (Uncommon)
--   points > 10  and <= 100  blue    (Rare)
--   points > 100             purple  (Epic)
--   points missing/not a number   grey (Poor) - see PointsColor
--
-- Bands are evaluated low-to-high with strictly-greater-than upper
-- bounds, so each boundary value (1, 10, 100) belongs to the LOWER band
-- - exactly as Chris phrased it ("<=1 white, >1 and <=10 green, >10 and
-- <=100 blue, >100 purple").
--
-- 2026-08-07 (Chris): ZERO OR NEGATIVE points are red. This sits
-- outside the quality palette on purpose - there is no red item quality
-- in Classic, and the point is that "Bavin does not want this" (or the
-- entry is wrong) should not read as just a very cheap item. Note the
-- ordering consequence: this is checked BEFORE the bands, because 0 and
-- every negative number satisfy `points <= 1` and would otherwise come
-- back white.
--
-- Colors come from Blizzard's ITEM_QUALITY_COLORS table when it's
-- present rather than being hardcoded, so the line always matches
-- whatever the client actually paints item names with. That table has
-- existed since vanilla and is indexed by the numeric quality (1 =
-- Common ... 4 = Epic); the literal RGB fallbacks below are the stock
-- Classic Era values and are used if it's ever missing, so a nil table
-- degrades to correct colors instead of a nil-index error. Deliberately
-- NOT using Enum.ItemQuality here - a missing global is a runtime nil no
-- syntax check can catch (k-0023), and plain numeric indices need no
-- such gamble. Only the added line's color changes; the rest of the
-- tooltip (item name, other lines, border) is untouched.
local QUALITY_POOR = 0
local QUALITY_COMMON, QUALITY_UNCOMMON, QUALITY_RARE, QUALITY_EPIC = 1, 2, 3, 4
local FALLBACK_QUALITY_COLORS = {
    [QUALITY_POOR]     = { 0.62, 0.62, 0.62 }, -- grey
    [QUALITY_COMMON]   = { 1.00, 1.00, 1.00 }, -- white
    [QUALITY_UNCOMMON] = { 0.12, 1.00, 0.00 }, -- green
    [QUALITY_RARE]     = { 0.00, 0.44, 0.87 }, -- blue
    [QUALITY_EPIC]     = { 0.64, 0.21, 0.93 }, -- purple
}

-- Ordered low band -> high band. First entry whose `max` the points do
-- not exceed wins; the last entry has no max and catches everything
-- above the top boundary.
local POINT_BANDS = {
    { max = 1,   quality = QUALITY_COMMON },
    { max = 10,  quality = QUALITY_UNCOMMON },
    { max = 100, quality = QUALITY_RARE },
    {            quality = QUALITY_EPIC },
}

-- Red for the zero/negative case. RED_FONT_COLOR is the game's own
-- standard red and has existed since vanilla, but it's read defensively
-- (k-0023: a missing global is a runtime nil no syntax check catches)
-- with the stock 1.0/0.125/0.125 as the fallback.
local FALLBACK_RED = { 1.00, 0.13, 0.13 }
local function RedColor()
    local c = RED_FONT_COLOR
    if c and c.r then
        return c.r, c.g, c.b
    end
    return FALLBACK_RED[1], FALLBACK_RED[2], FALLBACK_RED[3]
end

local function QualityColor(quality)
    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
    if c and c.r then
        return c.r, c.g, c.b
    end
    local f = FALLBACK_QUALITY_COLORS[quality] or FALLBACK_QUALITY_COLORS[QUALITY_COMMON]
    return f[1], f[2], f[3]
end

-- Points that are missing or non-numeric render GREY (Poor quality)
-- rather than erroring or silently masquerading as a real low-value
-- entry. Grey is deliberately outside the four value bands: it means
-- "no usable number here", not "worth very little", so a malformed or
-- half-entered row is visually obvious instead of reading as white.
local function PointsColor(points)
    if type(points) ~= "number" then
        return QualityColor(QUALITY_POOR)
    end
    -- Must precede the band loop - see the ordering note in the header
    -- comment. 0 and negatives would otherwise match `points <= 1`.
    if points <= 0 then
        return RedColor()
    end
    for _, band in ipairs(POINT_BANDS) do
        if not band.max or points <= band.max then
            return QualityColor(band.quality)
        end
    end
    return QualityColor(QUALITY_EPIC)
end

local function OnTooltipSetItem(tooltip)
    if not ns.GetItemPoints then return end -- Core.lua failed to load
    local name = tooltip:GetItem()
    if not name then return end
    local entry = ns.GetItemPoints(name)
    if not entry then return end
    local r, g, b = PointsColor(entry.points)
    -- entry.detail only exists for a non-overridden baseline entry (see
    -- Core.lua's GetItemPoints) - anything else (a live override, or an
    -- item added through the Points Editor with no spreadsheet detail)
    -- falls back to the plain line automatically.
    if USE_DETAIL_LINE and entry.detail then
        tooltip:AddLine(entry.detail, r, g, b)
    else
        tooltip:AddLine("Bavin Points: " .. FormatPoints(entry.points), r, g, b)
    end
    tooltip:Show()
end

GameTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
if ItemRefTooltip then
    ItemRefTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
end
