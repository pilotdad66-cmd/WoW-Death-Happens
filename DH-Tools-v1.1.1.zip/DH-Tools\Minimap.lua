-- DH-Tools: Minimap.lua
-- Standard LibDataBroker-1.1 / LibDBIcon-1.0 minimap button.
--
-- 2026-08-03: switched from the hand-rolled flat choice-list (no submenus)
-- to a real dropdown menu, after studying how the Questie addon gets
-- reliable right-click menus with nested/expandable submenus. Questie
-- doesn't use the shared "LibUIDropDownMenu-4.0" - it embeds its OWN copy
-- under a private LibStub name (LibUIDropDownMenuQuestie-4.0) plus private
-- global frame names, specifically so its copy can never collide with a
-- different (possibly older/patched) copy some other addon has registered
-- under the same shared name via LibStub. DH-Air's old right-click menu
-- bug (clicks not registering / menu not appearing, never reproduced or
-- diagnosed - see DH-Air's Minimap.lua) is very plausibly exactly that
-- collision. DH-Tools now vendors the same fork, renamed for this addon:
-- Libs\LibUIDropDownMenu\LibUIDropDownMenu.lua, LibStub name
-- "LibUIDropDownMenuDHTools-4.0". See claude\knowledge\ for the write-up.
--
-- 2026-08-03: left and right click now do different things - left click
-- opens DH-Tools' own Config window directly (DHTools:Config_Open("Tools")),
-- right click opens the full menu with everything DH-Tools does reachable
-- from it - Mob Marker, Quests, and DH-Air are expandable submenus
-- (hasArrow/menuList, same pattern Questie uses), Bavin Wants/Settings/
-- About are flat entries straight to a Config page. DH-Air is a separate
-- standalone addon (not a DH-Tools module - see ROADMAP.md), so its
-- submenu is a thin adapter into DH-Air's own _G.DHAir globals
-- (Board_Toggle/Config_Open/DestinationEditor_Open), guarded the same way
-- the Quests submenu guards against DHQuests being absent.

local ADDON_NAME = ...
local DHTools = DHTools

local LDB = LibStub("LibDataBroker-1.1")
local LDBIcon = LibStub("LibDBIcon-1.0")
local LibDropDown = LibStub("LibUIDropDownMenuDHTools-4.0")

-- A generic wrench icon - DH-Tools isn't tied to any one module's theme.
local TOOLS_ICON = "Interface\\Icons\\INV_Misc_Wrench_01"

-- 2026-08-03 (submenu direction fix): ToggleDropDownMenu decides whether a
-- level-2 submenu opens to the right (default) or flips to the left purely
-- by checking listFrame:GetRight() > GetScreenWidth() AFTER the submenu is
-- sized to fit its own button text - so a submenu with short entries (like
-- DH-Air's "Open Board"/"Open Config") can legitimately fit onscreen while
-- a wider one (Mob Marker's "Configure Target Icons...") doesn't, and only
-- the wider one flips left. Since the minimap button sits near the screen
-- edge, that made Mob Marker/Quests open left but DH-Air open right -
-- same underlying menu, inconsistent look. Fix: give every submenu button
-- the same generous minWidth (a field UIDropDownMenu_AddButton already
-- reads: `width = max(GetButtonWidth(button), info.minWidth or 0)`) so all
-- three submenus render at least as wide as the widest one and trigger the
-- same flip consistently, regardless of each submenu's own text length.
local SUBMENU_MIN_WIDTH = 180

--------------------------------------------------------------------------
-- Menu construction
--------------------------------------------------------------------------

-- A zero-height separator entry, same shape LibEasyMenu-style menus use
-- (copied from how Questie's own QuestieMenu.lua builds its divider).
local DIVIDER = {
    hasArrow = false,
    dist = 0,
    isTitle = true,
    isUninteractable = true,
    notCheckable = true,
    iconOnly = true,
    isSeparator = true,
    icon = "Interface\\Common\\UI-TooltipDivider-Transparent",
    -- @kb:divider-icon-info - these MUST live under iconInfo, not flat on
    -- this table: UIDropDownMenu_AddButton calls
    -- UIDropDownMenu_SetIconImage(icon, info.icon, info.iconInfo), and that
    -- function indexes its third arg directly (info.tCoordLeft etc.) with
    -- no nil guard - a flat info.tCoordLeft here is invisible to it, so
    -- info.iconInfo stayed nil and every dropdown menu open crashed
    -- mid-build on this divider (attempt to index local 'info' (a nil
    -- value), LibUIDropDownMenu.lua:1537) - see
    -- claude\knowledge\k-0004-dropdown-divider-iconinfo-must-be-nested.md.
    iconInfo = {
        tCoordLeft = 0, tCoordRight = 1, tCoordTop = 0, tCoordBottom = 1,
        tSizeX = 0, tSizeY = 8,
        tFitDropDownSizeX = true,
    },
    text = "",
}

local function BuildMobMarkerSubmenu()
    return {
        { text = "Configure Target Icons...", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            DHTools:Config_Open("MobMarker")
        end },
        DIVIDER,
        { text = "Require Mouseover to Mark", notCheckable = false, isNotRadio = true, keepShownOnClick = true, minWidth = SUBMENU_MIN_WIDTH,
            checked = DHToolsDB and DHToolsDB.mobmarker and DHToolsDB.mobmarker.requireMouseover,
            func = function()
                if DHToolsDB and DHToolsDB.mobmarker then
                    DHToolsDB.mobmarker.requireMouseover = not DHToolsDB.mobmarker.requireMouseover
                end
            end },
    }
end

local function BuildQuestsSubmenu()
    return {
        { text = "Open Quest Board", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            if DHQuests and DHQuests.Board_Toggle then
                DHQuests.Board_Toggle()
            end
        end },
        DIVIDER,
        { text = "Configure Sharing...", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            DHTools:Config_Open("Quests")
        end },
    }
end

-- DH-Air is a separate, standalone addon (2026-07-17 decision - will NOT
-- become a DH-Tools module), so this is a thin adapter into ITS globals
-- (_G.DHAir, exposed by DH-Air\Core.lua), same guarded pattern as the
-- Quests submenu above. If DH-Air isn't installed/loaded, show a single
-- disabled row instead of hiding the submenu outright - matches how
-- Config.lua's Tools page treats DH-Air as a visible status row rather
-- than omitting it silently.
--
-- 2026-08-03 (expanded): added Set Destination (a nested submenu listing
-- DHAir.db.destinations, calling DHAir:SetWarlockDestination - same
-- destination auto-summon's QueueNextAvailable filters against, see
-- DH-Air's Queue.lua) plus quick toggles mirroring the equivalent /dhair
-- slash commands (join/leave, summoner on/off, clicker on/off, invite
-- on/off, start/stop). All five toggles (Join/Leave Queue, Register/
-- Unregister as Summoner, Register/Unregister as Clicker, Auto Invite
-- On/Off, Auto Summons On/Off) use the same ColorActionEntry pattern:
-- the label names the ACTION a click performs (opposite of current
-- state), colored green when the underlying feature is CURRENTLY on,
-- red when currently off - color always tracks current state even
-- though the label names the opposite action. (Briefly tried a pure
-- current-state label for Auto Invite/Auto Summons after Loopi flagged
-- the action-word version as reading backwards against the color; he
-- confirmed on reflection the action+state-color pattern is what he
-- wants everywhere, so all five are back to it.) Two restrictions
-- layered on top of DH-Air's own API (DH-Air
-- itself doesn't enforce either - these are DH-Tools UI guards only, per
-- Loopi's explicit request): Am Summoner is Warlock-only (only Warlocks
-- cast the Ritual of Summoning DH-Air automates), and Auto Summons stays
-- disabled until the player has registered as a Summoner - mirrors the
-- existing "you need a destination first" gate RequestStartAutoSummon
-- already enforces, just for the "you need to BE a Summoner first" half.
local COLOR_ON = "|cff00ff00"  -- green - feature is currently ON
local COLOR_OFF = "|cffff0000" -- red - feature is currently OFF

local function IsWarlock()
    local _, classFile = UnitClass("player")
    return classFile == "WARLOCK"
end

-- True if the local player currently has an entry in DH-Air's summon
-- queue (regardless of whether they've already been summoned this
-- session - matches SelfJoinQueue/QueueAdd's own "already queued" dedupe
-- check, which doesn't distinguish either).
local function IsSelfQueued()
    if not (DHAir and DHAir.db and DHAir.db.queue) then return false end
    local myKey = DHAir:NormalizeName(UnitName("player"))
    for _, entry in ipairs(DHAir.db.queue) do
        if DHAir:NormalizeName(entry.name) == myKey then
            return true
        end
    end
    return false
end

-- Label names the ACTION a click performs (opposite of current state),
-- e.g. "Join Queue" while not queued, "Leave Queue" once queued. Color
-- still tracks CURRENT state (green = on, red = off).
local function ColorActionEntry(isOn, actionWhenOff, actionWhenOn, onClick)
    return {
        text = isOn and actionWhenOn or actionWhenOff,
        notCheckable = true,
        minWidth = SUBMENU_MIN_WIDTH,
        colorCode = isOn and COLOR_ON or COLOR_OFF,
        func = onClick,
    }
end

-- Builds one flat, radio-checked pick list for a category (+ continent for
-- flightpoints), used by BuildDestinationSubmenu below.
local function BuildDestinationList(category, continent)
    local current = DHAir.db.warlockDestination
    local entries = {}
    for _, d in ipairs(DHAir.db.destinations or {}) do
        if d.category == category and (not continent or d.continent == continent) and d.enabled ~= false then
            table.insert(entries, {
                text = d.label, notCheckable = false, isNotRadio = true, minWidth = SUBMENU_MIN_WIDTH,
                checked = (current == d.id),
                func = function()
                    DHAir:SetWarlockDestination(d.id)
                end,
            })
        end
    end
    if #entries == 0 then
        table.insert(entries, { text = "None configured", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH })
    end
    return entries
end

-- 2026-08-03: "Destination Config (Officers)" opens DestinationEditor.lua's
-- standalone window - that window itself is open to everyone (read-only
-- for non-officers, per its own header comment), but Loopi wants THIS
-- menu entry gated so only an officer even sees it as clickable here,
-- same "See List" (open) / "Officer Config" (gated) split Bavin Wants
-- uses. Calls the real DHAir:HasPermission("edit_destinations") check
-- (guild rank <= officerRankThreshold, default 3, OR the Loopidot
-- testing override baked into IsGuildOfficer) rather than re-approximating
-- a rank threshold locally - the same Loopidot bug already fixed once
-- this session for Bavin's Officer Config is not worth risking again here.
local function BuildDestinationConfigEntry()
    if DHAir and DHAir.HasPermission and DHAir:HasPermission("edit_destinations") then
        return { text = "Destination Config (Officers)", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH,
            func = function()
                if DHAir.DestinationEditor_Open then
                    DHAir:DestinationEditor_Open()
                end
            end }
    end
    return {
        text = "Destination Config (Officers)", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH,
        tooltipTitle = "Destination Config (Officers)",
        tooltipText = "Only guild officers can open this.",
        tooltipWhileDisabled = true,
    }
end

-- 2026-08-03: was one flat 52-entry list (33 flightpoints + 19 summon
-- stones) - Loopi asked for it broken up: Flight Points vs Dungeon Stones
-- first, Flight Points further split by continent (Destinations.lua's new
-- `continent` field - see that file and Core.lua's migration comment for
-- existing installs). Originally nested "Flight Points" -> "Eastern
-- Kingdoms"/"Kalimdor" -> actual entries, three levels under Set
-- Destination (already level 3 under DH-Tools > DH-Air). 2026-08-05
-- (Loopi-reported): the deepest level (the actual destination list) never
-- opened - same root cause Board.lua hit and fixed 2026-08-04 (see that
-- file's comment), just never mirrored here. Flattened the same way:
-- Eastern Kingdoms/Kalimdor are now their own top-level "Flight Points -
-- <continent>" arrow entries (one level shallower), matching Board.lua's
-- structure and naming exactly.
local function BuildDestinationSubmenu()
    if not (DHAir and DHAir.db) then
        return {
            { text = "Not installed", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH },
        }
    end
    return {
        { text = "Flight Points - Eastern Kingdoms", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, hasArrow = true,
            menuList = BuildDestinationList("flightpoint", "Eastern Kingdoms") },
        { text = "Flight Points - Kalimdor", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, hasArrow = true,
            menuList = BuildDestinationList("flightpoint", "Kalimdor") },
        { text = "Dungeon Stones", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, hasArrow = true,
            menuList = BuildDestinationList("summonstone", nil) },
        DIVIDER,
        { text = "Clear Destination", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            DHAir:SetWarlockDestination(nil)
        end },
        DIVIDER,
        BuildDestinationConfigEntry(),
    }
end

local function BuildDHAirSubmenu()
    if not DHAir then
        return {
            { text = "Not installed", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH },
        }
    end

    local myName = UnitName("player")
    local isSummoner = DHAir:IsRegistered("summoner", myName)
    local isClicker = DHAir:IsRegistered("clicker", myName)
    local queued = IsSelfQueued()
    local autoInviteOn = DHAir.db.autoInvite and true or false
    local autoSummonsOn = DHAir.db.active and true or false

    local entries = {
        { text = "Open Board", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            if DHAir.Board_Toggle then
                DHAir:Board_Toggle()
            end
        end },
        { text = "Open Config", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            if DHAir.Config_Open then
                DHAir:Config_Open()
            end
        end },
        { text = "Set Destination", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH,
            hasArrow = true, menuList = BuildDestinationSubmenu() },
        DIVIDER,
        ColorActionEntry(queued, "Join Queue", "Leave Queue", function()
            if queued then
                if DHAir:SelfLeaveQueue() then
                    DHAir:Print("You've left the summon queue.")
                end
            else
                if DHAir:SelfJoinQueue() then
                    DHAir:Print("You've joined the summon queue.")
                else
                    DHAir:Print("You're already in the queue (or already summoned this session).")
                end
            end
        end),
    }

    if IsWarlock() then
        table.insert(entries, ColorActionEntry(isSummoner, "Register as Summoner", "Unregister as Summoner", function()
            DHAir:SetRole("summoner", not isSummoner)
            DHAir:Print(isSummoner and "Unregistered as a Summoner." or "Registered as a Summoner.")
        end))
    else
        table.insert(entries, {
            text = "Am Summoner", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH,
            tooltipTitle = "Am Summoner", tooltipText = "Only Warlocks can register as a Summoner.",
            tooltipWhileDisabled = true,
        })
    end

    table.insert(entries, ColorActionEntry(isClicker, "Register as Clicker", "Unregister as Clicker", function()
        DHAir:SetRole("clicker", not isClicker)
        DHAir:Print(isClicker and "Unregistered as a Clicker." or "Registered as a Clicker.")
    end))

    -- 2026-08-03 (reverted same day, per Loopi): back to action-word text
    -- (what a click WILL do) with color tracking current state - Loopi's
    -- earlier "backwards" complaint was specifically about the wording,
    -- not this pattern in general; on reflection he confirmed action-text
    -- + state-color is what he wants for every toggle here, matching
    -- Join/Leave Queue's original design.
    table.insert(entries, ColorActionEntry(autoInviteOn, "Auto Invite On", "Auto Invite Off", function()
        DHAir.db.autoInvite = not autoInviteOn
        DHAir:Print(autoInviteOn and "Auto-invite disabled." or "Auto-invite enabled.")
    end))

    if isSummoner then
        table.insert(entries, ColorActionEntry(autoSummonsOn, "Auto Summons On", "Auto Summons Off", function()
            if autoSummonsOn then
                DHAir.db.active = false
                DHAir:Print("Auto-summon stopped. Auto-invite is still active.")
            else
                if DHAir:RequestStartAutoSummon() then
                    DHAir:Print("Auto-summon started.")
                end
            end
            if DHAir.Minimap_UpdateIcon then
                DHAir.Minimap_UpdateIcon()
            end
        end))
    else
        table.insert(entries, {
            text = "Auto Summons", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH,
            tooltipTitle = "Auto Summons", tooltipText = "Register as a Summoner first (Am Summoner above).",
            tooltipWhileDisabled = true,
        })
    end

    return entries
end

-- 2026-08-03: "Bavin Wants" expanded from a flat entry into a submenu -
-- See List (prints the current priority list to chat, same as /dhb items)
-- is open to everyone; Officer Config (opens the Bavin Config page) is
-- greyed out unless the player's OWN guild rank qualifies. Reuses
-- /dhb items' existing display logic via SlashCmdList["DHBAVIN"] rather
-- than duplicating it or exporting a new function off DHTools.Bavin -
-- there's no dedicated "view list" window yet (see DHBavin's
-- PROFILE.md/STATUS.md, M4 not built), just the slash command's chat
-- printout.
--
-- 2026-08-03 (fixed same day): originally a standalone rank<=3
-- approximation, independent of DH-Bavin's own real permission model -
-- Loopi caught that this meant Loopidot (hardcoded full access in
-- DH-Air, and since this same session, in DH-Bavin's own
-- IsGuildLeader too) still saw Officer Config greyed out here, because
-- this menu's rank guess didn't know about that override at all. Now
-- calls DHTools.Bavin.CanManageRecipient() directly instead of
-- re-approximating - the actual gate the Config page's Save button
-- itself enforces (guild-leader-only via IsGuildLeader, which now
-- includes the Loopidot override, or wide open while
-- ns.TESTING_ALLOW_ANYONE_TO_MANAGE = true) - so this menu can never
-- show a state inconsistent with what the page you're about to open
-- will actually let you do.
local function IsBavinOfficer()
    if not (DHTools.Bavin and DHTools.Bavin.CanManageRecipient) then return false end
    return DHTools.Bavin.CanManageRecipient()
end

local function BuildBavinSubmenu()
    local entries = {
        { text = "See List", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            if SlashCmdList and SlashCmdList["DHBAVIN"] then
                SlashCmdList["DHBAVIN"]("items")
            end
        end },
    }
    if IsBavinOfficer() then
        table.insert(entries, { text = "Officer Config", notCheckable = true, minWidth = SUBMENU_MIN_WIDTH, func = function()
            DHTools:Config_Open("Bavin")
        end })
    else
        table.insert(entries, {
            text = "Officer Config", notCheckable = true, disabled = true, minWidth = SUBMENU_MIN_WIDTH,
            tooltipTitle = "Officer Config",
            tooltipText = "Only the guild leader can open this.",
            tooltipWhileDisabled = true,
        })
    end
    return entries
end

-- Rebuilt fresh every time the menu opens so checkbox states (e.g. Require
-- Mouseover) always reflect current DHToolsDB values - same approach
-- Questie's QuestieMenu:Show() uses (rebuilds via buildX() functions
-- rather than keeping one static table around).
local function BuildMenu()
    return {
        { text = "Mob Marker", notCheckable = true, keepShownOnClick = true,
            hasArrow = true, menuList = BuildMobMarkerSubmenu() },
        { text = "Quests", notCheckable = true, keepShownOnClick = true,
            hasArrow = true, menuList = BuildQuestsSubmenu() },
        { text = "DH-Air", notCheckable = true, keepShownOnClick = true,
            hasArrow = true, menuList = BuildDHAirSubmenu() },
        { text = "Bavin Wants", notCheckable = true, keepShownOnClick = true,
            hasArrow = true, menuList = BuildBavinSubmenu() },
        DIVIDER,
        { text = "DH-Tools Settings", notCheckable = true, func = function()
            DHTools:Config_Open("Tools")
        end },
        { text = "About", notCheckable = true, func = function()
            DHTools:Config_Open("About")
        end },
    }
end

--------------------------------------------------------------------------
-- Dropdown frame (created once, reused every open)
--------------------------------------------------------------------------

local dropdownFrame

local function ToggleMenu()
    if LibDropDown:getOpen() then
        LibDropDown:CloseDropDownMenus()
        return
    end
    if not dropdownFrame then
        dropdownFrame = LibDropDown:Create_UIDropDownMenu("DHToolsMinimapMenuFrame", UIParent)
    end
    LibDropDown:EasyMenu(BuildMenu(), dropdownFrame, "cursor", -80, -15, "MENU", 2)
end

--------------------------------------------------------------------------
-- LibDataBroker button
--------------------------------------------------------------------------

local dataObject = LDB:NewDataObject("DHTools", {
    type = "launcher",
    text = "DH-Tools",
    icon = TOOLS_ICON,
    -- 2026-08-03: split by button - left click used to open the same menu
    -- as right click; now it jumps straight to DH-Tools' own Config window
    -- (the "DH-Tools Settings" menu entry's destination), since that's the
    -- single most common thing Loopi wants from a left click. Right click
    -- keeps the full menu (Mob Marker/Quests/DH-Air/Bavin Wants/Settings/
    -- About).
    OnClick = function(_, button)
        if button == "LeftButton" then
            DHTools:Config_Open("Tools")
        else
            ToggleMenu()
        end
    end,
    OnTooltipShow = function(tooltip)
        if not tooltip or not tooltip.AddLine then return end
        tooltip:AddLine("DH-Tools")
        tooltip:AddLine(" ")
        tooltip:AddLine("Left Click: DH-Tools Config")
        tooltip:AddLine("Right Click: DH-Tools Menu")
    end,
})

function DHTools.Minimap_Init()
    LDBIcon:Register("DHTools", dataObject, DHTools.db.minimap)
end
