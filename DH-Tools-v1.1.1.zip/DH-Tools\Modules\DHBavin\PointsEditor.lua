-- DH-Bavin PointsEditor.lua
-- In-game editor for Bavin Points (see ItemPoints.lua's header for the
-- static ~7000-entry baseline, and Core.lua's "Item points" section for
-- the override/version plumbing this file drives). Opened via
-- /dhb points (Core.lua's slash dispatch calls ns.PointsEditor_Toggle).
--
-- GATING: unlike DestinationEditor.lua (DH-Air's own editor, the pattern
-- this file's window chrome is ported from), this window is NOT
-- viewable read-only by everyone - Loopi's original ask was "a totally
-- separate window, only available to Bavin and Loopidot for now", which
-- the finalized design answered by reusing CanEditList (recipient/
-- editors) rather than a separate Bavin+Loopidot-only gate. So
-- PointsEditor_Open refuses outright (never creates/shows the frame) if
-- CanEditList fails, instead of DestinationEditor's "show everyone, hide
-- only the edit controls" approach. Closing is always allowed regardless
-- of permission.
--
-- SEARCH, NOT A FULL LIST: ~7000 entries is far too many to list (see
-- Config.lua's BuildSuggestPool/PopulateSuggestions comment for the exact
-- same lesson learned the hard way on a ~1000-member roster picker) - so
-- this mirrors that type-to-filter pattern instead of DestinationEditor's
-- "render every row" approach. Matching is a plain case-insensitive
-- substring scan over ns.ITEM_POINTS' keys, capped to MAX_RESULTS
-- materialized rows; only the baseline's own item names are searchable,
-- since a live override can only ever be set on a name that already
-- exists in the shipped baseline (this editor never adds brand-new
-- items, only assigns/reverts a points value on existing ones).
--
-- itemId is shown read-only (per Loopi's design) - saving a new points
-- value always carries forward whatever itemId GetItemPoints already
-- reported for that name, never lets the points edit box clobber it.

local DHTools = DHTools
local ns = DHTools.Bavin

local ROW_HEIGHT = 20
local MAX_RESULTS = 25

local frame
local rowPool = {}
local searchText = ""

--------------------------------------------------------------------------
-- Matching
--------------------------------------------------------------------------

-- Case-insensitive plain-substring scan over the shipped baseline's
-- names (see file header for why only baseline names are searchable).
-- Returns every match, sorted alphabetically - callers cap how many they
-- actually render. Full ~7000-key scan per keystroke is cheap in Lua
-- (this is a table scan + string.find, not frame creation - the
-- expensive part this file avoids is materializing UI rows, per the
-- header comment), so no early-break is needed here for performance.
local function BuildMatches(typed)
    local matches = {}
    if typed == "" or not ns.ITEM_POINTS then return matches end
    local needle = typed:lower()
    for name in pairs(ns.ITEM_POINTS) do
        if name:lower():find(needle, 1, true) then
            table.insert(matches, name)
        end
    end
    table.sort(matches)
    return matches
end

--------------------------------------------------------------------------
-- Row pool (search results)
--------------------------------------------------------------------------

local function CreateRow(parent, index)
    local row = CreateFrame("Frame", nil, parent)
    row:SetHeight(ROW_HEIGHT)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", 0, -(index - 1) * ROW_HEIGHT)
    row:SetPoint("RIGHT", parent, "RIGHT", 0, 0)

    row.bg = row:CreateTexture(nil, "BACKGROUND")
    row.bg:SetAllPoints()
    row.bg:SetColorTexture(1, 1, 1, 0.03)

    -- Only shown for rows currently carrying a live override (see
    -- RenderRow) - reverting is an explicit action, never implied by
    -- clearing the points field (that's a no-op, not a revert; see the
    -- OnEnterPressed handler below).
    row.revertBtn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    row.revertBtn:SetSize(52, 18)
    row.revertBtn:SetText("Revert")
    row.revertBtn:SetPoint("RIGHT", row, "RIGHT", -2, 0)

    -- Text mode, not SetNumeric(true) - WoW's numeric EditBox mode
    -- disallows the leading "-" a negative point value needs (0 and
    -- negative points are valid - Loopi confirmed this during intake).
    -- Validated with tonumber() on submit instead.
    row.pointsEdit = CreateFrame("EditBox", nil, row, "InputBoxTemplate")
    row.pointsEdit:SetSize(44, 18)
    row.pointsEdit:SetPoint("RIGHT", row.revertBtn, "LEFT", -8, 0)
    row.pointsEdit:SetAutoFocus(false)
    row.pointsEdit:SetMaxLetters(8)
    row.pointsEdit:SetJustifyH("RIGHT")

    row.itemIdText = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    row.itemIdText:SetPoint("RIGHT", row.pointsEdit, "LEFT", -10, 0)
    row.itemIdText:SetWidth(50)
    row.itemIdText:SetJustifyH("RIGHT")
    row.itemIdText:SetWordWrap(false)

    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("LEFT", row, "LEFT", 4, 0)
    row.nameText:SetPoint("RIGHT", row.itemIdText, "LEFT", -10, 0)
    row.nameText:SetJustifyH("LEFT")
    -- Truncate rather than wrap - rows are fixed-height, same reasoning
    -- as DestinationEditor's labelText (the window is resizable, so a
    -- truncated name can still be read in full by widening it).
    row.nameText:SetWordWrap(false)

    return row
end

local function AcquireRow(parent, index)
    if not rowPool[index] then
        rowPool[index] = CreateRow(parent, index)
    end
    return rowPool[index]
end

local function HideRowsFrom(startIndex)
    for i = startIndex, #rowPool do
        rowPool[i]:Hide()
    end
end

local function RenderRow(row, name, index)
    row.bg:SetColorTexture(1, 1, 1, (index % 2 == 0) and 0.03 or 0.0)

    local info = ns.GetItemPoints(name)

    row.nameText:SetText(name)
    if info and info.isOverride then
        row.nameText:SetTextColor(1, 0.82, 0) -- flags a live edit at a glance
    else
        row.nameText:SetTextColor(1, 1, 1)
    end

    row.itemIdText:SetText((info and info.itemId) and tostring(info.itemId) or "\226\128\148")

    row.pointsEdit:SetText((info and info.points ~= nil) and tostring(info.points) or "")
    row.pointsEdit:SetCursorPosition(0)
    row.pointsEdit:SetScript("OnEnterPressed", function(self)
        local text = (self:GetText() or ""):match("^%s*(.-)%s*$")
        self:ClearFocus()
        if text == "" then
            return -- explicit no-op - use Revert to actually clear an override
        end
        local points = tonumber(text)
        if not points then
            ns.Print("'" .. text .. "' isn't a number - points edit not saved.")
            ns.PointsEditor_Refresh() -- restores the field to its last real value
            return
        end
        local keepItemId = info and info.itemId or nil
        if ns.SetItemPoints(name, points, keepItemId) then
            ns.PointsEditor_Refresh()
        else
            ns.Print("Refused - you must be the recipient or an editor.")
            ns.PointsEditor_Refresh()
        end
    end)
    row.pointsEdit:SetScript("OnEscapePressed", function(self)
        self:ClearFocus()
        ns.PointsEditor_Refresh()
    end)

    row.revertBtn:SetShown(info ~= nil and info.isOverride)
    row.revertBtn:SetScript("OnClick", function()
        ns.RevertItemPoints(name)
        ns.PointsEditor_Refresh()
    end)

    row:Show()
end

--------------------------------------------------------------------------
-- Frame construction (built once, first time the editor is opened)
--------------------------------------------------------------------------

local function CreateEditorFrame()
    frame = CreateFrame("Frame", "DHBavinPointsEditorFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(440, 460)
    frame:SetPoint("CENTER")
    if frame.TitleText then
        frame.TitleText:SetText("Bavin - Points Editor")
    end
    tinsert(UISpecialFrames, "DHBavinPointsEditorFrame")

    -- Toplevel raising, opaque background, title-bar-only dragging - see
    -- DH-Tools Core.lua's InitStandaloneWindow. Dot-call, not colon: it's
    -- a plain shared function hung off the DHTools table, not a method
    -- on a "self" object the way DH-Air's own InitStandaloneWindow is.
    DHTools.InitStandaloneWindow(frame)

    frame:SetResizable(true)
    if frame.SetMinResize then frame:SetMinResize(360, 320) end
    if frame.SetMaxResize then frame:SetMaxResize(700, 800) end

    frame.resizeBtn = CreateFrame("Button", nil, frame)
    frame.resizeBtn:SetSize(16, 16)
    frame.resizeBtn:SetPoint("BOTTOMRIGHT", -4, 4)
    frame.resizeBtn:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    frame.resizeBtn:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    frame.resizeBtn:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    frame.resizeBtn:SetScript("OnMouseDown", function() frame:StartSizing("BOTTOMRIGHT") end)
    frame.resizeBtn:SetScript("OnMouseUp", function() frame:StopMovingOrSizing() end)

    frame:SetScript("OnSizeChanged", function()
        if frame:IsShown() then
            ns.PointsEditor_Refresh()
        end
    end)

    frame.hint = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.hint:SetPoint("TOPLEFT", 12, -32)
    frame.hint:SetPoint("RIGHT", -12, 0)
    frame.hint:SetJustifyH("LEFT")
    frame.hint:SetWordWrap(true)
    frame.hint:SetText("Search an item name below to view or edit its Bavin Points. Saved changes push live to everyone online, and sync to anyone who logs in later.")

    frame.searchEdit = CreateFrame("EditBox", "DHBavinPointsEditorSearch", frame, "InputBoxTemplate")
    frame.searchEdit:SetSize(200, 20)
    frame.searchEdit:SetPoint("TOPLEFT", frame.hint, "BOTTOMLEFT", 6, -10)
    frame.searchEdit:SetAutoFocus(false)
    frame.searchEdit:SetMaxLetters(64)
    frame.searchEdit:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    frame.searchEdit:SetScript("OnEscapePressed", function(self) self:SetText(""); self:ClearFocus() end)
    frame.searchEdit:SetScript("OnTextChanged", function(self)
        searchText = (self:GetText() or ""):match("^%s*(.-)%s*$")
        ns.PointsEditor_Refresh()
    end)

    frame.resultsHint = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.resultsHint:SetPoint("TOPLEFT", frame.searchEdit, "BOTTOMLEFT", -6, -10)
    frame.resultsHint:SetPoint("RIGHT", -12, 0)
    frame.resultsHint:SetJustifyH("LEFT")

    -- Cosmetic column labels for the anonymous columns each result row
    -- renders (name / itemId / points / revert) - right-justified so
    -- "itemID" and "points" roughly land over their columns below.
    frame.colHeaders = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    frame.colHeaders:SetPoint("TOPLEFT", frame.resultsHint, "BOTTOMLEFT", 6, -8)
    frame.colHeaders:SetPoint("RIGHT", -12, 0)
    frame.colHeaders:SetJustifyH("RIGHT")
    frame.colHeaders:SetText("itemID   points")

    frame.scrollFrame = CreateFrame("ScrollFrame", "DHBavinPointsEditorScrollFrame", frame, "UIPanelScrollFrameTemplate")
    frame.scrollFrame:SetPoint("TOPLEFT", frame.colHeaders, "BOTTOMLEFT", 0, -6)
    frame.scrollFrame:SetPoint("BOTTOMRIGHT", -30, 12)

    frame.scrollContent = CreateFrame("Frame", nil, frame.scrollFrame)
    frame.scrollContent:SetSize(1, 1)
    frame.scrollFrame:SetScrollChild(frame.scrollContent)
end

--------------------------------------------------------------------------
-- Public API
--------------------------------------------------------------------------

function ns.PointsEditor_Refresh()
    if not frame or not frame:IsShown() then return end

    local content = frame.scrollContent
    content:SetWidth(math.max(1, frame.scrollFrame:GetWidth() - 24))

    local matches = BuildMatches(searchText)
    local totalMatches = #matches
    local shown = math.min(totalMatches, MAX_RESULTS)

    for i = 1, shown do
        local row = AcquireRow(content, i)
        RenderRow(row, matches[i], i)
    end
    HideRowsFrom(shown + 1)
    content:SetHeight(math.max(1, shown * ROW_HEIGHT))

    if searchText == "" then
        frame.resultsHint:SetText("Type part of an item name to search.")
    elseif totalMatches == 0 then
        frame.resultsHint:SetText("No matching items.")
    elseif totalMatches > shown then
        frame.resultsHint:SetText(("Showing %d of %d matches - narrow your search to see the rest."):format(shown, totalMatches))
    else
        frame.resultsHint:SetText(totalMatches .. " matching item" .. (totalMatches == 1 and "" or "s") .. ".")
    end
end

-- Refuses outright (no frame created/shown) if the caller isn't the
-- recipient or a designated editor - see file header's GATING note for
-- why this differs from DestinationEditor's read-only-for-everyone
-- approach.
function ns.PointsEditor_Open()
    if not ns.CanEditListLocal() then
        ns.Print("Only the recipient or a designated editor can open the Points Editor.")
        return
    end
    if not frame then
        CreateEditorFrame()
    end
    frame:Show()
    ns.PointsEditor_Refresh()
end

-- Closing is always allowed regardless of permission - only opening is
-- gated (see PointsEditor_Open).
function ns.PointsEditor_Toggle()
    if frame and frame:IsShown() then
        frame:Hide()
        return
    end
    ns.PointsEditor_Open()
end
