-- DH-Tools: Modules\DHBavin\Tooltip.lua
-- Adds a "Bavin Points: N" line to any item tooltip whose exact display
-- name appears in ItemPoints.lua's ns.ITEM_POINTS table (or has a live
-- in-game override on top of it - see Core.lua's "Item points" section)
-- - see ItemPoints.lua's header for why the lookup is by name, not
-- itemID (random-suffix rare items share one base itemID but price
-- differently per suffix). Read-only informational display, no
-- permission gate - this doesn't reveal anything guildmates can't
-- already see in the source spreadsheet (or, for a live edit, in the
-- Points Editor itself - PointsEditor.lua).
--
-- Uses ns.GetItemPoints(name), NOT ns.ITEM_POINTS[name] directly, so a
-- Points Editor override is reflected here immediately instead of only
-- after the next addon release ships a regenerated ItemPoints.lua.
--
-- Hooked via GameTooltip:HookScript("OnTooltipSetItem", ...) - the
-- standard, low-risk tooltip-extension idiom (unlike Bavin's still-
-- unbuilt M5 bag-highlight hook, which has real unverified API risk -
-- see PROFILE.md's Known risks). Per Blizzard's own API contract,
-- OnTooltipSetItem fires for every item-setting method on the tooltip -
-- SetBagItem, SetInventoryItem, SetHyperlink (chat item links, both
-- hover and the persistent ItemRefTooltip a click opens), SetAction
-- (action bar items), SetMerchantItem, SetLootItem, and more - because
-- it hooks the shared GameTooltip object itself, not any one caller.
-- Also hooks ItemRefTooltip directly (belt-and-suspenders for the
-- clicked-link case, a separate frame object from GameTooltip).
--
-- 2026-08-08 (Chris): confirmed working for bags; requested for chat
-- links and action bars specifically. Mechanically this ONE hook should
-- already cover both per the contract above - added below is a real gap
-- it doesn't close on its own: an item whose info the client hasn't
-- cached yet (GetItemInfo/tooltip:GetItem() returns nil until a server
-- round-trip completes) shows a blank/partial tooltip on first hover,
-- same caching gap DHDangerLootDump.lua already had to handle for a
-- different reason. Bag/merchant items are usually already cached
-- because you're carrying or looking at them; an item someone else
-- linked in chat, or one you haven't picked up in a while, may not be.
-- See TryAddLine/the GET_ITEM_INFO_RECEIVED watcher below.
--
-- 2026-08-08 (Chris, in-game result #1): chat links confirmed working;
-- action bar hover confirmed NOT working. So OnTooltipSetItem does not
-- actually fire for SetAction in this client, contrary to the
-- documented contract above - added hooksecurefunc(GameTooltip,
-- "SetAction", ...) as a second path, independent of whether
-- OnTooltipSetItem fires for it.
--
-- 2026-08-08 (Chris, in-game result #2): STILL not working after that.
-- Real cause, on reflection: the SetAction hook was still calling
-- tooltip:GetItem() to identify the item, same as the bag/hyperlink
-- path - but GetItem() reads from the tooltip's internal ITEM-tooltip
-- state, which SetAction's own C-side implementation apparently never
-- populates for an action-slot item the way SetBagItem/SetHyperlink do
-- (it visually SHOWS item info without wiring through the same shared
-- state GetItem() reads). No amount of retrying fixes that - it isn't
-- delayed, it's simply never set. So the action-bar path now identifies
-- the item a completely different way: GetActionInfo(slot) for the
-- itemID directly from the action-bar API, then GetItemInfo(itemID) for
-- the name, bypassing tooltip:GetItem() entirely for this path. See
-- OnSetAction/pendingItem below - a parallel retry mechanism to
-- TryAddLine/pending, keyed by itemID instead of by re-reading the
-- tooltip, since GetItemInfo(itemID) can still return nil once (cache
-- miss) even though tooltip:GetItem() never will for this path.

local DHTools = DHTools
DHTools.Bavin = DHTools.Bavin or {}
local ns = DHTools.Bavin

-- 2026-08-06 (Chris): trying the spreadsheet's richer column-P summary
-- line ("<name>: <points> pts to Bavin; <price/source>", e.g. "crafted
-- by an @Alchemist" or "(est. AH value)") in place of the plain "Bavin
-- Points: N" line, on a trial basis - Chris wants to see how it looks
-- in-game before committing to it, with an easy one-line revert if it's
-- too much text for a tooltip. Flip this back to false to instantly
-- restore the old plain-points line - no other code changes needed.
local USE_DETAIL_LINE = true

local function FormatPoints(points)
    if points == math.floor(points) then
        return string.format("%d", points)
    end
    return string.format("%.2f", points)
end

-- 2026-08-06 (Chris, revised same day): the tooltip line is now colored
-- on a four-band scale using the GAME'S OWN item-quality palette, so a
-- glance reads the same way gear rarity does - white/green/blue/purple
-- as value climbs. This replaces the earlier two-tier gold/green
-- experiment (>10 = green, everything else gold) entirely.
--
--   points <= 0              RED     (see RedColor - not a quality band)
--   points >  0  and <= 1    white   (Common)
--   points >  1  and <= 10   green   (Uncommon)
--   points > 10  and <= 100  blue    (Rare)
--   points > 100             purple  (Epic)
--   points missing/not a number   grey (Poor) - see PointsColor
--
-- Bands are evaluated low-to-high with strictly-greater-than upper
-- bounds, so each boundary value (1, 10, 100) belongs to the LOWER band
-- - exactly as Chris phrased it ("<=1 white, >1 and <=10 green, >10 and
-- <=100 blue, >100 purple").
--
-- 2026-08-07 (Chris): ZERO OR NEGATIVE points are red. This sits
-- outside the quality palette on purpose - there is no red item quality
-- in Classic, and the point is that "Bavin does not want this" (or the
-- entry is wrong) should not read as just a very cheap item. Note the
-- ordering consequence: this is checked BEFORE the bands, because 0 and
-- every negative number satisfy `points <= 1` and would otherwise come
-- back white.
--
-- Colors come from Blizzard's ITEM_QUALITY_COLORS table when it's
-- present rather than being hardcoded, so the line always matches
-- whatever the client actually paints item names with. That table has
-- existed since vanilla and is indexed by the numeric quality (1 =
-- Common ... 4 = Epic); the literal RGB fallbacks below are the stock
-- Classic Era values and are used if it's ever missing, so a nil table
-- degrades to correct colors instead of a nil-index error. Deliberately
-- NOT using Enum.ItemQuality here - a missing global is a runtime nil no
-- syntax check can catch (k-0023), and plain numeric indices need no
-- such gamble. Only the added line's color changes; the rest of the
-- tooltip (item name, other lines, border) is untouched.
local QUALITY_POOR = 0
local QUALITY_COMMON, QUALITY_UNCOMMON, QUALITY_RARE, QUALITY_EPIC = 1, 2, 3, 4
local FALLBACK_QUALITY_COLORS = {
    [QUALITY_POOR]     = { 0.62, 0.62, 0.62 }, -- grey
    [QUALITY_COMMON]   = { 1.00, 1.00, 1.00 }, -- white
    [QUALITY_UNCOMMON] = { 0.12, 1.00, 0.00 }, -- green
    [QUALITY_RARE]     = { 0.00, 0.44, 0.87 }, -- blue
    [QUALITY_EPIC]     = { 0.64, 0.21, 0.93 }, -- purple
}

-- Ordered low band -> high band. First entry whose `max` the points do
-- not exceed wins; the last entry has no max and catches everything
-- above the top boundary.
local POINT_BANDS = {
    { max = 1,   quality = QUALITY_COMMON },
    { max = 10,  quality = QUALITY_UNCOMMON },
    { max = 100, quality = QUALITY_RARE },
    {            quality = QUALITY_EPIC },
}

-- Red for the zero/negative case. RED_FONT_COLOR is the game's own
-- standard red and has existed since vanilla, but it's read defensively
-- (k-0023: a missing global is a runtime nil no syntax check catches)
-- with the stock 1.0/0.125/0.125 as the fallback.
local FALLBACK_RED = { 1.00, 0.13, 0.13 }
local function RedColor()
    local c = RED_FONT_COLOR
    if c and c.r then
        return c.r, c.g, c.b
    end
    return FALLBACK_RED[1], FALLBACK_RED[2], FALLBACK_RED[3]
end

local function QualityColor(quality)
    local c = ITEM_QUALITY_COLORS and ITEM_QUALITY_COLORS[quality]
    if c and c.r then
        return c.r, c.g, c.b
    end
    local f = FALLBACK_QUALITY_COLORS[quality] or FALLBACK_QUALITY_COLORS[QUALITY_COMMON]
    return f[1], f[2], f[3]
end

-- Points that are missing or non-numeric render GREY (Poor quality)
-- rather than erroring or silently masquerading as a real low-value
-- entry. Grey is deliberately outside the four value bands: it means
-- "no usable number here", not "worth very little", so a malformed or
-- half-entered row is visually obvious instead of reading as white.
local function PointsColor(points)
    if type(points) ~= "number" then
        return QualityColor(QUALITY_POOR)
    end
    -- Must precede the band loop - see the ordering note in the header
    -- comment. 0 and negatives would otherwise match `points <= 1`.
    if points <= 0 then
        return RedColor()
    end
    for _, band in ipairs(POINT_BANDS) do
        if not band.max or points <= band.max then
            return QualityColor(band.quality)
        end
    end
    return QualityColor(QUALITY_EPIC)
end

-- Tooltips that already got our line added for the CURRENT build, keyed
-- by tooltip object - guards against a double-add when both resolution
-- paths below ever fire for the same single hover. Reset on
-- OnTooltipCleared (fired by ClearLines, which every Set* call makes
-- before repopulating - see the reset hook below), so a fresh hover
-- always gets a fresh chance to add the line even when re-hovering the
-- exact same item.
local added = {}

-- Shared by both resolution paths once a name is known. Returns true
-- (always - by this point the item IS resolved, priced or not).
local function AddPointsLine(tooltip, name)
    local entry = ns.GetItemPoints(name)
    if entry then
        local r, g, b = PointsColor(entry.points)
        -- entry.detail only exists for a non-overridden baseline entry
        -- (see Core.lua's GetItemPoints) - anything else (a live
        -- override, or an item added through the Points Editor with no
        -- spreadsheet detail) falls back to the plain line automatically.
        if USE_DETAIL_LINE and entry.detail then
            tooltip:AddLine(entry.detail, r, g, b)
        else
            tooltip:AddLine("Bavin Points: " .. FormatPoints(entry.points), r, g, b)
        end
        tooltip:Show()
    end
    added[tooltip] = true
    return true
end

-- ---------------------------------------------------------------
-- Path 1: bags, chat links, merchant, etc - anything that actually
-- populates the tooltip's item-tooltip state, so tooltip:GetItem()
-- resolves (maybe not on the first call - see the cache-miss note in
-- the header comment).
-- ---------------------------------------------------------------

-- Returns true once the tooltip's item is actually resolved (whether or
-- not it turned out to be a priced item) - false means "not resolved
-- yet, try again later", the signal the retry watcher below acts on.
local function TryAddLine(tooltip)
    if added[tooltip] then return true end
    if not ns.GetItemPoints then return true end -- Core.lua failed to load; nothing to retry for
    local name = tooltip:GetItem()
    if not name then return false end
    return AddPointsLine(tooltip, name)
end

-- Tooltips currently waiting on item info that hasn't arrived yet, keyed
-- by tooltip object (GameTooltip and ItemRefTooltip can be pending
-- independently - e.g. a pinned ItemRefTooltip window while hovering a
-- different item elsewhere).
local pending = {}

local function OnTooltipSetItem(tooltip)
    if TryAddLine(tooltip) then
        pending[tooltip] = nil
    else
        pending[tooltip] = true
    end
end

GameTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
if ItemRefTooltip then
    ItemRefTooltip:HookScript("OnTooltipSetItem", OnTooltipSetItem)
end

-- ---------------------------------------------------------------
-- Path 2: action bar slots - tooltip:GetItem() never resolves here (see
-- header comment), so identify the item via the action-bar API instead:
-- GetActionInfo(slot) for the itemID, GetItemInfo(itemID) for the name.
-- ---------------------------------------------------------------

-- Tooltips waiting on GetItemInfo(itemID) for an action-bar item, keyed
-- by tooltip object -> itemID (not a plain "retry" flag, since the
-- retry has to re-query by itemID, not by re-reading the tooltip).
local pendingItem = {}

local function OnSetAction(tooltip, slot)
    if added[tooltip] then return end
    if not ns.GetItemPoints or not slot then return end
    local actionType, id = GetActionInfo(slot)
    if actionType ~= "item" or not id then
        added[tooltip] = true -- not an item action - resolved, nothing to add
        return
    end
    local name = GetItemInfo(id)
    if name then
        AddPointsLine(tooltip, name)
    else
        pendingItem[tooltip] = id -- cache miss - retry once GET_ITEM_INFO_RECEIVED fires
    end
end

if GameTooltip.SetAction then
    hooksecurefunc(GameTooltip, "SetAction", OnSetAction)
end

-- Retries every still-open pending tooltip (either path) whenever ANY
-- item's info arrives (cheap - this event doesn't fire often), stopping
-- once a given tooltip resolves or is no longer shown. Does not
-- explicitly request the item's data itself; the original
-- SetHyperlink/SetAction/etc. call already triggers that as a side
-- effect, same as it does for the client's normal (non-addon) tooltip
-- display.
local infoWatcher = CreateFrame("Frame")
infoWatcher:RegisterEvent("GET_ITEM_INFO_RECEIVED")
infoWatcher:SetScript("OnEvent", function()
    for tooltip in pairs(pending) do
        if not tooltip:IsShown() then
            pending[tooltip] = nil
        elseif TryAddLine(tooltip) then
            pending[tooltip] = nil
        end
    end
    for tooltip, id in pairs(pendingItem) do
        if not tooltip:IsShown() then
            pendingItem[tooltip] = nil
        else
            local name = GetItemInfo(id)
            if name then
                AddPointsLine(tooltip, name)
                pendingItem[tooltip] = nil
            end
        end
    end
end)

-- Resets the double-add guard once per hover, before any Set* call.
GameTooltip:HookScript("OnTooltipCleared", function(tooltip)
    added[tooltip] = nil
    pending[tooltip] = nil
    pendingItem[tooltip] = nil
end)
