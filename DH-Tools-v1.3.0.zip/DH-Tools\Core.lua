-- DH-Tools: Core.lua
-- Master addon - lets a guild member activate/deactivate individual
-- modules from one addon. See claude\DH-Tools\PROFILE.md for the module
-- registration contract and claude\DH-Tools\DH-Tools-Design.md for the
-- full design/milestone plan.

local ADDON_NAME = ...

DHTools = DHTools or {}
local ns = DHTools
ns.ADDON_NAME = ADDON_NAME
-- 2026-08-06 (Chris): was a hardcoded "1.0" literal that never got
-- touched during the v1.1.2 release - build-release-zip.ps1's -Version
-- param only names the output zip file, it does NOT write the .toc's own
-- "## Version:" line (that gets edited by hand), and nothing here ever
-- read that line back, so the About page kept showing "1.0" through
-- multiple real releases. Fixed at the root instead of just updating the
-- literal (which would only recreate the same drift at the next
-- release): read the version from the .toc's own metadata, same
-- dual-path C_AddOns/legacy-global idiom already used elsewhere in this
-- codebase (e.g. IsAddOnInstalled's GetAddOnInfo fallback) - now there's
-- exactly one place to edit at release time (the .toc line) and this
-- always reflects it.
ns.VERSION = (GetAddOnMetadata and GetAddOnMetadata(ADDON_NAME, "Version"))
    or (C_AddOns and C_AddOns.GetAddOnMetadata and C_AddOns.GetAddOnMetadata(ADDON_NAME, "Version"))
    or "unknown"

-- === Module registry ===
-- Each module file calls DHTools.RegisterModule(key, def) at load time.
-- def = {
--   name = "Display Name",       -- shown in /dht list and the Tools config page
--   desc = "One short line.",    -- optional: shown under the module's row in
--                                -- the Tools config page (Config.lua) - keep
--                                -- it to a single line, small print
--   default = true/false,        -- state on a fresh install (no saved value yet)
--   OnEnable = function() end,   -- optional: called on enable (incl. at login if already on)
--   OnDisable = function() end,  -- optional: called on disable
-- }
-- Saved enable state lives in DHToolsDB.modules[key]. Module-specific data
-- goes in the module's own DHToolsDB.<key> sub-table - Core.lua never
-- touches those.
ns.modules = {}
ns.moduleOrder = {}

function ns.RegisterModule(key, def)
    if ns.modules[key] then
        error("DH-Tools: module '" .. key .. "' already registered")
    end
    ns.modules[key] = def
    table.insert(ns.moduleOrder, key)
end

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99DH-Tools:|r " .. msg)
end

function ns.InitDB()
    if type(DHToolsDB) ~= "table" then
        DHToolsDB = {}
    end
    if type(DHToolsDB.modules) ~= "table" then
        DHToolsDB.modules = {}
    end
    if type(DHToolsDB.minimap) ~= "table" then
        DHToolsDB.minimap = { hide = false }
    end
    ns.db = DHToolsDB
end

-- === Author account admin (2026-08-05) ===
-- PUBLIC-RELEASE TOGGLE: set AUTHOR_OVERRIDE_ENABLED to false (or delete
-- this whole section, its call site in the PLAYER_LOGIN handler below,
-- and the `## SavedVariables: DHToolsAccountDB` line in DH-Tools.toc)
-- before distributing DH-Tools to a guild you're not personally a
-- member of - see claude\ROADMAP.md's Publishing workflow section.
--
-- WHY THIS EXISTS: the addon API deliberately has no way to ask "is
-- this character on the same account as character X" for anyone but
-- the CURRENT account (C_AccountInfo.IsGUIDRelatedToLocalAccount only
-- answers for the account actually running the check) - Blizzard walls
-- this off for privacy, so per-module admin overrides have always been
-- scoped to one hardcoded character name (FULL_PERMISSION_OVERRIDE_NAME
-- in DH-Bavin's Core.lua, same idiom in DH-Air's). That's fine for
-- REMOTE verification (another client checking who sent a network
-- message - there's no alternative), but means Loopi had to log into
-- one specific character to get admin access locally, on every alt.
--
-- FIX: SavedVariables (not SavedVariablesPerCharacter) ARE inherently
-- account-scoped by the client itself - one file per WoW account,
-- shared automatically by every character logged into it (DHBavinDB
-- already relies on exactly this for recipient/editors - see its own
-- 2026-07-29 fix). This reuses that existing mechanism instead of
-- trying to re-derive account identity: the first time ANY character in
-- AUTHOR_CHARACTER_NAMES logs in, the ACCOUNT (via DHToolsAccountDB)
-- gets flagged, not just that one character - every other character on
-- the same account, including alts created afterward, then gets full
-- local admin automatically, with zero further maintenance.
--
-- SCOPE: LOCAL ONLY - this decides what THIS client is allowed to do
-- (ns.IsAuthorAccount(), called from each module's own local-only
-- permission entry points). It cannot help verify an INCOMING network
-- message's sender, since a receiving client has no access to the
-- sender's account-wide SavedVariables - that side still goes through
-- each module's own FULL_PERMISSION_OVERRIDE_NAME-style character-name
-- check, unchanged. See claude\knowledge\ for the full writeup.
local AUTHOR_OVERRIDE_ENABLED = true
local AUTHOR_CHARACTER_NAMES = { Loopi = true, Loopidot = true }

-- True if THIS account has ever logged into a character in
-- AUTHOR_CHARACTER_NAMES (see CheckAuthorAccount below). Modules call
-- this from their own LOCAL-only permission entry points - never from a
-- function that also verifies a remote sender's name (that would let
-- the author's own account wrongly trust an arbitrary incoming message
-- just because the RECEIVER happens to be the author - see the
-- knowledge base entry for why this distinction matters).
function ns.IsAuthorAccount()
    return AUTHOR_OVERRIDE_ENABLED and type(DHToolsAccountDB) == "table"
        and DHToolsAccountDB.isAuthorAccount == true
end

-- Called once per login/reload (PLAYER_LOGIN, below). Cheap no-op for
-- everyone except the handful of names in AUTHOR_CHARACTER_NAMES.
local function CheckAuthorAccount()
    if not AUTHOR_OVERRIDE_ENABLED then return end
    if not AUTHOR_CHARACTER_NAMES[UnitName("player")] then return end
    if type(DHToolsAccountDB) ~= "table" then
        DHToolsAccountDB = {}
    end
    DHToolsAccountDB.isAuthorAccount = true
end

-- Sets up a top-level DH-Tools window with the properties every one of them
-- needs: proper click-to-raise behavior, a guaranteed-opaque background
-- (rather than relying entirely on the template's own backdrop), and
-- dragging scoped to a title-bar-height strip only (registering drag on the
-- whole frame breaks addons like MoveAny that add their own drag handling
-- on top of whatever a frame already exposes). Ported from DH-Air's
-- Core.lua (DHAir:InitStandaloneWindow) - same rationale applies here.
-- Every DH-Tools window should call this once, right after creating its frame.
function ns.InitStandaloneWindow(targetFrame, rightInset)
    targetFrame:SetToplevel(true)

    local bg = targetFrame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0, 0, 0, 0.9)

    targetFrame:SetMovable(true)
    targetFrame:EnableMouse(true)

    local dragRegion = CreateFrame("Frame", nil, targetFrame)
    dragRegion:SetPoint("TOPLEFT", 0, 0)
    dragRegion:SetPoint("TOPRIGHT", -(rightInset or 28), 0) -- leaves room for a close button
    dragRegion:SetHeight(24)
    dragRegion:EnableMouse(true)
    dragRegion:RegisterForDrag("LeftButton")
    dragRegion:SetScript("OnDragStart", function() targetFrame:StartMoving() end)
    dragRegion:SetScript("OnDragStop", function() targetFrame:StopMovingOrSizing() end)
    return dragRegion
end

-- Returns true/false for whether `key` is currently enabled: saved state
-- if one exists, else the module's own default.
function ns.IsModuleEnabled(key)
    local saved = ns.db.modules[key]
    if saved ~= nil then return saved end
    local def = ns.modules[key]
    return def ~= nil and def.default or false
end

function ns.SetModuleEnabled(key, enabled)
    local def = ns.modules[key]
    if not def then
        ns.Print("Unknown module: '" .. tostring(key) .. "'. Type /dht list.")
        return
    end
    local wasEnabled = ns.IsModuleEnabled(key)
    ns.db.modules[key] = enabled
    if enabled and not wasEnabled then
        if def.OnEnable then def.OnEnable() end
        ns.Print(def.name .. " enabled.")
    elseif not enabled and wasEnabled then
        if def.OnDisable then def.OnDisable() end
        ns.Print(def.name .. " disabled.")
    end
end

local function ActivateEnabledModules()
    for _, key in ipairs(ns.moduleOrder) do
        if ns.IsModuleEnabled(key) then
            local def = ns.modules[key]
            if def.OnEnable then def.OnEnable() end
        end
    end
end

local function ListModules()
    ns.Print(("Modules (v%s):"):format(ns.VERSION))
    for _, key in ipairs(ns.moduleOrder) do
        local def = ns.modules[key]
        local state = ns.IsModuleEnabled(key) and "|cff33ff99on|r" or "|cffff3333off|r"
        ns.Print(("  %s - %s (%s)"):format(key, def.name, state))
    end
end

-- === Boot ===
local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_LOGIN")
frame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        ns.InitDB()
    elseif event == "PLAYER_LOGIN" then
        CheckAuthorAccount()
        ActivateEnabledModules()
        if ns.Minimap_Init then
            ns.Minimap_Init()
        end
        ns.Print(("loaded (v%s). Type /dht help for commands."):format(ns.VERSION))
    end
end)

-- === Slash commands ===
SLASH_DHTOOLS1 = "/dht"
SLASH_DHTOOLS2 = "/dhtools"

SlashCmdList["DHTOOLS"] = function(msg)
    msg = msg or ""
    local cmd, rest = msg:match("^(%S*)%s*(.-)$")
    cmd = (cmd or ""):lower()

    if cmd == "list" or cmd == "" then
        ListModules()
    elseif cmd == "on" then
        ns.SetModuleEnabled(rest, true)
    elseif cmd == "off" then
        ns.SetModuleEnabled(rest, false)
    elseif cmd == "config" or cmd == "options" then
        if ns.Config_Open then
            ns:Config_Open("Tools")
        else
            ns.Print("Config UI didn't load correctly.")
        end
    elseif cmd == "help" then
        ns.Print(("Commands (v%s):"):format(ns.VERSION))
        ns.Print("  /dht list          - show modules and their on/off state")
        ns.Print("  /dht on <module>   - enable a module")
        ns.Print("  /dht off <module>  - disable a module")
        ns.Print("  /dht config        - open the config window")
        ns.Print("  /dht help          - show this list")
        ns.Print("Each module keeps its own slash commands too (e.g. /mm for Mob Marker).")
    else
        ns.Print("Unknown command: '" .. cmd .. "'. Type /dht help.")
    end
end
