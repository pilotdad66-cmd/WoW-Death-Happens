-- DH-Air Minimap.lua
-- Standard LibDataBroker-1.1 / LibDBIcon-1.0 minimap button (CurseForge-compliant).
-- Left-click: open the Air Service Board (the primary hub for everyone -
-- Warlocks, Clickers, and plain members alike, not just auto-summon control).
-- Right-click: open the config window directly.
--
-- NOTE: this intentionally does NOT use EasyMenu/UIDropDownMenu for a
-- right-click context menu. Two rounds of testing on live Classic Era
-- showed the right-click either not registering or the menu not
-- appearing, and rather than keep guessing at a client-specific quirk we
-- can't reproduce or debug directly, right-click does one simple,
-- already-proven-working thing: open Config.

local ADDON_NAME, DHAir = ...

local LDB = LibStub("LibDataBroker-1.1")
local LDBIcon = LibStub("LibDBIcon-1.0")

-- Same icon the game uses for the Warlock spell Ritual of Summoning.
local SUMMON_ICON = "Interface\\Icons\\Spell_Shadow_Twilight"

local dataObject = LDB:NewDataObject("DHAir", {
    type = "launcher",
    text = "DH-Air",
    icon = SUMMON_ICON,
    OnClick = function(_, buttonPressed)
        if buttonPressed == "LeftButton" then
            if DHAir.Board_Toggle then
                DHAir:Board_Toggle()
            end
        elseif buttonPressed == "RightButton" then
            DHAir:Config_Open()
        end
    end,
    OnTooltipShow = function(tooltip)
        if not tooltip or not tooltip.AddLine then return end
        tooltip:AddLine("DH-Air")
        tooltip:AddLine(" ")
        tooltip:AddLine("Left-click: open the Air Service Board")
        tooltip:AddLine("Right-click: open config")
        tooltip:AddLine(" ")
        tooltip:AddLine("Auto-invite: " .. (DHAir.db.autoInvite and "|cff00ff00ON|r" or "|cffff0000OFF|r"))
        local status = DHAir.db.paused and "|cffffff00Paused|r"
            or (DHAir.db.active and "|cff00ff00Active|r" or "|cffff0000Stopped|r")
        tooltip:AddLine("Auto-summon: " .. status)
    end,
})

function DHAir.Minimap_UpdateIcon()
    -- LibDBIcon doesn't recolor icons itself; dim the icon when auto-summon is off
    -- so the minimap button visually reflects state at a glance, even though
    -- clicking it no longer directly toggles that (see the Board for that now).
    dataObject.iconR = DHAir.db.active and 1 or 0.5
    dataObject.iconG = DHAir.db.active and 1 or 0.5
    dataObject.iconB = DHAir.db.active and 1 or 0.5
end

function DHAir.Minimap_Init()
    LDBIcon:Register("DHAir", dataObject, DHAir.db.minimap)
    DHAir.Minimap_UpdateIcon()
end
