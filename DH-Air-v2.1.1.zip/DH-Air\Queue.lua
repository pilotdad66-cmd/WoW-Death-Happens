-- DH-Air Queue.lua
-- Manages the ordered summon queue and per-session summon history.

local ADDON_NAME, DHAir = ...

-- Strips a "-Realm" suffix for display / comparison purposes.
function DHAir:NormalizeName(name)
    if not name then return name end
    return name:match("^([^%-]+)") or name
end

-- Adds a player to the bottom of the queue. Returns true if added.
function DHAir:QueueAdd(name)
    if not name or name == "" then return false end
    local db = self.db
    local short = self:NormalizeName(name)

    for _, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            return false -- already queued
        end
    end

    if db.history[short] then
        return false -- already summoned this session, don't re-queue
    end

    table.insert(db.queue, {
        name = name,
        summoned = false,
        role = self.EffectiveRole and self:EffectiveRole(name) or nil,
        queuedAt = GetTime(),
    })
    self:Print(short .. " added to the summon queue (position " .. #db.queue .. ").")

    if self.TrySummonNext then
        self:TrySummonNext()
    end

    return true
end

-- Returns the first not-yet-summoned entry, or nil.
function DHAir:QueueNext()
    for _, entry in ipairs(self.db.queue) do
        if not entry.summoned then
            return entry
        end
    end
    return nil
end

--------------------------------------------------------------------------
-- Self-service (any DH-Air installation can join/leave, no permission needed)
--------------------------------------------------------------------------

-- Adds the local player to the queue. Same as being added by someone else's
-- whisper trigger, just self-initiated (e.g. from the Board's "Join queue"
-- button, or the /raid code phrase). Broadcasts so everyone else's queue
-- picks it up too.
function DHAir:SelfJoinQueue()
    local myName = UnitName("player")
    if self:QueueAdd(myName) then
        if self.Sync_BroadcastAdd then
            self:Sync_BroadcastAdd(myName)
        end
        return true
    end
    return false
end

-- Removes the local player from the queue. Always allowed - removing
-- yourself never needs permission, unlike removing someone else.
function DHAir:SelfLeaveQueue()
    local myName = UnitName("player")
    if self:QueueRemove(myName) then
        if self.Sync_IsActive and self:Sync_IsActive() then
            self:Sync_Send("REMOVE", myName)
        end
        return true
    end
    return false
end

--------------------------------------------------------------------------
-- Destinations (M1, see DH-Air-Destinations-Design.md) - local data model
-- only so far: no sync (M2) or officer-only editing (M3/M4) yet. Picking
-- your OWN destination is self-service, same idiom as SelfJoinQueue/
-- SelfLeaveQueue - no permission needed.
--------------------------------------------------------------------------

-- Looks up a destination entry ({ id, label, category }) by id, or nil if
-- unknown. `db.destinations` is small (tens of entries) so a linear scan
-- is plenty - no need for an id-keyed index.
function DHAir:GetDestination(destId)
    if not destId then return nil end
    for _, d in ipairs(self.db.destinations) do
        if d.id == destId then return d end
    end
    return nil
end

-- Shared implementation: sets (or clears, nil/"") `name`'s destination
-- within their existing queue entry, validating destId against
-- db.destinations. Callers are responsible for authorization - this
-- function itself doesn't check who's asking. SetMyDestination below
-- limits itself to the local player by construction; Sync.lua's SETDEST
-- receiver additionally verifies Name == sender before calling this for an
-- incoming broadcast, since one player must never be able to set another's
-- destination remotely.
function DHAir:ApplyDestination(name, destId)
    local short = self:NormalizeName(name)
    local entry = nil
    for _, e in ipairs(self.db.queue) do
        if self:NormalizeName(e.name) == short then
            entry = e
            break
        end
    end
    if not entry then return false end

    if destId == nil or destId == "" then
        entry.destination = nil
        return true
    end

    local dest = self:GetDestination(destId)
    if not dest or dest.enabled == false then
        -- Unknown id, or a real one an officer has since disabled - refuse
        -- rather than store a new selection the picker UI won't offer
        -- (Board's dropdown/`/dhair dest` both skip disabled entries).
        -- Doesn't touch an entry that already has this destination from
        -- before it was disabled - this function is only ever called to
        -- APPLY a (new) choice, never to silently re-validate an old one.
        return false
    end

    entry.destination = destId
    return true
end

-- Sets (or clears) the LOCAL PLAYER's own destination within their existing
-- queue entry. Requires the player to already be queued - destination is a
-- property of a queue entry, not something you can set in the abstract.
-- Self-service, no permission needed (same idiom as SelfJoinQueue/
-- SelfLeaveQueue) - broadcasts so other DH-Air installations' queues pick
-- it up too. Returns true/false so callers (Board.lua, later) can show a
-- refusal instead of failing silently.
--
-- Calls TrySummonNext() afterward (2026-08-03, same idiom SelfJoinQueue/
-- RELEASE/SUMMONED already follow) - a Warlock's auto-summon loop may
-- ALREADY be running and idle, having found nothing to match against
-- before this player picked a destination; without this, it wouldn't
-- notice the newly-eligible entry until some unrelated event (roster
-- change, bag update, etc.) happened to fire TrySummonNext again.
function DHAir:SetMyDestination(destId)
    local myName = UnitName("player")
    if not self:ApplyDestination(myName, destId) then
        return false
    end
    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("SETDEST", myName .. "|" .. (destId or ""))
    end
    if self.TrySummonNext then
        self:TrySummonNext()
    end
    return true
end

--------------------------------------------------------------------------
-- Destinations list management (officer-gated) - see Core.lua's
-- HasPermission("edit_destinations"). No editor UI yet (M4) - these are
-- the plain functions that UI will eventually call, same "API before UI"
-- precedent DH-Bavin's Core.lua used for SetRecipient/SetEditors ahead of
-- its own config-page work.
--------------------------------------------------------------------------

-- Full replace of the destinations list. Broadcasts the new list to
-- everyone else so their Boards (M5) converge too.
function DHAir:SetDestinationList(list)
    if not self:HasPermission("edit_destinations") then
        return false
    end
    self.db.destinations = list
    if self.Sync_BroadcastDestinations then
        self:Sync_BroadcastDestinations()
    end
    return true
end

-- Convenience: discards any custom edits and repopulates from the built-in
-- starter list (Destinations.lua). Same permission gate as
-- SetDestinationList (this IS a full replace, just from a fixed source).
-- 2026-08-03: reset now mirrors DEFAULT_DESTINATIONS exactly - each entry's
-- own `enabled` field is respected (defaulting true when absent) instead of
-- being forced true, and `continent` is carried over too. Previously this
-- hardcoded enabled=true and dropped continent entirely, so a reset would
-- silently re-enable The Stockade/Ragefire Chasm/The Deadmines (meant to
-- stay off by default) and break the Board/Minimap "Flight Points >
-- continent" grouping until the next login's migration patched it back up.
-- "Reset to default" now means what it says: default is whatever
-- Destinations.lua currently defines, disabled entries included.
function DHAir:ResetDestinationsToDefault()
    local fresh = {}
    for _, d in ipairs(self.DEFAULT_DESTINATIONS or {}) do
        table.insert(fresh, {
            id = d.id,
            label = d.label,
            category = d.category,
            continent = d.continent,
            enabled = (d.enabled ~= false),
        })
    end
    return self:SetDestinationList(fresh)
end

-- Enables/disables a destination WITHOUT removing it from the list -
-- distinct from removal (DestinationEditor.lua's remove button), which
-- deletes the entry permanently. A disabled destination is hidden from
-- new-selection UI (Board's dropdown, FindDestinationByQuery below, and
-- ApplyDestination's own guard above) but keeps rendering normally
-- anywhere it's just being DISPLAYED - GetDestination doesn't filter by
-- enabled, so a queue entry that already picked it before it was disabled
-- (Board.lua's destText, SortedQueue's destLabel, the editor's own
-- read-only rows) keeps showing its real label instead of going blank.
-- Same officer gate as SetDestinationList; broadcasts the whole list since
-- Sync.lua doesn't have a narrower per-field message (DESTLIST is already
-- the one officer-edit broadcast, see EncodeDestinations/
-- DecodeDestinationsChunk for the enabled bit on the wire).
function DHAir:SetDestinationEnabled(destId, enabled)
    if not self:HasPermission("edit_destinations") then
        return false
    end
    local dest = self:GetDestination(destId)
    if not dest then
        return false
    end
    dest.enabled = enabled and true or false
    if self.Sync_BroadcastDestinations then
        self:Sync_BroadcastDestinations()
    end
    return true
end

-- Finds a destination by case-insensitive substring match against its
-- label (e.g. "iron" -> "Ironforge (Dun Morogh)"). Returns the single
-- match, or nil if there's no match OR more than one (ambiguous) -
-- callers should ask the player to be more specific rather than silently
-- guessing which one they meant. Used by slash commands as an interim
-- text-entry alternative ahead of a real dropdown picker (Board UI, M5).
function DHAir:FindDestinationByQuery(query)
    if not query or query == "" then return nil end
    local q = query:lower()
    local match, matchCount = nil, 0
    for _, d in ipairs(self.db.destinations) do
        if d.enabled ~= false and d.label:lower():find(q, 1, true) then
            match = d
            matchCount = matchCount + 1
        end
    end
    if matchCount == 1 then return match end
    return nil
end

--------------------------------------------------------------------------
-- Warlock's own operating destination (2026-08-03 addition) - which
-- destination auto-summon is currently servicing. DISTINCT from
-- SetMyDestination above, which sets YOUR OWN QUEUE ENTRY's destination if
-- you're queued as someone wanting a summon - a Warlock running
-- auto-summon isn't necessarily queued at all, and these two concepts can
-- differ (e.g. a Warlock who is ALSO queued for a summon elsewhere). Local
-- operating state only - never synced, unlike SETDEST/entry.destination,
-- since nobody else needs to know which destination YOU personally are
-- currently working. See Summon.lua's QueueNextAvailable for how this
-- filters auto-summon, and RequestStartAutoSummon/RequestResumeAutoSummon
-- for the "you must pick one before starting" gate.
--------------------------------------------------------------------------

function DHAir:GetWarlockDestination()
    return self.db.warlockDestination
end

-- Passing nil or "" clears it (auto-summon then has nothing to safely
-- match against - see QueueNextAvailable). Refuses an unrecognized OR
-- disabled destId (same "no new selection of a disabled destination" rule
-- ApplyDestination follows).
function DHAir:SetWarlockDestination(destId)
    if destId == nil or destId == "" then
        self.db.warlockDestination = nil
        return true
    end
    local dest = self:GetDestination(destId)
    if not dest or dest.enabled == false then
        return false
    end
    self.db.warlockDestination = destId
    return true
end

--------------------------------------------------------------------------
-- Permission-gated removal (see Core.lua's HasPermission/UnitHasAuthority)
--------------------------------------------------------------------------

-- Requests removing ANY player from the queue. Removing yourself is always
-- allowed; removing someone else requires raid leader/assist. Refuses
-- quietly (with a chat message) rather than attempting and failing, so the
-- UI can just call this without duplicating the permission check itself.
function DHAir:RequestRemove(name)
    local myName = UnitName("player")
    local isSelf = self:NormalizeName(name) == self:NormalizeName(myName)

    if not isSelf and not self:HasPermission("remove_any") then
        self:Print("Only the raid leader or an assistant can remove someone else from the queue.")
        return false
    end

    if not self:QueueRemove(name) then
        return false
    end

    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("REMOVE", name)
    end
    return true
end

-- Requests clearing the ENTIRE queue. Raid leader/assist only.
function DHAir:RequestClearAll()
    if not self:HasPermission("clear_all") then
        self:Print("Only the raid leader or an assistant can clear the entire queue.")
        return false
    end

    self:QueueReset()
    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("CLEARALL")
    end
    return true
end

-- Requests changing the /raid chat code phrase. Leader/assist only for now
-- (see HasPermission - guild-officer-gated in 2.2, same call site).
function DHAir:RequestSetPhrase(newPhrase)
    if not newPhrase or newPhrase == "" then
        self:Print("Usage: /dhair phrase <word or phrase>")
        return false
    end

    if not self:HasPermission("set_phrase") then
        self:Print("Only the raid leader or an assistant can change the code phrase.")
        return false
    end

    self.db.codePhrase = newPhrase
    if self.Sync_IsActive and self:Sync_IsActive() then
        self:Sync_Send("SETPHRASE", newPhrase)
    end
    return true
end

-- Marks a queued player as summoned and records them in session history.
function DHAir:QueueMarkSummoned(name)
    local db = self.db
    local short = self:NormalizeName(name)
    for _, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            entry.summoned = true
        end
    end
    db.history[short] = true
end

-- Removes a player from the queue entirely (does not touch history).
function DHAir:QueueRemove(name)
    local db = self.db
    local short = self:NormalizeName(name)
    for i, entry in ipairs(db.queue) do
        if self:NormalizeName(entry.name) == short then
            table.remove(db.queue, i)
            return true
        end
    end
    return false
end

-- Clears the queue and the session history (fresh Air Service session).
function DHAir:QueueReset()
    self.db.queue = {}
    self.db.history = {}
    if self.CancelTimeout then
        self:CancelTimeout()
    end
    self.summonState = "idle"
    self.currentSummon = nil
    self.pendingEntry = nil
    self.failCount = 0
    self.pausedForShards = false
    if self.claims then
        self.claims = {}
    end
    if self.syncBuffers then
        self.syncBuffers = {}
    end
    if self.destListBuffers then
        self.destListBuffers = {}
    end
    if self.destSyncDataBuffers then
        self.destSyncDataBuffers = {}
    end
    self:Print("Summon queue and session have been reset.")
end

-- Prints the current queue state to chat.
function DHAir:QueueList()
    local db = self.db
    if #db.queue == 0 then
        self:Print("Summon queue is empty.")
        return
    end
    self:Print("Current summon queue:")
    for i, entry in ipairs(db.queue) do
        local status = entry.summoned and "|cff00ff00(summoned)|r" or "|cffffff00(waiting)|r"
        self:Print(i .. ". " .. self:NormalizeName(entry.name) .. " " .. status)
    end
end

--------------------------------------------------------------------------
-- Display ordering (Board UI) - pure function, no side effects
--------------------------------------------------------------------------

-- Returns queue entries in Board display order:
--   1. the viewer's own entry (if queued), always first
--   2. entries with a role (summoner/clicker), sorted by sortKey/sortDir
--   3. everyone else, sorted by sortKey/sortDir
-- Sorting never reorders ACROSS tiers, only within each one - a helper who
-- just joined still outranks every regular member, but not a helper who's
-- been waiting longer.
function DHAir:SortedQueue(sortKey, sortDir)
    sortKey = sortKey or "wait"
    sortDir = sortDir or "desc"
    local myName = UnitName("player")
    local myKey = self:NormalizeName(myName)

    -- Resolves a queue entry's destId to its current label for sorting
    -- (M5, DH-Air-Destinations-Design.md §5) - undecided sorts as "" (an
    -- empty string), which naturally sorts first ascending / last
    -- descending, same as an unset name would under Lua's default string
    -- comparison. Looked up fresh each call rather than cached on the
    -- entry, since db.destinations can change (officer edits) independent
    -- of the queue itself.
    local function destLabel(entry)
        local d = entry.destination and self:GetDestination(entry.destination)
        return d and d.label or ""
    end

    local function compare(a, b)
        local c
        if sortKey == "name" then
            c = self:NormalizeName(a.name) < self:NormalizeName(b.name) and -1
                or (self:NormalizeName(a.name) > self:NormalizeName(b.name) and 1 or 0)
        elseif sortKey == "dest" then
            local aDest, bDest = destLabel(a), destLabel(b)
            c = aDest < bDest and -1 or (aDest > bDest and 1 or 0)
        else
            local aWait, bWait = GetTime() - (a.queuedAt or GetTime()), GetTime() - (b.queuedAt or GetTime())
            c = aWait < bWait and -1 or (aWait > bWait and 1 or 0)
        end
        if sortDir == "asc" then return c < 0 end
        return c > 0
    end

    local mine, helpers, regular = nil, {}, {}
    for _, entry in ipairs(self.db.queue) do
        if not entry.summoned then
            if self:NormalizeName(entry.name) == myKey then
                mine = entry
            elseif entry.role then
                table.insert(helpers, entry)
            else
                table.insert(regular, entry)
            end
        end
    end

    table.sort(helpers, compare)
    table.sort(regular, compare)

    local ordered = {}
    if mine then table.insert(ordered, mine) end
    for _, e in ipairs(helpers) do table.insert(ordered, e) end
    for _, e in ipairs(regular) do table.insert(ordered, e) end
    return ordered
end
