-- DH-Air Invite.lua
-- Detects whispered invite requests and the /raid chat code phrase, and
-- auto-invites/queues the requester in both cases.

local ADDON_NAME, DHAir = ...

-- Phrases that trigger an auto-invite. Matched against the whole,
-- trimmed, lower-cased whisper text (not a substring match), so that
-- normal conversation whispers aren't accidentally treated as requests.
local INVITE_PATTERNS = {
    "^inv$", "^invite$",
    "^inv me$", "^invite me$",
    "^inv please$", "^invite please$",
    "^plz inv$", "^pls inv$", "^inv plz$", "^inv pls$",
    "^can i get an? inv$", "^can i get an? invite$",
    "^can i have an? inv$", "^can i have an? invite$",
    "^need inv$", "^need an? invite$",
    "^inv for air$", "^inv for the air service$",
}

local recentInvites = {}
local INVITE_DEBOUNCE_SECONDS = 20

local function MatchesInvitePattern(msg)
    msg = msg:lower()
    msg = msg:gsub("^%s+", ""):gsub("%s+$", "")
    for _, pattern in ipairs(INVITE_PATTERNS) do
        if msg:match(pattern) then
            return true
        end
    end
    return false
end

local function DoInvite(name)
    if C_PartyInfo and C_PartyInfo.InviteUnit then
        C_PartyInfo.InviteUnit(name)
    else
        InviteUnit(name)
    end
end

-- Called from Core.lua's CHAT_MSG_WHISPER handler.
function DHAir:HandleWhisper(msg, sender)
    if not self.db or not self.db.autoInvite then return end
    if not sender or sender == "" then return end
    if not MatchesInvitePattern(msg) then return end

    if self.db.guildOnly and not self:IsGuildMember(sender) then
        return -- "guild members only" is on and this whisperer isn't a guildmate
    end

    local now = GetTime()
    if recentInvites[sender] and (now - recentInvites[sender]) < INVITE_DEBOUNCE_SECONDS then
        return -- avoid spamming repeated invites for the same whisper spam
    end
    recentInvites[sender] = now

    DoInvite(sender)
    self:Print("Auto-invited " .. self:NormalizeName(sender) .. ".")
    if self:QueueAdd(sender) then
        if self.Sync_BroadcastAdd then
            self:Sync_BroadcastAdd(sender)
        end
    end
end

-- Called from Core.lua's CHAT_MSG_RAID/CHAT_MSG_RAID_LEADER handler. Anyone
-- in raid chat typing the configured code phrase (exact match, not a
-- substring - same reasoning as the whisper triggers above: avoids normal
-- conversation accidentally counting) gets themselves added to the queue.
-- This fires for the sender's OWN messages too (WoW echoes your own chat
-- back to your own client), so the exact same code path handles "I typed
-- the phrase myself" and "I saw someone else type it" identically - no
-- need to special-case self vs. others.
function DHAir:HandleRaidChat(msg, sender)
    if not self.db then return end
    if not sender or sender == "" then return end

    local phrase = self.db.codePhrase
    if not phrase or phrase == "" then return end

    local trimmed = msg:lower():gsub("^%s+", ""):gsub("%s+$", "")
    if trimmed ~= phrase:lower() then return end

    if self.db.guildOnly and not self:IsGuildMember(sender) then
        return -- "guild members only" is on and this player isn't a guildmate
    end

    if self:QueueAdd(sender) then
        if self.Sync_BroadcastAdd then
            self:Sync_BroadcastAdd(sender)
        end
    end
end
