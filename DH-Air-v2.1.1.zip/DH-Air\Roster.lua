-- DH-Air Roster.lua
-- Guild-wide registration: who's volunteering as a Summoner or a Clicker.
--
-- IMPORTANT: registering a role is a PURE DECLARATION. It never touches the
-- summon queue - joining the queue is always a separate, explicit action
-- (see Queue.lua / Board.lua). A parked player who's already at the meeting
-- spot can register without ever requesting a summon.
--
-- Broadcast over whatever channel Sync.lua currently picks (RAID > PARTY >
-- GUILD), so registration works even before a raid exists.
--
-- Summoner registrations also carry an "active" flag (auto-summon currently
-- running, vs. off/paused) - needed so the leader-succession rescue handoff
-- in Leadership.lua can rank candidates by who's actually working right
-- now, not just who's registered. This is necessarily a bit stale (only
-- refreshed when a Summoner toggles their role, or on the periodic HELLO
-- cadence) since we don't want a dedicated live-update broadcast for
-- something this infrequently needed - see Leadership.lua for how that
-- staleness is treated (a soft preference, not a hard requirement).

local ADDON_NAME, DHAir = ...

local ROSTER_TTL_SECONDS = 300 -- entries older than this are treated as stale/offline

local function RosterTable(role)
    if role == "summoner" then return "summoners" end
    if role == "clicker" then return "clickers" end
    return nil
end

--------------------------------------------------------------------------
-- Queries
--------------------------------------------------------------------------

function DHAir:IsRegistered(role, name)
    if not self.db then return false end
    local tblName = RosterTable(role)
    local tbl = tblName and self.db.roster[tblName]
    if not tbl then return false end
    local entry = tbl[self:NormalizeName(name)]
    if not entry then return false end
    return (GetTime() - entry.lastSeen) < ROSTER_TTL_SECONDS
end

function DHAir:CountRegistered(role)
    if not self.db then return 0 end
    local tblName = RosterTable(role)
    local tbl = tblName and self.db.roster[tblName]
    if not tbl then return 0 end
    local now = GetTime()
    local n = 0
    for _, entry in pairs(tbl) do
        if (now - entry.lastSeen) < ROSTER_TTL_SECONDS then
            n = n + 1
        end
    end
    return n
end

-- Best-known guess at whether a registered Summoner currently has
-- auto-summon actively running. Necessarily approximate for anyone other
-- than yourself - see the module comment above.
function DHAir:IsSummonerActive(name)
    if not self:IsRegistered("summoner", name) then return false end
    local entry = self.db.roster.summoners[self:NormalizeName(name)]
    return entry ~= nil and entry.active == true
end

-- Recomputes the role that should be SHOWN for a player from current roster
-- state (summoner takes precedence over clicker if both are true). Single
-- source of truth used to (re)stamp queue entries whenever a registration
-- changes, so priority-tier sorting always reflects the current roster.
function DHAir:EffectiveRole(name)
    if self:IsRegistered("summoner", name) then return "summoner" end
    if self:IsRegistered("clicker", name) then return "clicker" end
    return nil
end

--------------------------------------------------------------------------
-- Recording (local writes, no broadcast - see SetRole for the public API)
--------------------------------------------------------------------------

-- Re-stamps a queue entry's .role field from current roster truth, if that
-- player happens to be in the queue right now.
function DHAir:RefreshQueueEntryRole(name)
    if not self.db then return end
    local key = self:NormalizeName(name)
    for _, entry in ipairs(self.db.queue) do
        if self:NormalizeName(entry.name) == key then
            entry.role = self:EffectiveRole(name)
        end
    end
end

function DHAir:RecordRegistration(role, name, active)
    local tblName = RosterTable(role)
    if not tblName or not self.db then return end
    self.db.roster[tblName][self:NormalizeName(name)] = { lastSeen = GetTime(), active = active == true }
    self:RefreshQueueEntryRole(name)
end

function DHAir:RecordUnregistration(role, name)
    local tblName = RosterTable(role)
    if not tblName or not self.db then return end
    self.db.roster[tblName][self:NormalizeName(name)] = nil
    self:RefreshQueueEntryRole(name)
end

--------------------------------------------------------------------------
-- Public API (local player toggling their own role)
--------------------------------------------------------------------------

function DHAir:SetRole(role, enabled)
    local myName = UnitName("player")
    local active = (role == "summoner") and (self.db.active and not self.db.paused) or false

    if enabled then
        self:RecordRegistration(role, myName, active)
    else
        self:RecordUnregistration(role, myName)
    end

    if self.Sync_IsActive and self:Sync_IsActive() then
        if enabled then
            self:Sync_Send("REGISTER", role .. "|" .. myName .. "|" .. (active and "1" or "0"))
        else
            self:Sync_Send("UNREGISTER", role .. "|" .. myName)
        end
    end
end

-- Re-broadcasts the player's own current registrations, including a fresh
-- active/paused snapshot. Piggybacks on the existing HELLO cadence in
-- Sync.lua so both staleness AND the active flag refresh periodically
-- without needing a separate timer.
function DHAir:Roster_Reannounce()
    if not (self.Sync_IsActive and self:Sync_IsActive()) then return end
    local myName = UnitName("player")
    if self:IsRegistered("summoner", myName) then
        local active = self.db.active and not self.db.paused
        self.db.roster.summoners[self:NormalizeName(myName)] = { lastSeen = GetTime(), active = active }
        self:Sync_Send("REGISTER", "summoner|" .. myName .. "|" .. (active and "1" or "0"))
    end
    if self:IsRegistered("clicker", myName) then
        self:Sync_Send("REGISTER", "clicker|" .. myName .. "|0")
    end
end

--------------------------------------------------------------------------
-- Incoming message handling (called from Sync.lua's dispatcher)
--------------------------------------------------------------------------

function DHAir:Roster_OnMessage(msgType, rest)
    if msgType == "UNREGISTER" then
        local role, name = rest:match("^(.-)|(.+)$")
        if not role or not name then return end
        if role ~= "summoner" and role ~= "clicker" then return end
        self:RecordUnregistration(role, name)
        return
    end

    if msgType == "REGISTER" then
        local role, name, activeFlag = rest:match("^(.-)|(.-)|(.*)$")
        if not role or not name then return end
        if role ~= "summoner" and role ~= "clicker" then return end
        self:RecordRegistration(role, name, activeFlag == "1")
    end
end
