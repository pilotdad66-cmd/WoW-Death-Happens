-- DH-Air Invite.lua
-- Detects whispered invite requests and the /raid chat code phrase, and
-- auto-invites/queues the requester in both cases.

local ADDON_NAME, DHAir = ...

-- Phrases that trigger an auto-invite. Matched against the whole,
-- trimmed, lower-cased whisper text (not a substring match), so that
-- normal conversation whispers aren't accidentally treated as requests.
local INVITE_PATTERNS = {
    "^inv$", "^invite$",
    "^inv me$", "^invite me$",
    "^inv please$", "^invite please$",
    "^plz inv$", "^pls inv$", "^inv plz$", "^inv pls$",
    "^can i get an? inv$", "^can i get an? invite$",
    "^can i have an? inv$", "^can i have an? invite$",
    "^need inv$", "^need an? invite$",
    "^inv for air$", "^inv for the air service$",
}

local recentInvites = {}
local INVITE_DEBOUNCE_SECONDS = 20

-- Matches the code phrase at the START of a trigger message and returns
-- (matched, note), where note is whatever free text the requester typed
-- after it ("air to SM" -> "to SM") or nil.
--
-- 2026-08-07 (@kb:air-prefix-trigger): the old rule was exact equality, so
-- "air pls", "air to SM", "AIR!" matched nothing at all - no invite, no
-- queue entry, and no reply of any kind - and the requester (who almost
-- never has DH-Air installed) just waited. That silent drop was the real
-- cause of the "significant delay" reported after the 2026-08-07 raid.
--
-- The phrase must be followed by end-of-string or WHITESPACE: a bare
-- prefix test would also match "airhead". The note is sliced out of the
-- ORIGINAL message rather than the lower-cased copy so it keeps the
-- requester's own capitalization when the Board shows it; lower-casing
-- never changes a string's length, so the offsets still line up.
--
-- WHISPERS ONLY. Public channels keep exact matching (see
-- HandlePublicChat) - a Warlock typing "air service is up, whisper me"
-- in raid chat must not queue themselves.
local function MatchPhrasePrefix(msg, phrase)
    if not phrase or phrase == "" then return false, nil end

    local trimmed = msg:lower():gsub("^%s+", ""):gsub("%s+$", "")
    local lowerPhrase = phrase:lower()
    if trimmed == lowerPhrase then return true, nil end

    local plen = #lowerPhrase
    if trimmed:sub(1, plen) ~= lowerPhrase then return false, nil end
    if not trimmed:sub(plen + 1, plen + 1):match("%s") then return false, nil end

    local original = msg:gsub("^%s+", ""):gsub("%s+$", "")
    local note = original:sub(plen + 1):gsub("^%s+", ""):gsub("%s+$", "")
    if note == "" then note = nil end
    return true, note
end

local function MatchesInvitePattern(msg)
    msg = msg:lower()
    msg = msg:gsub("^%s+", ""):gsub("%s+$", "")
    for _, pattern in ipairs(INVITE_PATTERNS) do
        if msg:match(pattern) then
            return true
        end
    end
    return false
end

local function DoInvite(name)
    if C_PartyInfo and C_PartyInfo.InviteUnit then
        C_PartyInfo.InviteUnit(name)
    else
        InviteUnit(name)
    end
end

-- Called from Core.lua's CHAT_MSG_WHISPER handler.
-- 2026-08-05 (Chris): joining the summon QUEUE must be an explicit,
-- deliberate act - whispering the code phrase (db.codePhrase, same one
-- raid chat uses) or self-joining via the addon's own Board. A plain
-- invite request ("inv", "invite me", ...) now ONLY gets the auto-invite,
-- never a queue entry - previously it did both, which meant guildies
-- whispering for an ordinary group invite silently landed in the summon
-- queue.
-- Whispering the code phrase also auto-invites (if autoInvite is on and
-- the debounce allows) - you can't be summoned from outside the group
-- anyway, so "air" alone gets you both in one whisper.
function DHAir:HandleWhisper(msg, sender)
    if not self.db then return end
    if not sender or sender == "" then return end

    local isQueueJoin, note = MatchPhrasePrefix(msg, self.db.codePhrase)
    local isInviteRequest = MatchesInvitePattern(msg)
    if not isQueueJoin and not isInviteRequest then return end

    if self.db.guildOnly and not self:IsGuildMember(sender) then
        return -- "guild members only" is on and this whisperer isn't a guildmate
    end

    if self.db.autoInvite then
        local now = GetTime()
        if not (recentInvites[sender] and (now - recentInvites[sender]) < INVITE_DEBOUNCE_SECONDS) then
            recentInvites[sender] = now
            DoInvite(sender)
            self:Print("Auto-invited " .. self:NormalizeName(sender) .. ".")
        end
    end

    if isQueueJoin then
        -- `note` is LOCAL to this client and deliberately never synced
        -- (QueueFeedback design D6) - it's free prose, and putting free
        -- prose on the wire is exactly the k-0024 escaping trap DH-Bavin
        -- hit. The Warlock who received the whisper is the one who reads
        -- it and sets the destination, so nobody else needs it.
        if self:QueueAdd(sender, note) then
            if self.Sync_BroadcastAdd then
                self:Sync_BroadcastAdd(sender)
            end
        end
    end
end

-- Called from Core.lua for CHAT_MSG_RAID / CHAT_MSG_RAID_LEADER /
-- CHAT_MSG_PARTY / CHAT_MSG_PARTY_LEADER. Anyone in those channels typing
-- the configured code phrase gets themselves added to the queue. Party was
-- added 2026-08-07 (QueueFeedback design D1) - a 5-man forming before the
-- raid exists had no way in short of whispering.
--
-- EXACT match here, unlike HandleWhisper's prefix match above, and that
-- asymmetry is deliberate (design D2): these are PUBLIC channels, so a
-- prefix rule would mean a Warlock typing "air service is up, whisper me"
-- in raid chat silently queues themselves. A whisper is unambiguously
-- addressed at the Air Service; a raid-chat line is not.
--
-- This fires for the sender's OWN messages too (WoW echoes your own chat
-- back to your own client), so the exact same code path handles "I typed
-- the phrase myself" and "I saw someone else type it" identically - no
-- need to special-case self vs. others.
function DHAir:HandlePublicChat(msg, sender)
    if not self.db then return end
    if not sender or sender == "" then return end

    local phrase = self.db.codePhrase
    if not phrase or phrase == "" then return end

    local trimmed = msg:lower():gsub("^%s+", ""):gsub("%s+$", "")
    if trimmed ~= phrase:lower() then return end

    if self.db.guildOnly and not self:IsGuildMember(sender) then
        return -- "guild members only" is on and this player isn't a guildmate
    end

    if self:QueueAdd(sender) then
        if self.Sync_BroadcastAdd then
            self:Sync_BroadcastAdd(sender)
        end
    end
end
